export interface CaseStudy {
  id: number;
  title: string;
  tagline: string;
  description?: string;
  image: string;
  tags: string[];
  link?: string;
  metrics?: {
    icon: string;
    label: string;
    value: string;
  }[];
  challenge?: string[];
  solution?: string[];
  timeline?: string;
  role?: string;
  team?: string;
  tools?: string[];
  research?: string[];
  implementation?: string[];
  impact?: {
    user?: string[];
    business?: string[];
    development?: string[];
  };
}

export interface TimelineEvent {
  title: string;
  company: string;
  period: string;
  description: string | React.ReactNode;
  icon: React.ReactNode;
  skills?: string[];
}

export interface Quote {
  text: string;
  author: string;
}