import { Quote } from '../types';

export const quotes: Quote[] = [
  {
    text: "The universe is not only stranger than we imagine, it is stranger than we can imagine. This perspective guides my design philosophy: there's always another way to look at a problem.",
    author: "John Imburgia"
  },
  {
    text: "We are a way for the cosmos to know itself. Through design, I help create interfaces that allow humans to better understand their world and themselves.",
    author: "John Imburgia, inspired by Carl Sagan"
  },
  {
    text: "Design is not just what it looks like and feels like. Design is how it works, how it evolves, and ultimately how it shapes our collective experience.",
    author: "John Imburgia"
  }
];