import { SlideCaseStudyConfig } from '../../components/SlideCaseStudy';

export const shopifyConfig: SlideCaseStudyConfig = {
  slides: [
    {
      id: 'hero',
      kind: 'hero',
      backgroundImage: '/shopify_hero.webp',
      tags: ['Enterprise Software', 'FinTech', 'Global Markets', 'Tax Compliance'],
      title: 'Shopify Tax International',
      tagline:
        'Turning country by country VAT complexity into a single confident product for EU and UK merchants.',
      role: 'Design Lead, Mission Lead',
    },
    {
      id: 'problem',
      kind: 'content',
      chapter: 'Discovery',
      title: 'A Legacy Product Built for Pain',
      body: (
        <>
          <p>
            Shopify&rsquo;s 2024 push into international markets ran straight into tax compliance.
            EU and UK merchants faced a patchwork of country-specific VAT rules and the legacy
            product offered little help. Rates had to be entered manually, no automation, no
            guidance, no visibility into where they might owe tax.
          </p>
          <p>
            I audited that legacy product end to end, mapped the gaps against benchmarks, and
            paired the audit with merchant interviews so every design decision traced back to
            something real.
          </p>
        </>
      ),
      media: {
        kind: 'image',
        src: '/shopify_manual.webp',
        alt: 'Legacy Manual Tax product for EU and UK merchants',
        before: true,
      },
    },
    {
      id: 'workshop',
      kind: 'content',
      chapter: 'Discovery',
      title: 'Five Features, One Direction',
      body: (
        <>
          <p>
            I partnered with product and engineering leads for a cross-functional workshop in
            Montr&eacute;al. We turned interview findings into a focused list of five features
            covering the most painful jobs: liability insights, VAT registration, VAT invoices,
            product category exemptions, and B2B exemptions.
          </p>
          <p>
            We presented to senior leadership that same week, locked in the MVP scope, and
            committed to keeping the free Manual Tax product around so every merchant had a
            no-cost option.
          </p>
        </>
      ),
      media: {
        kind: 'image',
        src: '/shopify02.webp',
        alt: 'Cross-functional Shopify Tax workshop in Montr\u00e9al',
      },
    },
    {
      id: 'liability',
      kind: 'content',
      chapter: 'Implementation',
      title: 'Tax Liability Insights',
      body: (
        <>
          <p>
            In the US product, liability tracking and tax collection lived in separate cards. For
            EU and UK we consolidated them into one flow so merchants could see where they were
            approaching a threshold and act on it without jumping around.
          </p>
          <p>
            Popovers surfaced region-specific insights without cluttering the page. Email and
            in-admin alerts fired at 80% of threshold. Merchants got it immediately in testing,
            and the pattern became the foundation for a unified global standard.
          </p>
        </>
      ),
      media: {
        kind: 'carousel',
        items: [
          { src: '/shopify_legacyUS.webp', alt: 'Legacy US tax product with competing cards' },
          { src: '/shopify_tli-rejects.webp', alt: 'Tax Liability Insights design iterations' },
          { src: '/TLI.gif', alt: 'Shopify Tax dashboard with liability popovers' },
        ],
      },
    },
    {
      id: 'registration',
      kind: 'content',
      chapter: 'Implementation',
      title: 'Registration That Grows With the Business',
      body: (
        <>
          <p>
            As a merchant&rsquo;s revenue grows, their registrations and exemptions change. The
            system needed to surface that proactively rather than expecting merchants to track it
            themselves.
          </p>
          <p>
            Banners inside the admin flagged eligibility changes, walked merchants through the
            right registration type, and stayed quiet when nothing was needed. Banners are
            Shopify&rsquo;s standard surface for ongoing issues, so it felt native.
          </p>
        </>
      ),
      media: { kind: 'image', src: '/Reg.gif', alt: 'Tax registration flow with banner alerts' },
    },
    {
      id: 'invoices',
      kind: 'content',
      chapter: 'Implementation',
      title: 'VAT Invoices That Adapt',
      body: (
        <>
          <p>
            VAT invoices had to satisfy regional law without adding friction. I mapped
            country-specific requirements, aligned with B2B and Split Cart teams on shared data,
            and landed on the buyer and merchant order screens as the best entry points.
          </p>
          <p>
            The template stayed neutral so each merchant&rsquo;s brand could lead through their
            uploaded logo. A single toggle turned it on without stepping on third-party invoicing
            tools.
          </p>
        </>
      ),
      media: {
        kind: 'carousel',
        items: [
          { src: '/shopify06.png', alt: 'VAT invoice toggle in tax settings' },
          { src: '/shopify_tradeoffs.webp', alt: 'Tradeoffs for VAT invoice entry points' },
          { src: '/shopify07.webp', alt: 'Tax compliance overview with invoices surfaced' },
          { src: '/shopify05.png', alt: 'Dynamic VAT invoice template' },
        ],
      },
    },
    {
      id: 'categories',
      kind: 'content',
      chapter: 'Implementation',
      title: 'Categories and B2B Exemptions',
      body: (
        <>
          <p>
            Categorization existed but bulk editing didn&rsquo;t, so fixing exemption accuracy
            was a manual chore. I partnered with the Bulk Editor team on a workflow that let
            merchants assign or override categories at scale, with in-admin reminders nudging
            them when products were left unclassified.
          </p>
          <p>
            A real-time VAT ID checker validated B2B customers at checkout, applied zero-rated
            exemptions where eligible, and pulled valid IDs directly into invoices. It was one
            of the most requested features in merchant research.
          </p>
        </>
      ),
      media: {
        kind: 'carousel',
        items: [
          { src: '/shopify08.png', alt: 'Bulk product categorization inside the tax experience' },
          { src: '/Dynamic Tax Exemptions.gif', alt: 'Dynamic tax exemptions and VAT ID checks' },
        ],
      },
    },
    {
      id: 'results',
      kind: 'content',
      chapter: 'Results',
      title: (
        <>
          Adoption, Trust,
          <br />
          and Time Returned
        </>
      ),
      body: (
        <>
          <p>
            Merchants went from managing tax manually to having a flow they actually trusted.
            Adoption and compliance metrics both climbed, and support volume dropped.
          </p>
          <ul className="space-y-3 text-cream/75 text-base list-none pl-0 font-sans">
            <li>
              <strong className="text-cream">90 percent</strong> of eligible merchants chose
              Shopify Tax over the free option or a third party app.
            </li>
            <li>
              Merchants generated <strong className="text-cream">millions of VAT invoices</strong>{' '}
              within weeks, reducing reliance on external tools.
            </li>
            <li>
              In-admin liability tracking and VAT ID validation{' '}
              <strong className="text-cream">saved merchants significant time</strong> compared
              to the legacy workflow.
            </li>
            <li>
              Tax-related support frustration{' '}
              <strong className="text-cream">dropped sharply</strong>, making it one of
              Shopify&rsquo;s lowest-friction surfaces.
            </li>
          </ul>
        </>
      ),
      media: {
        kind: 'carousel',
        items: [
          { src: '/shopify07.webp', alt: 'Tax compliance overview post launch' },
          { src: '/TLI.gif', alt: 'Liability insights after launch' },
          { src: '/Dynamic Tax Exemptions.gif', alt: 'Dynamic B2B exemptions in production' },
        ],
      },
    },
  ],
};
