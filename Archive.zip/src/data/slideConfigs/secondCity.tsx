import { SlideCaseStudyConfig } from '../../components/SlideCaseStudy';

export const secondCityConfig: SlideCaseStudyConfig = {
  slides: [
    {
      id: 'hero',
      kind: 'hero',
      backgroundImage: '/secondcity01.webp',
      tags: ['Entertainment', 'UX Research', 'Analytics', 'Mobile First'],
      title: 'The Second City',
      tagline:
        'A flexible, mobile first experience for discovering and booking live comedy in Chicago and beyond.',
      role: 'UX Designer, UX Researcher',
    },
    {
      id: 'problem',
      kind: 'content',
      chapter: 'Discovery',
      title: 'A Theater Centric Legacy',
      body: (
        <>
          <p>
            The Second City&rsquo;s existing site gave every show the same visual weight.
            Headliners, touring productions, and student nights all sat side by side, so audiences
            had to do the sorting themselves.
          </p>
          <p>
            I kicked off the engagement with a product manager and engineering lead, working
            directly with the COO and Head of Digital to reframe the show-finding experience
            around what audiences were actually looking for.
          </p>
        </>
      ),
      media: {
        kind: 'image',
        src: '/sc_previous.webp',
        alt: 'Previous Second City website',
        before: true,
      },
    },
    {
      id: 'audiences',
      kind: 'content',
      chapter: 'Discovery',
      title: 'Two Audiences, Two Behaviors',
      body: (
        <>
          <p>
            I combined Second City&rsquo;s analytics with stakeholder interviews and competitive
            research. The data showed a clear split: desktop planners browsing weeks out with low
            intent, and mobile users looking for seats tonight or this weekend with high intent.
          </p>
          <p>
            There were other groups too, touring searchers, families, improv regulars, each with
            different needs. Every screen was designed to serve the planner and the mobile buyer
            first, with clear paths for everyone else.
          </p>
        </>
      ),
      media: {
        kind: 'image',
        src: '/secondcity02.png',
        alt: 'Competitive analysis and user research findings',
      },
    },
    {
      id: 'ordering',
      kind: 'content',
      chapter: 'Discovery',
      title: 'Ordering Shows With Intent',
      body: (
        <>
          <p>
            I ran whiteboarding sessions to define how shows should be ordered, balancing what
            audiences expected with what the business needed to promote. We landed on a
            chronological base with prioritization layered on top, so headline shows sat above
            touring and student work without burying anything.
          </p>
          <p>
            For high-intent mobile users we added urgency cues like tickets remaining, and
            grouped marquee shows into large prioritized tiles so the biggest moments got the
            most real estate.
          </p>
        </>
      ),
      media: {
        kind: 'image',
        src: '/secondcity03.webp',
        alt: 'Mindmap for determining show order',
      },
    },
    {
      id: 'scenarios',
      kind: 'content',
      chapter: 'Implementation',
      title: 'Scenarios and Flows',
      body: (
        <>
          <p>
            I mapped flows for each audience type. High-intent buyers could reach checkout in a
            handful of taps. Exploratory users could go deeper without losing their place in the
            experience.
          </p>
          <p>
            Each persona came with a clickable prototype so stakeholders could walk through the
            experience themselves rather than just reading about it.
          </p>
        </>
      ),
      media: {
        kind: 'carousel',
        items: [
          { src: '/secondcity04.webp', alt: 'Personas and scenarios for show discovery' },
          { src: '/secondcity05.png', alt: 'User flows across desktop and mobile' },
        ],
      },
    },
    {
      id: 'homepage',
      kind: 'content',
      chapter: 'Implementation',
      title: 'Homepage and Quick Show Finder',
      body: (
        <>
          <p>
            The homepage kept the brand&rsquo;s energy but simplified the path into the core
            experience. Date selection and live ticket availability were the first things users
            could interact with.
          </p>
          <p>
            A Quick Show Finder sat above the fold so mobile visitors could get from homepage to
            a show tonight without scrolling past marketing content first.
          </p>
        </>
      ),
      media: {
        kind: 'image',
        src: '/secondcity07.webp',
        alt: 'Second City homepage redesign',
      },
    },
    {
      id: 'results-page',
      kind: 'content',
      chapter: 'Implementation',
      title: 'Results Page and Quick View',
      body: (
        <>
          <p>
            Show listings displayed dates, times, and availability inline so users could scan and
            decide without opening every detail page. Headliner priority held up across filters
            and categories.
          </p>
          <p>
            A quick view modal let mobile buyers preview a show and buy tickets without leaving
            the list. Fewer steps, less drop-off.
          </p>
        </>
      ),
      media: {
        kind: 'carousel',
        items: [
          { src: '/secondcity08.webp', alt: 'Show results redesign' },
          { src: '/secondcity09.webp', alt: 'Quick view ticket finder' },
        ],
      },
    },
    {
      id: 'detail',
      kind: 'content',
      chapter: 'Implementation',
      title: 'Show Detail Page',
      body: (
        <>
          <p>
            For users landing directly on a show, the detail page pulled description, cast,
            reviews, and logistics into one view alongside an embedded calendar of upcoming dates.
          </p>
          <p>
            Putting every upcoming performance on the show page itself cut extra navigation and
            gave returning audiences one place to plan their next visit.
          </p>
        </>
      ),
      media: {
        kind: 'image',
        src: '/secondcity10.webp',
        alt: 'Show detail page with embedded calendar',
      },
    },
    {
      id: 'results',
      kind: 'content',
      chapter: 'Results',
      title: (
        <>
          Ticket Sales Up,
          <br />
          Bounce Rates Down
        </>
      ),
      body: (
        <>
          <p>
            Mobile went from an afterthought to the primary surface and the numbers followed.
            The biggest shift was high-intent mobile users completing purchases on the device
            they arrived on.
          </p>
          <ul className="space-y-3 text-cream/75 text-base list-none pl-0 font-sans">
            <li>
              Ticket sales lifted by{' '}
              <strong className="text-cream">20 percent</strong> in the six months post launch.
            </li>
            <li>
              Bounce rates <strong className="text-cream">dropped 13 percent</strong> compared
              to the prior six months.
            </li>
            <li>
              Mobile ticket share climbed from{' '}
              <strong className="text-cream">42 percent to 51.5 percent</strong>, with mobile
              visits up 6 percent.
            </li>
            <li>
              Referrals to Second City Works (the business arm) grew substantially through
              clearer cross linking.
            </li>
          </ul>
        </>
      ),
      media: {
        kind: 'carousel',
        items: [
          { src: '/secondcity07.webp', alt: 'Final homepage in production' },
          { src: '/secondcity08.webp', alt: 'Final results page in production' },
          { src: '/secondcity09.webp', alt: 'Quick view in production' },
          { src: '/secondcity10.webp', alt: 'Show detail page in production' },
        ],
      },
    },
  ],
};
