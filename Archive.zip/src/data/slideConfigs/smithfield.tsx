import { SlideCaseStudyConfig } from '../../components/SlideCaseStudy';

export const smithfieldConfig: SlideCaseStudyConfig = {
  slides: [
    {
      id: 'hero',
      kind: 'hero',
      backgroundImage: '/smithfield1.webp',
      tags: ['E-commerce', 'Multi-brand', 'Design Systems', 'Food & Beverage'],
      title: 'Smithfield Foods',
      tagline:
        'A multi-brand commerce platform with one shared cart, many voices, and a design system built to scale.',
      role: 'UX / UI Design Lead',
    },
    {
      id: 'problem',
      kind: 'content',
      chapter: 'Discovery',
      title: 'Many Brands, One Cart',
      body: (
        <>
          <p>
            Smithfield&rsquo;s portfolio spans a wide range of food brands, each with its own
            voice and audience. The legacy sites were all separate, no shared cart, no shared
            engineering, and a growing cost for parallel design work across every brand.
          </p>
          <p>
            The goal was one commerce foundation where customers could shop across any brand in
            a single transaction while each brand kept its personality. The hardest part wasn&rsquo;t
            engineering, it was getting brand marketing teams aligned.
          </p>
        </>
      ),
      media: {
        kind: 'image',
        src: '/smithfield2.webp',
        alt: 'Smithfield mood board and branding direction',
      },
    },
    {
      id: 'style-guide',
      kind: 'content',
      chapter: 'Discovery',
      title: 'A Shared Style Language',
      body: (
        <>
          <p>
            Working directly with the brand teams, I translated the agreed direction into a
            shared style guide and lightweight design system in Abstract. Tokens covered type,
            color, spacing, and component states so any brand could theme without forking the
            system.
          </p>
          <p>
            Accessibility was built in from the start. We validated color contrast with Contraste
            and baked WCAG compliance into the component library so brand themes could vary
            without ever dropping below standards.
          </p>
        </>
      ),
      media: {
        kind: 'image',
        src: '/smithfield5.webp',
        alt: 'Smithfield shared style guide in Abstract',
      },
    },
    {
      id: 'homepage',
      kind: 'content',
      chapter: 'Implementation',
      title: 'Responsive Homepage Template',
      body: (
        <>
          <p>
            The homepage template set the tone for the entire platform. I designed it as a
            flexible stack of modules that could be reordered, restyled, or swapped per brand
            without breaking the underlying layout contract.
          </p>
          <p>
            Brand teams could lead with storytelling, product drops, or promotional moments
            depending on their audience, and the same template still served responsive
            experiences from mobile to desktop.
          </p>
        </>
      ),
      media: {
        kind: 'image',
        src: '/smithfield3.webp',
        alt: 'Responsive homepage template',
      },
    },
    {
      id: 'subpages',
      kind: 'content',
      chapter: 'Implementation',
      title: 'Subpage Templates at Scale',
      body: (
        <>
          <p>
            Product listings, detail pages, contact pages, promotional pages, and a universal
            cart all extended from the same system. Each template went through iterative design
            and requirements gathering with the brand teams who would live with it.
          </p>
          <p>
            Because components shared tokens and behavior, a brand could launch new content
            without waiting for bespoke design work on every page type.
          </p>
        </>
      ),
      media: {
        kind: 'image',
        src: '/smithfield4.webp',
        alt: 'Template variations across Smithfield brands',
      },
    },
    {
      id: 'multi-site',
      kind: 'content',
      chapter: 'Implementation',
      title: 'Multi Site Brand Application',
      body: (
        <>
          <p>
            With the system in place, I partnered with external agencies to apply it to each
            brand. The typical handoff was a themed homepage plus the master design file, which
            the agency then extended inside the shared guardrails.
          </p>
          <p>
            The result was a network of brand sites that felt distinct to customers but
            operated as one platform for Smithfield, sharing the universal cart and common
            infrastructure.
          </p>
        </>
      ),
      media: {
        kind: 'image',
        src: '/smithfield6.webp',
        alt: 'Brand customization examples across the portfolio',
      },
    },
    {
      id: 'results',
      kind: 'content',
      chapter: 'Results',
      title: (
        <>
          One Platform,
          <br />
          Many Brands Live
        </>
      ),
      body: (
        <>
          <p>
            The platform shipped as the foundation for the Smithfield portfolio, replacing
            parallel work streams with one shared system while keeping the brand identities
            customers recognized.
          </p>
          <ul className="space-y-3 text-cream/75 text-base list-none pl-0 font-sans">
            <li>
              Unified e-commerce launched across <strong className="text-cream">multiple Smithfield brands</strong> on one platform.
            </li>
            <li>
              <strong className="text-cream">Shared cart</strong> enabled cross brand shopping and lifted average order value.
            </li>
            <li>
              <strong className="text-cream">Reusable components</strong> cut development time for every new brand launch.
            </li>
            <li>
              Each brand retained its <strong className="text-cream">distinct identity</strong>{' '}
              while operating on shared infrastructure.
            </li>
          </ul>
        </>
      ),
      media: {
        kind: 'carousel',
        items: [
          { src: '/smithfield3.webp', alt: 'Homepage template in production' },
          { src: '/smithfield4.webp', alt: 'Subpage templates in production' },
          { src: '/smithfield6.webp', alt: 'Brand applications in production' },
        ],
      },
    },
  ],
};
