import { SlideCaseStudyConfig } from '../../components/SlideCaseStudy';

export const advicentConfig: SlideCaseStudyConfig = {
  slides: [
    {
      id: 'hero',
      kind: 'hero',
      backgroundImage: '/advicent01.webp',
      tags: ['FinTech', 'Enterprise Software', 'Financial Planning', 'UX Research'],
      title: 'Advicent NaviPlan',
      tagline:
        'Reimagining financial planning software to expand beyond high-net-worth clients into the mass affluent market.',
      role: 'UX Designer, UX Researcher',
    },
    {
      id: 'problem',
      kind: 'content',
      chapter: 'Discovery',
      title: 'From Affluent to Mass Affluent',
      body: (
        <>
          <p>
            NaviPlan was built for high-net-worth planners and it showed. Dense, jargon-heavy,
            and slow to navigate in client meetings. Advicent wanted to bring it to the mass
            affluent market without stripping out the depth senior planners depended on.
          </p>
          <p>
            I led discovery with a card sort and emotional response worksheets, then took the
            work into contextual inquiries across the US and Canada to see how planners actually
            used the tool with clients.
          </p>
        </>
      ),
      media: {
        kind: 'image',
        src: '/advicent02.webp',
        alt: 'Card sort and questionnaire research',
      },
    },
    {
      id: 'benchmarks',
      kind: 'content',
      chapter: 'Discovery',
      title: 'Benchmarks and Heuristics',
      body: (
        <>
          <p>
            Alongside the field work, I ran heuristic evaluations, competitive analysis, and a
            quantitative survey. Mass affluent investors expected something closer to their
            banking apps, not decade-old enterprise software.
          </p>
          <p>
            The findings pointed to a clear gap in visual polish and flexibility. The redesign
            needed to feel modern immediately and adapt to how planners actually worked, not how
            the tool assumed they would.
          </p>
        </>
      ),
      media: {
        kind: 'image',
        src: '/advicent04.webp',
        alt: 'Competitive review and heuristic evaluation',
      },
    },
    {
      id: 'personas',
      kind: 'content',
      chapter: 'Discovery',
      title: 'Personas and Journeys',
      body: (
        <>
          <p>
            Six personas came out of the research, each representing a different planner-client
            interaction through the lifecycle of a plan. Analytics confirmed that advisors used
            the software non-linearly, jumping between modules rather than following any prescribed
            path.
          </p>
          <p>
            I paired each persona with an experience flow so the team had a shared reference for
            where the product needed to adapt to intent rather than force a sequence.
          </p>
        </>
      ),
      media: {
        kind: 'carousel',
        items: [
          { src: '/advicent05.webp', alt: 'User personas for NaviPlan redesign' },
          { src: '/advicent06.webp', alt: 'Experience flows across planner and client' },
        ],
      },
    },
    {
      id: 'workshop',
      kind: 'content',
      chapter: 'Discovery',
      title: 'A Three Day Workshop',
      body: (
        <>
          <p>
            I ran a three-day workshop with Advicent to review and prioritize the research.
            The group stress-tested the findings, aligned on success criteria, and ranked
            opportunities by impact and effort together.
          </p>
          <p>
            We left with a prioritization matrix, an opportunity roadmap, and ten product themes
            that gave leadership a shared foundation for the redesign.
          </p>
        </>
      ),
      media: {
        kind: 'carousel',
        items: [
          { src: '/advicent07.webp', alt: 'Workshop with client stakeholders' },
          { src: '/advicent08.webp', alt: 'Prioritization matrix' },
          { src: '/advicent09.webp', alt: 'Opportunity roadmap' },
        ],
      },
    },
    {
      id: 'themes',
      kind: 'content',
      chapter: 'Implementation',
      title: 'Ten Guiding Themes',
      body: (
        <>
          <p>
            The themes drove design, engineering, and executive conversations. They covered
            alignment, flexibility, integrated guidance, and data-driven defaults so decisions
            had something to trace back to.
          </p>
          <ol className="grid grid-cols-1 gap-y-1.5 text-cream/75 text-sm list-decimal pl-5 font-sans">
            <li>Align advisor and client experiences</li>
            <li>Use a core and layers approach</li>
            <li>Improve advisor workflow efficiency</li>
            <li>Integrate guidance throughout</li>
            <li>Deploy common design standards</li>
            <li>Provide default values using data</li>
            <li>Apply the 80/20 rule</li>
            <li>Use big data for benchmarking</li>
            <li>Empower client interactivity</li>
            <li>Enhance personal finance features</li>
          </ol>
        </>
      ),
      media: {
        kind: 'image',
        src: '/advicent11.webp',
        alt: 'Final wireframe composition referencing the guiding themes',
      },
    },
    {
      id: 'comps',
      kind: 'content',
      chapter: 'Implementation',
      title: 'Design Comps in Practice',
      body: (
        <>
          <p>
            I moved from low-fidelity wireframes in Sketch into a lightweight design system,
            then into high-fidelity prototypes in InVision. Each iteration was reviewed against
            the ten themes so feedback stayed grounded in the principles, not personal preference.
          </p>
          <p>
            Comps covered the planner workspace, the client portal, and the side-by-side view
            built for live meetings, where advisors and clients could navigate the same screen
            together without losing context.
          </p>
        </>
      ),
      media: {
        kind: 'carousel',
        items: [
          { src: '/advicent11.webp', alt: 'Final wireframe composition one' },
          { src: '/advicent12.webp', alt: 'Final wireframe composition two' },
          { src: '/advicent13.webp', alt: 'Final wireframe composition three' },
          { src: '/advicent14.webp', alt: 'Final wireframe composition four' },
        ],
      },
    },
    {
      id: 'results',
      kind: 'content',
      chapter: 'Results',
      title: (
        <>
          A Redesign Built
          <br />
          On Evidence
        </>
      ),
      body: (
        <>
          <p>
            The work gave Advicent a research-backed foundation to expand NaviPlan into the
            mass affluent market, along with a roadmap and design language leadership could
            commit to.
          </p>
          <ul className="space-y-3 text-cream/75 text-base list-none pl-0 font-sans">
            <li>
              Enabled expansion into the <strong className="text-cream">mass affluent market</strong> with NaviPlan Essentials.
            </li>
            <li>
              Defined <strong className="text-cream">ten product themes</strong> as the backbone for the redesign.
            </li>
            <li>
              Equipped advisors with a more <strong className="text-cream">efficient and flexible workflow</strong>.
            </li>
            <li>
              Elevated client transparency through <strong className="text-cream">self serve and side by side planning</strong>.
            </li>
            <li>
              Secured executive alignment with a <strong className="text-cream">clear, research driven roadmap</strong>.
            </li>
          </ul>
        </>
      ),
      media: {
        kind: 'carousel',
        items: [
          { src: '/advicent11.webp', alt: 'NaviPlan wireframe one' },
          { src: '/advicent12.webp', alt: 'NaviPlan wireframe two' },
          { src: '/advicent13.webp', alt: 'NaviPlan wireframe three' },
          { src: '/advicent14.webp', alt: 'NaviPlan wireframe four' },
        ],
      },
    },
  ],
};
