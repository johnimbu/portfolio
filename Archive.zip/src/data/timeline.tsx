import React from 'react';
import { Palette, Users, LayoutGrid as Layout, LineChart, BarChart, Play } from 'lucide-react';
import { TimelineEvent } from '../types';
import YouTubeModal from '../components/YouTubeModal';

interface TopDermLinkProps {
  onVideoClick: () => void;
}

const TopDermLink = ({ onVideoClick }: TopDermLinkProps) => (
  <button
    onClick={onVideoClick}
    className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-red-600/20 border border-red-500/30 text-red-400 hover:bg-red-600/30 hover:border-red-500/50 transition-all duration-200 text-sm font-medium"
  >
    <Play size={12} className="fill-current" />
    Top Derm
  </button>
);

export const createTimelineEvents = (onVideoClick: () => void): TimelineEvent[] => [
  {
    title: "Staff Product Designer",
    company: "Shopify | Chicago, IL (remote)",
    period: "3.5 years",
    description: "Launched and led UX for Shopify Tax (90%+ adoption) and related 0-1 platforms, simplifying complex compliance workflows and generating millions in incremental revenue through growth efforts. Managed and mentored UX designers.",
    icon: <Palette size={18} className="text-cobalt" />,
    skills: ["UX/UI Design", "Design Leadership", "Research", "Tax Solutions", "International Markets"]
  },
  {
    title: "UX Manager, UX Design Lead",
    company: "Level Ex | Chicago, IL",
    period: "2 years",
    description: (
      <span>
        Directed UX for 5+ medical games, including{' '}
        <TopDermLink onVideoClick={onVideoClick} />{' '}
        (4.5 rating, used by 1 in 5 dermatologists). Increased verified registration from 29% to 83% across games. Managed and mentored a cross-discipline design team.
      </span>
    ),
    icon: <Users size={18} className="text-cobalt" />,
    skills: ["UX Design", "Team Management", "Game Design", "Product Strategy"]
  },
  {
    title: "UX Designer II",
    company: "Projekt202 / ORA Interactive | Chicago, IL",
    period: "3 Years",
    description: "Designed scalable systems and flagship experiences like Smithfield's multi-brand single-cart platform and The Second City's redesigned ticketing flow.",
    icon: <Layout size={18} className="text-cobalt" />,
    skills: ["UX/UI Design", "UX Research", "Usability Testing", "Mobile & Web Design"]
  },
  {
    title: "Digital Marketing Supervisor",
    company: "Symmetri Marketing | Chicago, IL",
    period: "2 Years",
    description: "Led UX design, marketing campaigns, and a cross-functional team that drove measurable lead growth for large B2B brands.",
    icon: <LineChart size={18} className="text-cobalt" />,
    skills: ["UX/UI Design", "Analytics", "SEO", "CRO", "Team Leadership"]
  },
  {
    title: "Digital Marketing Consultant",
    company: "Logical Media Group / Rise Interactive | Chicago, IL",
    period: "1.5 Years",
    description: "Advanced SEO, CRO, and PPC strategies that improved visibility and conversions across multiple client accounts",
    icon: <BarChart size={18} className="text-cobalt" />,
    skills: ["Digital Marketing", "SEO", "CRO", "Content Strategy"]
  }
];

export const timelineEvents: TimelineEvent[] = [
  {
    title: "Staff Product Designer",
    company: "Shopify | Chicago, IL (remote)",
    period: "3.5 years",
    description: "Launched and led UX for Shopify Tax (90%+ adoption) and related 0-1 platforms, simplifying complex compliance workflows and generating millions in incremental revenue through growth efforts. Managed and mentored UX designers.",
    icon: <Palette size={18} className="text-cobalt" />,
    skills: ["UX/UI Design", "Design Leadership", "Research", "Tax Solutions", "International Markets"]
  },
  {
    title: "UX Manager, UX Design Lead",
    company: "Level Ex | Chicago, IL",
    period: "2 years",
    description: (
      <span>
        Directed UX for 5+ medical games, including{' '}
        <a
          href="https://www.youtube.com/watch?v=prc-1dTuISg"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-red-600/20 border border-red-500/30 text-red-400 hover:bg-red-600/30 hover:border-red-500/50 transition-all duration-200 text-sm font-medium"
        >
          <Play size={12} className="fill-current" />
          Top Derm
        </a>{' '}
          (4.5 rating, used by 1 in 5 dermatologists). Increased verified registration from 29% to 83% across games. Managed and mentored a cross-discipline design team.
      </span>
    ),
    icon: <Users size={18} className="text-cobalt" />,
    skills: ["UX Design", "Team Management", "Game Design", "Product Strategy"]
  },
  {
    title: "UX Designer II",
    company: "Projekt202 / ORA Interactive | Chicago, IL",
    period: "3 Years",
    description: "Designed scalable systems and flagship experiences like Smithfield's multi-brand single-cart platform and The Second City's redesigned ticketing flow.",
    icon: <Layout size={18} className="text-cobalt" />,
    skills: ["UX/UI Design", "UX Research", "Usability Testing", "Mobile & Web Design"]
  },
  {
    title: "Digital Marketing Supervisor",
    company: "Symmetri Marketing | Chicago, IL",
    period: "2 Years",
    description: "Led UX design, marketing campaigns, and a cross-functional team that drove measurable lead growth for large B2B brands.",
    icon: <LineChart size={18} className="text-cobalt" />,
    skills: ["UX/UI Design", "Analytics", "SEO", "CRO", "Team Leadership"]
  },
  {
    title: "Digital Marketing Consultant",
    company: "Logical Media Group / Rise Interactive | Chicago, IL",
    period: "1.5 Years",
    description: "Advanced SEO, CRO, and PPC strategies that improved visibility and conversions across multiple client accounts.",
    icon: <BarChart size={18} className="text-cobalt" />,
    skills: ["Digital Marketing", "SEO", "CRO", "Content Strategy"]
  }
];