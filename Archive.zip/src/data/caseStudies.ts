import { CaseStudy } from '../types';

export const featuredCaseStudy: CaseStudy = {
  id: 1,
  title: "Shopify Tax International",
  tagline: "Designing a tax product that turned complexity into confidence for EU and UK merchants",
  image: "/shopify01.webp",
  tags: ["Enterprise Software", "FinTech", "Global Markets", "Tax Compliance"],
  challenge: [
    "One of Shopify’s 2024 priorities was international expansion—but tax compliance quickly emerged as a major blocker. EU and UK merchants faced a maze of country-specific VAT (value-added tax) rules that made compliance confusing and time-consuming. Our challenge was to launch a 0–1 tax product that simplified this complexity and built confidence for merchants of all sizes."
  ],
  solution: [
    "To better understand the key tax jobs-to-be-done for EU and UK merchants, I partnered with Shopify's internal tax experts and our product manager to conduct merchant interviews to uncover how merchants navigate VAT compliance and where Shopify's current offering fell short. We heard consistent pain points—uncertainty around when and where to collect tax, difficulty keeping registrations up to date, rigid invoicing across regions, and confusion managing B2B exemptions.",
    "I took these findings and partnered with my product and engineering lead counterparts to run a cross-functional workshop in Montréal, turning insights into focus and aligning on the five most critical features to address key merchant pain points:",
    "<div class='bg-cosmic-light/50 border border-white/10 rounded-lg p-6 my-6'><div class='space-y-3'><div class='flex items-start'><span class='flex-shrink-0 w-6 h-6 rounded-full bg-accent-violet text-cosmic-black text-sm font-bold flex items-center justify-center mr-3 mt-0.5'>1</span><div><strong class='text-accent-violet'>Tax Liability Insights</strong> — real-time tracking across jurisdictions</div></div><div class='flex items-start'><span class='flex-shrink-0 w-6 h-6 rounded-full bg-accent-violet text-cosmic-black text-sm font-bold flex items-center justify-center mr-3 mt-0.5'>2</span><div><strong class='text-accent-violet'>VAT Registration</strong> — facilitate registration updates with alerts when eligibility changes</div></div><div class='flex items-start'><span class='flex-shrink-0 w-6 h-6 rounded-full bg-accent-violet text-cosmic-black text-sm font-bold flex items-center justify-center mr-3 mt-0.5'>3</span><div><strong class='text-accent-violet'>VAT Invoices</strong> — flexible templates that adapt to region, language, and currency</div></div><div class='flex items-start'><span class='flex-shrink-0 w-6 h-6 rounded-full bg-accent-violet text-cosmic-black text-sm font-bold flex items-center justify-center mr-3 mt-0.5'>4</span><div><strong class='text-accent-violet'>Product Category Exemptions</strong> — smart tagging with automated rate application</div></div><div class='flex items-start'><span class='flex-shrink-0 w-6 h-6 rounded-full bg-accent-violet text-cosmic-black text-sm font-bold flex items-center justify-center mr-3 mt-0.5'>5</span><div><strong class='text-accent-violet'>B2B Tax Exemptions</strong> — automatic B2B onboarding with proper exemptions</div></div></div></div>"
  ],
  implementation: [
    "2. VAT registration flows matched international VAT registration types, alerting merchants if they were ineligible for registrations types based on their shop's revenue.",
    "3. I designed a utilitarian VAT invoice template, that dynamically presented information such as currency conversions and purchase order numbers, based on merchant settings. Merchants could also upload their own logo to personalize invoices",
    "4. I implemented a flow and interaction for merchants to categorize products which will automatically apply tax exemptions at checkout."
  ],
  impact: {
    business: [
      "90% of merchants chose Shopify Tax over the free option or a third-party app, demonstrating strong preference and trust.",
      "Merchants enabled VAT invoices at scale, reducing reliance on cumbersome third-party tools and generating millions of invoices within weeks.",
      "In-admin liability tracking and VAT ID validation saved merchants significant time by reducing reliance on self-tracking and also increased compliance compared to legacy workflows.",
      "Bulk product categorization improved tax accuracy at checkout and reduced support debt, since merchants could resolve tax accuracy issues proactively in fewer steps.",
      "Support call data showed frustration with tax products dropped significantly, making it one of Shopify's lowest-friction product areas."
    ]
  }
};

export const caseStudies: CaseStudy[] = [
  {
    id: 2,
    title: "The Second City",
    tagline: "Designing a flexible, mobile-first experience for discovering and booking live comedy",
    image: "/sc01.jpg",
    tags: ["Entertainment", "UX Research", "Analytics", "Mobile First"],
    challenge: [
      "The Second City, known for its live comedy and training programs, partnered with us to redesign its website. The challenge was to deeply understand their business goals and audience behavior to rebuild the show-finding experience from the ground up—making it easier for visitors to discover and book performances while spotlighting the brand’s most important shows."
    ],
    solution: [
      "To kick off the project, our core team—myself, a product manager, and an engineering lead—partnered closely with The Second City's Chief Operating Officer and Head of Digital to define the redesign strategy. We began by reviewing the existing show-finding experience, which was theater-centric and presented all shows with equal visual weight. It lacked the hierarchy and intuitive browsing patterns seen in best-in-class live event experiences.",
      "<img src='/sc_previous.webp' alt='Previous Second City website' class='w-full rounded-lg my-6 cursor-pointer hover:opacity-90 transition-opacity' onclick='this.dispatchEvent(new CustomEvent(\"imageClick\", { bubbles: true, detail: { src: \"/sc_previous.webp\", alt: \"Previous Second City website\" } }))' />",
      "<div class='bg-cosmic-light/50 border border-white/10 rounded-lg p-6 my-6'><div class='space-y-3'><div class='flex items-start'><span class='flex-shrink-0 w-6 h-6 rounded-full bg-accent-violet text-cosmic-black text-sm font-bold flex items-center justify-center mr-3 mt-0.5'>1</span><div><strong class='text-accent-violet'>Desktop Planners</strong> — browsing shows far in advance with low purchase intent</div></div><div class='flex items-start'><span class='flex-shrink-0 w-6 h-6 rounded-full bg-accent-violet text-cosmic-black text-sm font-bold flex items-center justify-center mr-3 mt-0.5'>2</span><div><strong class='text-accent-violet'>Mobile Users</strong> — high intent, often seeking tickets for the same day or weekend</div></div></div></div>"
    ],
    implementation: [
      "We identified several additional user types beyond our core segments—like travelers searching for touring shows, families looking for age-appropriate options, and audiences specifically seeking improv rather than stand-up, etc. By mapping flows around these behaviors, we designed pathways tailored to each scenario, ensuring intuitive navigation and a seamless experience across devices.",
      "Recognizing the homepage as the entry point for most users, we prioritized a visually immersive hero section that captured The Second City's brand. We introduced a \"Quick Show Finder\" module for easy access to upcoming shows.",
      "Based on client workshops, we designed the show results to present performances in an intuitive way, tailored to user types and aligned with The Second City's branding and priorities.",
      "Building on our show-ordering approach, we refined the results page to keep users focused on purchase. We introduced a quick-view modal that let users preview show details without leaving the listing page—reducing back-and-forth clicks, maintaining momentum in the funnel, and ensuring consistency across desktop and mobile.",
      "For exploratory, low-intent users, a full show detail page was designed, featuring an embedded show calendar. This update catered to focused-intent users who arrived on specific show pages, providing all relevant shows in one place rather than requiring additional navigation."
    ],
    impact: {
      business: [
        "Lifted ticket sales by 20% in the six months post-launch compared to the previous period",
        "Reduced bounce rates by 13% compared to the prior six months",
        "Mobile drove more sales, with ticket purchase share jumping from 42% to 51.5% and mobile site visits climbing 6%.",
        "Substantially boosted referrals to Second City Works (for businesses)"
      ]
    }
  },
  {
    id: 4,
    title: "Smithfield Foods",
    tagline: "Creating a unified e-commerce platform for multiple food brands with shared cart functionality",
    image: "/smithfield1.webp",
    tags: ["E-commerce", "Multi-brand", "Design Systems", "Food & Beverage"],
    challenge: [
      "Smithfield Foods needed a scalable e-commerce solution that could serve multiple brands under their portfolio while maintaining individual brand identities. The key challenge was creating a unified shopping experience that allowed customers to purchase products from different Smithfield brands in a single transaction, while ensuring each brand maintained its unique visual identity and messaging."
    ],
    solution: [
      "I led the design of a flexible, multi-brand e-commerce platform that balanced brand individuality with operational efficiency. The solution centered around a shared cart system that allowed customers to shop across Smithfield's portfolio seamlessly, while each brand maintained its distinct look and feel through a comprehensive design system.",
      "Working closely with brand teams, I developed a modular design approach that could adapt to different brand aesthetics while maintaining consistency in user experience patterns. This included creating flexible templates for product pages, checkout flows, and promotional content that could be easily customized for each brand."
    ],
    implementation: [
      "The implementation involved creating a comprehensive design system with flexible components that could be themed for different brands. I designed responsive templates for homepages, product listings, and detail pages that maintained usability across all Smithfield brands while allowing for visual customization.",
      "The shared cart functionality required careful UX consideration to help users understand they were shopping across multiple brands while maintaining trust and clarity throughout the purchase process. I designed clear visual indicators and messaging to guide users through the multi-brand shopping experience."
    ],
    impact: {
      business: [
        "Successfully launched a unified e-commerce platform serving multiple Smithfield brands",
        "Enabled cross-brand shopping with shared cart functionality, increasing average order value",
        "Reduced development time for new brand launches through reusable design components",
        "Maintained brand integrity while achieving operational efficiency across the portfolio"
      ]
    }
  },
  // {
  //   id: 5,
  //   title: "Level Ex Registration",
  //   tagline: "Designing a unified registration experience that turned a fragmented, high-friction process into one of Level Ex's most effective growth levers",
  //   image: "/topderm1.webp",
  //   tags: ["Gaming", "Medical", "Identity Verification", "Growth"],
  //   challenge: [
  //     "Level Ex creates medical training games that let physicians practice diagnosing and treating virtual patients in their specialty. But behind the scenes, registration had become a major bottleneck. Each title used its own independently built flow, leaving player data fragmented and unreliable. Without verifiable information, we couldn't tailor content to medical specialties, offer Continuing Medical Education (CME), or give sponsors confidence in who they were reaching. We needed a unified registration flow that instilled confidence, verified users seamlessly, and scaled across every game in the portfolio."
  //   ],
  //   solution: [
  //     "As Lead UX Designer, I began the project by interviewing senior leadership to identify the most critical problem facing Level Ex. Across marketing, engineering, and product, the message was the same: too few players were completing registration. On average, only about 29% of players who started the process finished it.",
  //     "To understand why, I sat down with medical professionals and watched them play our games. Observing real physicians interact with the flow quickly surfaced three core issues:",
  //     "<div class='bg-cosmic-light/50 border border-white/10 rounded-lg p-6 my-6'><div class='space-y-3'><div class='flex items-start'><span class='w-2 h-2 rounded-full bg-accent-violet mr-3 mt-2 flex-shrink-0'></span><div><strong class='text-accent-violet'>Unclear value</strong> — Players didn't understand why they needed to register to play a game and were hesitant to share personal information.</div></div><div class='flex items-start'><span class='w-2 h-2 rounded-full bg-accent-violet mr-3 mt-2 flex-shrink-0'></span><div><strong class='text-accent-violet'>Poor flow and relevance</strong> — The registration process felt clunky, repetitive, and disconnected from their specialty or context.</div></div><div class='flex items-start'><span class='w-2 h-2 rounded-full bg-accent-violet mr-3 mt-2 flex-shrink-0'></span><div><strong class='text-accent-violet'>No chance to try before committing</strong> — Many expected to sample the game before being asked to register, and dropped off when forced to do so upfront.</div></div></div></div>",
  //     "These findings framed the problem not just as a UX issue, but as a credibility and trust challenge.",
  //     "Building on that, I worked cross-functionally with product managers and engineers to map out over 100 player scenarios the new registration flow needed to handle—from specialty verification to cross-title identity linking. These scenarios became our product requirements:",
  //     "<img src='/lex02.png' alt='Level Ex research and scenarios' class='w-full rounded-lg my-6 cursor-pointer hover:opacity-90 transition-opacity' onclick='this.dispatchEvent(new CustomEvent(\"imageClick\", { bubbles: true, detail: { src: \"/lex02.png\", alt: \"Level Ex research and scenarios\" } }))' />"
  //   ],
  //   implementation: [
  //     "<h3 class='text-xl md:text-2xl font-display mb-6 text-accent-violet'>1. Clarifying the Value of Registration</h3>",
  //     "The first challenge was helping physicians understand why registration mattered. We shifted from a transactional sign-up to a transparent value exchange. Players now saw clear benefits upfront—eligibility for CME credit, personalized cases by specialty, and access to exclusive new treatments from our sponsors.",
  //     "To build trust around data collection, I introduced a subtle \"Why do you need this information?\" tooltip next to the NPI field, explaining exactly how their information was used. This small transparency cue tested extremely well in research—it reframed registration from \"data grab\" to \"professional validation.\"<div id='levelex-prototype-container' class='my-8'></div>",
  //     "<h3 class='text-xl md:text-2xl font-display mb-6 mt-12 text-accent-violet'>2. Streamlining the Registration Experience</h3>",
  //     "Next, we simplified and standardized the entire flow. Working closely with engineering, I led design of the Unified Registration System (URS)—a reusable Unity module shared across all Level Ex titles. Each game could keep its own visual identity while inheriting the same structure, logic, and analytics events.",
  //     "We removed redundant fields, added intelligent defaults, and condensed the process into two short screens. The flow validated NPI information in real time, using a mirrored NPI database built in-house for reliability. This decision extended the build timeline but dramatically improved system stability and allowed registration to function even when the government registry was offline.",
  //     "<h3 class='text-xl md:text-2xl font-display mb-6 mt-12 text-accent-violet'>3. Letting Players Try Before They Commit</h3>",
  //     "Many physicians wanted to sample gameplay before registering. To meet that expectation, we redesigned onboarding so players could start a mission immediately and register once they understood the game's value.",
  //     "This \"play-now, register-later\" model reduced initial friction while capturing higher-intent players post-session. We also treated registration as a brief tone shift—a calm, professional pause before returning to play. Clean layouts, slower transitions, and reassuring copy emphasized credibility without breaking immersion.",
  //     "<h3 class='text-xl md:text-2xl font-display mb-6 mt-12 text-accent-violet'>Continuous Testing and Refinement</h3>",
  //     "Throughout implementation, we ran iterative usability sessions with practicing physicians, refining validation states, messaging, and visual tone. Each test helped balance the seriousness of professional verification with the playfulness of the medium—making the flow both trustworthy and approachable."
  //   ],
  //   impact: {
  //     business: [
  //       "Registration completion increased from 29% → 83% among players who started the process",
  //       "Verified user data unlocked personalization and targeting, improving both player engagement and sponsor ROI",
  //       "Support tickets related to login and registration dropped by 40%",
  //       "Engineering stability improved, with no downtime from external registry dependencies",
  //       "The mirror database became a shared service supporting future Level Ex titles and growth initiatives"
  //     ]
  //   }
  // },
  {
    id: 6,
    title: "Scene+ Banking",
    tagline: "Designing a modern banking experience integrated with Canada's leading loyalty rewards program",
    image: "/pexels-silverkblack-36697453.webp",
    tags: ["Loyalty & Rewards", "Fintech", "Banking"],
    challenge: [
      "Scene+ is a rewards and loyalty program that partners with Scotiabank, allowing rewards members who also use Scotiabank cards to double or even triple their points. With the addition of Tangerine — a more accessible, fully online bank — Scene+ and its banking partners wanted to redesign the experience for discovering which cards work with the rewards program.",
      "The core challenge was twofold: introduce both banks to rewards members who may be unfamiliar with one or both of them, and give each bank a dedicated space that reflects its unique identity and card offerings — while making the synergy between the banks and the Scene+ program feel intuitive and compelling."
    ],
    solution: [
      "To kick off the project, I conducted stakeholder interviews across both Scene+ and the partner banks to align on product requirements and build a shared understanding of the problem space. Alongside those conversations, I reviewed existing user feedback and support data tied to the current banking page. The signal was consistent: users felt the experience was foreign to the Scene+ ecosystem — it loaded inside an iframe, carried a completely different visual language, and required significantly more effort to compare and select a card than felt reasonable. Words like <em>\"confusing\"</em>, <em>\"clunky\"</em>, and <em>\"doesn't feel like Scene+\"</em> surfaced repeatedly. What emerged was a clear picture of the friction in the existing experience: the card-finder had been inherited from the bank itself — dense with copy, heavily interactive, and designed in isolation from the rewards program's identity.",
      "The experience felt transactional rather than relational. It dropped members into unfamiliar bank territory without context, leaving them without a sense of how the bank and Scene+ worked together. The partners wanted something fundamentally different — a flow that moved seamlessly between the Scene+ ecosystem and each bank's world, building brand trust progressively so that members could understand the relationship, feel confident in their options, and ultimately feel excited about applying for a card that would meaningfully enhance their rewards."
    ],
    implementation: [
      "__scene_filter_table__"
    ],
    impact: {
      business: []
    }
  },
];