import React, { createContext, useCallback, useContext, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { CaseStudy } from '../types';
import { slugify } from '../utils/slugify';

interface NavigationContextValue {
  allCaseStudies: CaseStudy[];
  currentCaseStudy: CaseStudy | null;
  currentIndex: number;
  nextCaseStudy: CaseStudy | null;
  previousCaseStudy: CaseStudy | null;
  isTransitioning: boolean;
  goHome: () => Promise<void>;
  goToCaseStudy: (study: CaseStudy) => Promise<void>;
  goToFirstCaseStudy: () => Promise<void>;
}

const NavigationContext = createContext<NavigationContextValue | null>(null);

interface ProviderProps {
  allCaseStudies: CaseStudy[];
  children: React.ReactNode;
}

export const NavigationProvider = ({ allCaseStudies, children }: ProviderProps) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isTransitioning, setIsTransitioning] = useState(false);

  const { currentCaseStudy, currentIndex, nextCaseStudy, previousCaseStudy } = useMemo(() => {
    const match = location.pathname.match(/^\/case-study\/(.+)$/);
    if (!match) {
      return {
        currentCaseStudy: null,
        currentIndex: -1,
        nextCaseStudy: allCaseStudies[0] ?? null,
        previousCaseStudy: null,
      };
    }
    const slug = match[1];
    const idx = allCaseStudies.findIndex((s) => slugify(s.title) === slug);
    if (idx === -1) {
      return {
        currentCaseStudy: null,
        currentIndex: -1,
        nextCaseStudy: allCaseStudies[0] ?? null,
        previousCaseStudy: null,
      };
    }
    const total = allCaseStudies.length;
    return {
      currentCaseStudy: allCaseStudies[idx],
      currentIndex: idx,
      nextCaseStudy: allCaseStudies[(idx + 1) % total],
      previousCaseStudy: allCaseStudies[(idx - 1 + total) % total],
    };
  }, [location.pathname, allCaseStudies]);

  const runWithTransition = useCallback(async (action: () => void) => {
    setIsTransitioning(true);
    await new Promise((r) => setTimeout(r, 300));
    action();
    window.scrollTo(0, 0);
    await new Promise((r) => setTimeout(r, 50));
    setIsTransitioning(false);
  }, []);

  const goHome = useCallback(async () => {
    if (location.pathname === '/') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    await runWithTransition(() => navigate('/'));
  }, [location.pathname, navigate, runWithTransition]);

  const goToCaseStudy = useCallback(
    async (study: CaseStudy) => {
      await runWithTransition(() => navigate(`/case-study/${slugify(study.title)}`));
    },
    [navigate, runWithTransition]
  );

  const goToFirstCaseStudy = useCallback(async () => {
    const first = allCaseStudies[0];
    if (!first) return;
    await goToCaseStudy(first);
  }, [allCaseStudies, goToCaseStudy]);

  const value: NavigationContextValue = {
    allCaseStudies,
    currentCaseStudy,
    currentIndex,
    nextCaseStudy,
    previousCaseStudy,
    isTransitioning,
    goHome,
    goToCaseStudy,
    goToFirstCaseStudy,
  };

  return <NavigationContext.Provider value={value}>{children}</NavigationContext.Provider>;
};

export const useNavigation = () => {
  const ctx = useContext(NavigationContext);
  if (!ctx) throw new Error('useNavigation must be used within NavigationProvider');
  return ctx;
};
