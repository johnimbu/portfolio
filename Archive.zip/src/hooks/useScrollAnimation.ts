import { useEffect } from 'react';

export const useScrollAnimation = () => {
  useEffect(() => {
    const animateElements = () => {
      const elements = document.querySelectorAll('.animate-on-scroll');
      
      elements.forEach((element) => {
        const elementPosition = element.getBoundingClientRect().top;
        const windowHeight = window.innerHeight;
        
        // If element is in viewport
        if (elementPosition < windowHeight * 0.85) {
          const animationClass = element.getAttribute('data-animation') || 'animate-fade-in';
          element.classList.add(animationClass);
          element.classList.remove('opacity-0');
        }
      });
    };
    
    // Run once on load
    animateElements();
    
    // Run on scroll
    window.addEventListener('scroll', animateElements);
    
    return () => window.removeEventListener('scroll', animateElements);
  }, []);
};