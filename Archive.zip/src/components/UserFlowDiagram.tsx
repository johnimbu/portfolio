import React from 'react';

const CYAN = '#05D9E8';
const GOLD = '#E8A505';
const GREEN = '#22c55e';
const RED = '#ef4444';
const BOX_BG = '#161616';
const BOX_BORDER = 'rgba(255,255,255,0.18)';
const HIGHLIGHT_BG = '#1a3a4a';
const HIGHLIGHT_BORDER = CYAN;

interface Rect { x: number; y: number; w: number; h: number; label: string; sub?: string; color?: string; bgColor?: string; bold?: boolean; }
interface Diamond { x: number; y: number; size: number; label: string; color?: string; }
interface Arrow { x1: number; y1: number; x2: number; y2: number; color?: string; dashed?: boolean; label?: string; labelSide?: 'top' | 'bottom' | 'left' | 'right'; bend?: 'down' | 'up' | 'left' | 'right'; bendMid?: number; }

const BOX_H = 44;
const CARD_BOX_H = 50;
const W_WIDE = 150;
const W_MED = 140;
const W_NARROW = 128;
const CENTER_Y = 100;
const UPPER_Y = 62;
const LOWER_Y = 148;
const UPPER_CARD_Y = 50;
const LOWER_CARD_Y = 160;

const SVG_W = 1940;
const SVG_H = 260;

const UserFlowDiagram: React.FC = () => {
  const userStart = { x: 30, y: CENTER_Y };

  const home: Rect = { x: 80, y: CENTER_Y - BOX_H / 2, w: W_NARROW, h: BOX_H, label: 'Home', color: 'rgba(255,255,255,0.7)', bgColor: BOX_BG };
  const navPay: Rect = { x: 248, y: CENTER_Y - BOX_H / 2, w: W_MED, h: BOX_H, label: 'Nav > Payments', color: CYAN, bgColor: HIGHLIGHT_BG, bold: true };
  const loggedDiamond: Diamond = { x: 450, y: CENTER_Y, size: 40, label: 'Logged\nin?', color: GOLD };

  const payOverviewTop: Rect = { x: 536, y: UPPER_Y - BOX_H / 2, w: W_WIDE, h: BOX_H, label: 'Payments overview', sub: 'Personalized content', color: 'rgba(255,255,255,0.7)', bgColor: BOX_BG };
  const payOverviewBot: Rect = { x: 536, y: LOWER_Y - BOX_H / 2, w: W_WIDE, h: BOX_H, label: 'Payments overview', sub: 'General content', color: 'rgba(255,255,255,0.7)', bgColor: BOX_BG };

  const bnsTop: Rect = { x: 740, y: UPPER_CARD_Y - CARD_BOX_H / 2, w: W_NARROW, h: CARD_BOX_H, label: 'BNS', sub: 'Personalized details', color: 'rgba(255,255,255,0.7)', bgColor: BOX_BG };
  const tngTop: Rect = { x: 740, y: UPPER_Y + 20, w: W_NARROW, h: CARD_BOX_H, label: 'TNG', sub: 'Personalized details', color: 'rgba(255,255,255,0.7)', bgColor: BOX_BG };
  const bnsBot: Rect = { x: 740, y: LOWER_Y - 30, w: W_NARROW, h: CARD_BOX_H, label: 'BNS', sub: 'General card details', color: 'rgba(255,255,255,0.7)', bgColor: BOX_BG };
  const tngBot: Rect = { x: 740, y: LOWER_CARD_Y + 10, w: W_NARROW, h: CARD_BOX_H, label: 'TNG', sub: 'General card details', color: 'rgba(255,255,255,0.7)', bgColor: BOX_BG };

  const HANDOFF_X = 930;

  const cardApp: Rect = { x: 990, y: CENTER_Y - BOX_H / 2, w: W_WIDE, h: BOX_H, label: 'Card application', sub: 'TBD', color: 'rgba(255,255,255,0.7)', bgColor: BOX_BG };
  const thankYouPage: Rect = { x: 1200, y: CENTER_Y - BOX_H / 2, w: W_WIDE, h: BOX_H, label: 'Thank you page', sub: '[Next steps]', color: 'rgba(255,255,255,0.7)', bgColor: BOX_BG };
  const thankYouEmail: Rect = { x: 1415, y: CENTER_Y - BOX_H / 2, w: W_WIDE, h: BOX_H, label: 'Thank you email', sub: '[Next steps]', color: 'rgba(255,255,255,0.7)', bgColor: BOX_BG };
  const approvedDiamond: Diamond = { x: 1630, y: CENTER_Y, size: 44, label: 'Approved?', color: GOLD };

  const approvedEmail: Rect = { x: 1730, y: UPPER_Y - BOX_H / 2, w: W_WIDE, h: BOX_H, label: 'Approved email', sub: '[What to expect…]', color: 'rgba(255,255,255,0.7)', bgColor: BOX_BG };
  const deniedEmail: Rect = { x: 1730, y: LOWER_Y - BOX_H / 2, w: W_WIDE, h: BOX_H, label: 'Denied email', sub: "[What's next…]", color: 'rgba(255,255,255,0.7)', bgColor: BOX_BG };

  const homeCards: Rect = { x: 55, y: 175, w: W_WIDE + 10, h: 52, label: 'Home cards,', sub: 'Category pages and rewards pages', color: 'rgba(255,255,255,0.45)', bgColor: 'transparent' };

  const renderRect = (r: Rect, key: string) => (
    <g key={key}>
      <rect
        x={r.x} y={r.y} width={r.w} height={r.h} rx={6}
        fill={r.bgColor ?? BOX_BG}
        stroke={r.color === CYAN ? HIGHLIGHT_BORDER : BOX_BORDER}
        strokeWidth={r.color === CYAN ? 1.5 : 1}
      />
      <text x={r.x + r.w / 2} y={r.y + (r.sub ? BOX_H / 2 - 5 : BOX_H / 2 + 4)} textAnchor="middle" fill={r.color ?? 'rgba(255,255,255,0.7)'} fontSize={r.bold ? 11 : 10} fontWeight={r.bold ? 700 : 500} fontFamily="system-ui, sans-serif">
        {r.label}
      </text>
      {r.sub && (
        <text x={r.x + r.w / 2} y={r.y + BOX_H / 2 + 10} textAnchor="middle" fill="rgba(255,255,255,0.35)" fontSize={9} fontFamily="system-ui, sans-serif">
          {r.sub}
        </text>
      )}
    </g>
  );

  const renderCardBox = (r: Rect, key: string) => (
    <g key={key}>
      <rect
        x={r.x} y={r.y} width={r.w} height={r.h} rx={6}
        fill={r.bgColor ?? BOX_BG}
        stroke={BOX_BORDER}
        strokeWidth={1}
      />
      <text x={r.x + r.w / 2} y={r.y + 18} textAnchor="middle" fill={r.color ?? 'rgba(255,255,255,0.7)'} fontSize={10} fontWeight={600} fontFamily="system-ui, sans-serif">
        {r.label}
      </text>
      {r.sub && (
        <text x={r.x + r.w / 2} y={r.y + 32} textAnchor="middle" fill="rgba(255,255,255,0.35)" fontSize={9} fontFamily="system-ui, sans-serif">
          {r.sub}
        </text>
      )}
    </g>
  );

  const renderDiamond = (d: Diamond, key: string) => {
    const s = d.size;
    const pts = `${d.x},${d.y - s} ${d.x + s * 1.5},${d.y} ${d.x},${d.y + s} ${d.x - s * 1.5},${d.y}`;
    const lines = d.label.split('\n');
    return (
      <g key={key}>
        <polygon points={pts} fill={`${d.color ?? GOLD}22`} stroke={d.color ?? GOLD} strokeWidth={1.5} />
        {lines.map((line, i) => (
          <text key={i} x={d.x} y={d.y + (lines.length === 1 ? 4 : i === 0 ? -2 : 12)} textAnchor="middle" fill={d.color ?? GOLD} fontSize={9} fontWeight={600} fontFamily="system-ui, sans-serif">
            {line}
          </text>
        ))}
      </g>
    );
  };

  const arrowHead = (x: number, y: number, dir: 'right' | 'left' | 'down' | 'up' = 'right', color = 'rgba(255,255,255,0.3)') => {
    const size = 5;
    let pts = '';
    if (dir === 'right') pts = `${x},${y - size / 2} ${x + size},${y} ${x},${y + size / 2}`;
    if (dir === 'left') pts = `${x},${y - size / 2} ${x - size},${y} ${x},${y + size / 2}`;
    if (dir === 'down') pts = `${x - size / 2},${y} ${x},${y + size} ${x + size / 2},${y}`;
    if (dir === 'up') pts = `${x - size / 2},${y} ${x},${y - size} ${x + size / 2},${y}`;
    return <polygon points={pts} fill={color} />;
  };

  return (
    <svg
      width={SVG_W}
      height={SVG_H}
      viewBox={`0 0 ${SVG_W} ${SVG_H}`}
      style={{ display: 'block', userSelect: 'none' }}
    >
      <defs>
        <marker id="arrowRight" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
          <path d="M0,0 L6,3 L0,6 Z" fill="rgba(255,255,255,0.3)" />
        </marker>
        <marker id="arrowRightGold" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
          <path d="M0,0 L6,3 L0,6 Z" fill={GOLD} />
        </marker>
        <marker id="arrowRightGreen" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
          <path d="M0,0 L6,3 L0,6 Z" fill={GREEN} />
        </marker>
        <marker id="arrowRightRed" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
          <path d="M0,0 L6,3 L0,6 Z" fill={RED} />
        </marker>
        <marker id="arrowDown" markerWidth="6" markerHeight="6" refX="3" refY="5" orient="auto">
          <path d="M0,0 L3,6 L6,0 Z" fill="rgba(255,255,255,0.3)" />
        </marker>
      </defs>

      {/* User Start person icon */}
      <circle cx={userStart.x} cy={userStart.y - 14} r={9} fill="none" stroke={CYAN} strokeWidth={1.5} />
      <path d={`M${userStart.x - 12},${userStart.y + 14} Q${userStart.x - 12},${userStart.y} ${userStart.x},${userStart.y} Q${userStart.x + 12},${userStart.y} ${userStart.x + 12},${userStart.y + 14}`} fill="none" stroke={CYAN} strokeWidth={1.5} />
      <text x={userStart.x} y={userStart.y + 30} textAnchor="middle" fill={CYAN} fontSize={9} fontFamily="system-ui, sans-serif">User Start</text>

      {/* Person → Home */}
      <line x1={userStart.x + 14} y1={CENTER_Y} x2={home.x - 4} y2={CENTER_Y} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} markerEnd="url(#arrowRight)" />

      {/* Home → Nav>Payments */}
      <line x1={home.x + home.w} y1={CENTER_Y} x2={navPay.x - 4} y2={CENTER_Y} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} markerEnd="url(#arrowRight)" />

      {/* Nav>Payments → Logged in? diamond */}
      <line x1={navPay.x + navPay.w} y1={CENTER_Y} x2={loggedDiamond.x - loggedDiamond.size * 1.5 - 4} y2={CENTER_Y} stroke={CYAN} strokeWidth={1.2} markerEnd="url(#arrowRight)" />

      {/* "no" label on down branch from diamond */}
      <text x={loggedDiamond.x - 2} y={loggedDiamond.y + loggedDiamond.size + 14} textAnchor="middle" fill="rgba(255,255,255,0.35)" fontSize={9} fontFamily="system-ui, sans-serif">no</text>
      {/* "yes" label on up branch */}
      <text x={loggedDiamond.x - 2} y={loggedDiamond.y - loggedDiamond.size - 6} textAnchor="middle" fill="rgba(255,255,255,0.35)" fontSize={9} fontFamily="system-ui, sans-serif">yes</text>

      {/* Diamond → Payments Overview Top (yes / up) */}
      <line x1={loggedDiamond.x} y1={loggedDiamond.y - loggedDiamond.size} x2={loggedDiamond.x} y2={UPPER_Y} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} />
      <line x1={loggedDiamond.x} y1={UPPER_Y} x2={payOverviewTop.x - 4} y2={UPPER_Y} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} markerEnd="url(#arrowRight)" />

      {/* Diamond → Payments Overview Bottom (no / down) */}
      <line x1={loggedDiamond.x} y1={loggedDiamond.y + loggedDiamond.size} x2={loggedDiamond.x} y2={LOWER_Y} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} />
      <line x1={loggedDiamond.x} y1={LOWER_Y} x2={payOverviewBot.x - 4} y2={LOWER_Y} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} markerEnd="url(#arrowRight)" />

      {/* Payments Overview Top → BNS Top */}
      {(() => {
        const midY = (UPPER_Y + UPPER_CARD_Y) / 2;
        const fromX = payOverviewTop.x + payOverviewTop.w;
        const toX = bnsTop.x - 4;
        return <>
          <line x1={fromX} y1={UPPER_Y} x2={fromX + 20} y2={UPPER_Y} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} />
          <line x1={fromX + 20} y1={UPPER_Y} x2={fromX + 20} y2={UPPER_CARD_Y} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} />
          <line x1={fromX + 20} y1={UPPER_CARD_Y} x2={toX} y2={UPPER_CARD_Y} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} markerEnd="url(#arrowRight)" />
        </>;
      })()}

      {/* Payments Overview Top → TNG Top */}
      {(() => {
        const fromX = payOverviewTop.x + payOverviewTop.w;
        const tngMidY = tngTop.y + CARD_BOX_H / 2;
        return <>
          <line x1={fromX} y1={UPPER_Y} x2={fromX + 20} y2={UPPER_Y} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} />
          <line x1={fromX + 20} y1={UPPER_Y} x2={fromX + 20} y2={tngMidY} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} />
          <line x1={fromX + 20} y1={tngMidY} x2={bnsTop.x - 4} y2={tngMidY} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} markerEnd="url(#arrowRight)" />
        </>;
      })()}

      {/* Payments Overview Bot → BNS Bot */}
      {(() => {
        const fromX = payOverviewBot.x + payOverviewBot.w;
        const bnsMidY = bnsBot.y + CARD_BOX_H / 2;
        return <>
          <line x1={fromX} y1={LOWER_Y} x2={fromX + 20} y2={LOWER_Y} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} />
          <line x1={fromX + 20} y1={LOWER_Y} x2={fromX + 20} y2={bnsMidY} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} />
          <line x1={fromX + 20} y1={bnsMidY} x2={bnsBot.x - 4} y2={bnsMidY} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} markerEnd="url(#arrowRight)" />
        </>;
      })()}

      {/* Payments Overview Bot → TNG Bot */}
      {(() => {
        const fromX = payOverviewBot.x + payOverviewBot.w;
        const tngMidY = tngBot.y + CARD_BOX_H / 2;
        return <>
          <line x1={fromX + 20} y1={tngMidY} x2={bnsBot.x - 4} y2={tngMidY} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} markerEnd="url(#arrowRight)" />
        </>;
      })()}

      {/* Dashed Handoff vertical line */}
      <line x1={HANDOFF_X} y1={20} x2={HANDOFF_X} y2={SVG_H - 20} stroke={CYAN} strokeWidth={1.2} strokeDasharray="5 4" opacity={0.45} />
      <text x={HANDOFF_X + 6} y={30} fill={CYAN} fontSize={9} fontWeight={600} fontFamily="system-ui, sans-serif" opacity={0.7}>Handoff</text>

      {/* All 4 card boxes → merge to center → Card Application */}
      {(() => {
        const bnsMidY1 = bnsTop.y + CARD_BOX_H / 2;
        const tngMidY1 = tngTop.y + CARD_BOX_H / 2;
        const bnsMidY2 = bnsBot.y + CARD_BOX_H / 2;
        const tngMidY2 = tngBot.y + CARD_BOX_H / 2;
        const mergeX = HANDOFF_X - 10;
        const appMidY = CENTER_Y;
        return <>
          {/* BNS top → merge */}
          <line x1={bnsTop.x + W_NARROW} y1={bnsMidY1} x2={mergeX} y2={bnsMidY1} stroke="rgba(255,255,255,0.2)" strokeWidth={1.2} />
          <line x1={mergeX} y1={bnsMidY1} x2={mergeX} y2={appMidY} stroke="rgba(255,255,255,0.2)" strokeWidth={1.2} />
          {/* TNG top → merge */}
          <line x1={bnsTop.x + W_NARROW} y1={tngMidY1} x2={mergeX} y2={tngMidY1} stroke="rgba(255,255,255,0.2)" strokeWidth={1.2} />
          <line x1={mergeX} y1={tngMidY1} x2={mergeX} y2={appMidY} stroke="rgba(255,255,255,0.2)" strokeWidth={1.2} />
          {/* BNS bot → merge */}
          <line x1={bnsBot.x + W_NARROW} y1={bnsMidY2} x2={mergeX} y2={bnsMidY2} stroke="rgba(255,255,255,0.2)" strokeWidth={1.2} />
          <line x1={mergeX} y1={bnsMidY2} x2={mergeX} y2={appMidY} stroke="rgba(255,255,255,0.2)" strokeWidth={1.2} />
          {/* TNG bot → merge */}
          <line x1={bnsBot.x + W_NARROW} y1={tngMidY2} x2={mergeX} y2={tngMidY2} stroke="rgba(255,255,255,0.2)" strokeWidth={1.2} />
          <line x1={mergeX} y1={tngMidY2} x2={mergeX} y2={appMidY} stroke="rgba(255,255,255,0.2)" strokeWidth={1.2} />
          {/* merge → card app */}
          <line x1={mergeX} y1={appMidY} x2={cardApp.x - 4} y2={appMidY} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} markerEnd="url(#arrowRight)" />
        </>;
      })()}

      {/* Card App → Thank You Page */}
      <line x1={cardApp.x + cardApp.w} y1={CENTER_Y} x2={thankYouPage.x - 4} y2={CENTER_Y} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} markerEnd="url(#arrowRight)" />

      {/* Gear/settings icon between thank you page and email (represents processing) */}
      {(() => {
        const gx = (thankYouPage.x + thankYouPage.w + thankYouEmail.x) / 2;
        return <text x={gx} y={CENTER_Y + 5} textAnchor="middle" fill="rgba(255,255,255,0.2)" fontSize={12} fontFamily="system-ui, sans-serif">⚙</text>;
      })()}

      {/* Thank You Page → Thank You Email */}
      <line x1={thankYouPage.x + thankYouPage.w} y1={CENTER_Y} x2={thankYouEmail.x - 4} y2={CENTER_Y} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} markerEnd="url(#arrowRight)" />

      {/* Thank You Email → Approved? diamond */}
      <line x1={thankYouEmail.x + thankYouEmail.w} y1={CENTER_Y} x2={approvedDiamond.x - approvedDiamond.size * 1.5 - 4} y2={CENTER_Y} stroke="rgba(255,255,255,0.25)" strokeWidth={1.2} markerEnd="url(#arrowRight)" />

      {/* Approved diamond → Approved email (yes/up) */}
      <line x1={approvedDiamond.x} y1={approvedDiamond.y - approvedDiamond.size} x2={approvedDiamond.x} y2={UPPER_Y} stroke={GREEN} strokeWidth={1.2} opacity={0.7} />
      <line x1={approvedDiamond.x} y1={UPPER_Y} x2={approvedEmail.x - 4} y2={UPPER_Y} stroke={GREEN} strokeWidth={1.2} opacity={0.7} markerEnd="url(#arrowRightGreen)" />
      <text x={approvedDiamond.x + 6} y={approvedDiamond.y - approvedDiamond.size - 6} fill={GREEN} fontSize={9} fontFamily="system-ui, sans-serif" opacity={0.7}>yes</text>

      {/* Approved diamond → Denied email (no/down) */}
      <line x1={approvedDiamond.x} y1={approvedDiamond.y + approvedDiamond.size} x2={approvedDiamond.x} y2={LOWER_Y} stroke={RED} strokeWidth={1.2} opacity={0.6} />
      <line x1={approvedDiamond.x} y1={LOWER_Y} x2={deniedEmail.x - 4} y2={LOWER_Y} stroke={RED} strokeWidth={1.2} opacity={0.6} markerEnd="url(#arrowRightRed)" />
      <text x={approvedDiamond.x + 6} y={approvedDiamond.y + approvedDiamond.size + 14} fill={RED} fontSize={9} fontFamily="system-ui, sans-serif" opacity={0.7}>no</text>

      {/* Home Cards curved annotation below */}
      <rect x={homeCards.x} y={homeCards.y} width={homeCards.w} height={homeCards.h} rx={5} fill="transparent" stroke="rgba(255,255,255,0.12)" strokeWidth={1} strokeDasharray="3 3" />
      <text x={homeCards.x + homeCards.w / 2} y={homeCards.y + 18} textAnchor="middle" fill="rgba(255,255,255,0.35)" fontSize={9} fontFamily="system-ui, sans-serif">{homeCards.label}</text>
      <text x={homeCards.x + homeCards.w / 2} y={homeCards.y + 30} textAnchor="middle" fill="rgba(255,255,255,0.25)" fontSize={8.5} fontFamily="system-ui, sans-serif">Category pages and</text>
      <text x={homeCards.x + homeCards.w / 2} y={homeCards.y + 41} textAnchor="middle" fill="rgba(255,255,255,0.25)" fontSize={8.5} fontFamily="system-ui, sans-serif">rewards pages</text>
      {/* Curved bracket from home cards to home box */}
      <path d={`M${homeCards.x + homeCards.w / 2},${homeCards.y} Q${home.x + home.w / 2},${homeCards.y - 10} ${home.x + home.w / 2},${home.y + home.h}`} fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth={1} strokeDasharray="3 3" markerEnd="url(#arrowDown)" />

      {/* Render all boxes */}
      {renderRect(home, 'home')}
      {renderRect(navPay, 'navPay')}
      {renderDiamond(loggedDiamond, 'logged')}
      {renderRect(payOverviewTop, 'pot')}
      {renderRect(payOverviewBot, 'pob')}
      {renderCardBox(bnsTop, 'bnsTop')}
      {renderCardBox(tngTop, 'tngTop')}
      {renderCardBox(bnsBot, 'bnsBot')}
      {renderCardBox(tngBot, 'tngBot')}
      {renderRect(cardApp, 'cardApp')}
      {renderRect(thankYouPage, 'typ')}
      {renderRect(thankYouEmail, 'tye')}
      {renderDiamond(approvedDiamond, 'approved')}
      {renderRect(approvedEmail, 'approvedEmail')}
      {renderRect(deniedEmail, 'deniedEmail')}
    </svg>
  );
};

export default UserFlowDiagram;
