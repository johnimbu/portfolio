import React from 'react';

interface ButtonProps {
  children: React.ReactNode;
  type?: 'button' | 'submit' | 'reset';
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  disabled?: boolean;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
}

const Button = ({
  children,
  type = 'button',
  variant = 'primary',
  size = 'md',
  className = '',
  onClick,
  disabled = false,
  icon,
  iconPosition = 'left',
}: ButtonProps) => {
  const baseClasses = "relative inline-flex items-center justify-center font-medium rounded-full transition-all duration-300 group whitespace-nowrap";
  
  const variantClasses = {
    primary: "bg-cobalt text-cream border border-cobalt hover:bg-cobalt-deep hover:border-cobalt-deep focus:bg-cobalt-deep font-display font-bold tracking-wide",
    secondary: "bg-transparent text-cobalt border border-cobalt hover:bg-cobalt hover:text-cream focus:bg-cobalt focus:text-cream font-display font-bold tracking-wide",
    outline: "bg-transparent text-ink border border-ink/30 hover:border-ink hover:text-ink font-sans",
  };
  
  const sizeClasses = {
    sm: "py-1.5 px-3 text-sm",
    md: "py-2 px-5 text-base",
    lg: "py-3 px-6 text-lg",
  };

  const buttonClasses = `
    ${baseClasses}
    ${variantClasses[variant]}
    ${sizeClasses[size]}
    ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
    ${className}
  `;

  const textureClasses = ``;

  return (
    <button
      type={type}
      className={`${buttonClasses} ${textureClasses}`}
      onClick={onClick}
      disabled={disabled}
    >
      {icon && iconPosition === 'left' && <span className="mr-2">{icon}</span>}
      <span className="relative z-10">{children}</span>
      {icon && iconPosition === 'right' && <span className="ml-2">{icon}</span>}
      
    </button>
  );
};

export default Button;