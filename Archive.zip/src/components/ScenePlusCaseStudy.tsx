import React, { useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, ChevronUp, ChevronDown, Maximize2 } from 'lucide-react';
import { CaseStudy } from '../types';
import ImageModal from './ImageModal';
import MobileMediaThumb from './MobileMediaThumb';

interface ScenePlusCaseStudyProps {
  caseStudy: CaseStudy;
  onBack: () => void;
  onNextCaseStudy: (nextStudy: CaseStudy) => void;
  allCaseStudies: CaseStudy[];
}

interface Slide {
  id: string;
  chapter: 'Discovery' | 'Implementation' | 'Results' | null;
}

const slides: Slide[] = [
  { id: 'hero', chapter: null },
  { id: 'problem', chapter: 'Discovery' },
  { id: 'workshop', chapter: 'Discovery' },
  { id: 'hero-landing', chapter: 'Implementation' },
  { id: 'filter-table', chapter: 'Implementation' },
  { id: 'iterative-process', chapter: 'Implementation' },
  { id: 'breakpoints', chapter: 'Implementation' },
  { id: 'results', chapter: 'Results' },
];

const CHAPTER_COLORS: Record<string, string> = {
  Discovery: 'text-accent-teal/80',
  Implementation: 'text-accent-teal/60',
  Results: 'text-amber-400/80',
};

const ExpandBadge = () => (
  <div className="absolute top-3 right-3 z-10 p-1.5 rounded-full bg-cosmic-black/70 backdrop-blur-sm border border-white/15 text-white/75 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none">
    <Maximize2 size={14} />
  </div>
);

const StandaloneCaption = ({ text }: { text: string }) => (
  <div className="mt-4 text-center">
    <span className="text-cream/40 text-xs tracking-wide font-sans">{text}</span>
  </div>
);

const ScenePlusCaseStudy = ({
  caseStudy,
  onBack,
  onNextCaseStudy,
  allCaseStudies,
}: ScenePlusCaseStudyProps) => {
  const currentIndex = allCaseStudies.findIndex((s) => s.id === caseStudy.id);
  const nextCaseStudy = allCaseStudies[(currentIndex + 1) % allCaseStudies.length];
  const previousCaseStudy =
    allCaseStudies[(currentIndex - 1 + allCaseStudies.length) % allCaseStudies.length];

  const [activeSlide, setActiveSlide] = useState(0);
  const [selectedImage, setSelectedImage] = useState<{ src: string; alt: string } | null>(null);
  const [selectedImageIndex, setSelectedImageIndex] = useState(-1);
  const [activeGallery, setActiveGallery] = useState<{ src: string; alt: string }[]>([]);
  const [activeTitle, setActiveTitle] = useState<string | null>(null);
  const [workshopCarouselIndex, setWorkshopCarouselIndex] = useState(0);
  const [heroLandingCarouselIndex, setHeroLandingCarouselIndex] = useState(0);
  const [resultsCarouselIndex, setResultsCarouselIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const slideRefs = useRef<(HTMLElement | null)[]>([]);

  const workshopImages = [
    { src: '/uj.webp', alt: 'User Journey Map — cross-org alignment artifact' },
    { src: '/brd.png', alt: 'Business Requirements Document — member comprehension focus' },
  ];

  const heroLandingImages = [
    { src: '/2-banks-1-reward-program.gif', alt: 'Two banks, one rewards program landing page' },
    { src: '/feature-toggle.gif', alt: 'Scene+ bank switcher interaction' },
  ];

  const resultsImages = [
    { src: '/scene-results-1.png', alt: 'User testing results — design variants' },
    { src: '/scene-results-2.png', alt: 'User testing results — preference data' },
    { src: '/scene-results-3.png', alt: 'User testing results — comprehension findings' },
    { src: '/scene-results-4.png', alt: 'User testing results — stakeholder alignment' },
  ];

  const gallery = [
    { src: '/scene-banking_current.png', alt: 'Current Scene+ Banking Experience' },
    { src: '/2-banks-1-reward-program.gif', alt: 'Two banks, one rewards program landing page' },
    { src: '/feature-toggle.gif', alt: 'Scene+ feature toggle interaction' },
    { src: '/filter-table-highlighter.gif', alt: 'Scene+ card filter and comparison table' },
    { src: '/iterative-process.webp', alt: 'Iterative design process' },
    { src: '/scene_banking_mobile-responsive-2.png', alt: 'Scene+ Banking — web and mobile responsive design' },
  ];

  useEffect(() => {
    document.title = `John Imburgia | ${caseStudy.title}`;
    return () => {
      document.title = 'John Imburgia: UX Design Leader';
    };
  }, [caseStudy.title]);

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  useEffect(() => {
    const observers: IntersectionObserver[] = [];
    slideRefs.current.forEach((el, i) => {
      if (!el) return;
      const obs = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) setActiveSlide(i);
        },
        { threshold: 0.5 }
      );
      obs.observe(el);
      observers.push(obs);
    });
    return () => observers.forEach((o) => o.disconnect());
  }, []);

  const openImage = (
    src: string,
    alt: string,
    group?: { src: string; alt: string }[],
    title?: string
  ) => {
    const g = group ?? gallery;
    const idx = g.findIndex((item) => item.src === src);
    setActiveGallery(g);
    setSelectedImageIndex(idx);
    setSelectedImage({ src, alt });
    setActiveTitle(title ?? null);
  };

  const handlePrev = () => {
    if (selectedImageIndex > 0) {
      const i = selectedImageIndex - 1;
      setSelectedImageIndex(i);
      setSelectedImage(activeGallery[i]);
    }
  };

  const handleNext = () => {
    if (selectedImageIndex < activeGallery.length - 1) {
      const i = selectedImageIndex + 1;
      setSelectedImageIndex(i);
      setSelectedImage(activeGallery[i]);
    }
  };

  const scrollTo = (i: number) => {
    const el = slideRefs.current[i];
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (selectedImage) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        onNextCaseStudy(previousCaseStudy);
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        onNextCaseStudy(nextCaseStudy);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        if (activeSlide > 0) scrollTo(activeSlide - 1);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (activeSlide < slides.length - 1) scrollTo(activeSlide + 1);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedImage, activeSlide, onNextCaseStudy, nextCaseStudy, previousCaseStudy]);

  const setRef = (i: number) => (el: HTMLElement | null) => {
    slideRefs.current[i] = el;
  };

  return (
    <div className="relative">
      {/* Slide navigator pill */}
      <div className="hidden md:flex fixed right-6 top-1/2 -translate-y-1/2 z-40 flex-col items-center rounded-full border border-cream/20 bg-cosmic-black/50 backdrop-blur-sm overflow-hidden">
        <button
          onClick={() => scrollTo(activeSlide - 1)}
          disabled={activeSlide === 0}
          aria-label="Previous slide"
          className="p-2.5 text-cream/50 hover:text-cream disabled:opacity-20 disabled:pointer-events-none transition-colors duration-150"
        >
          <ChevronUp size={14} />
        </button>

        <span className="w-px self-stretch bg-cream/15" />

        <span className="px-2.5 py-2 text-cream/50 text-xs tabular-nums font-mono leading-none">
          {activeSlide + 1}<span className="text-cream/20 mx-0.5">/</span>{slides.length}
        </span>

        <span className="w-px self-stretch bg-cream/15" />

        <button
          onClick={() => scrollTo(activeSlide + 1)}
          disabled={activeSlide === slides.length - 1}
          aria-label="Next slide"
          className="p-2.5 text-cream/50 hover:text-cream disabled:opacity-20 disabled:pointer-events-none transition-colors duration-150"
        >
          <ChevronDown size={14} />
        </button>
      </div>

      {/* Scroll container */}
      <div
        ref={containerRef}
        className="slide-scroll h-screen overflow-y-scroll no-scrollbar"
      >
        {/* ─── Slide 0: Hero ─────────────────────────────────────── */}
        <section
          ref={setRef(0)}
          className="slide-section relative min-h-screen flex items-center bg-cosmic-black py-20 md:py-0"
        >
          <div
            className="absolute inset-0 bg-cover bg-center opacity-30"
            style={{
              backgroundImage: `url(/pexels-silverkblack-36697453.webp)`,
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-cosmic-black/20 via-transparent to-cosmic-black" />
          <div className="relative z-10 container mx-auto px-4 md:px-8">
            <div className="flex flex-wrap gap-2 mb-6 md:mb-8">
              {caseStudy.tags.map((tag) => (
                <span
                  key={tag}
                  className="text-[10px] md:text-xs font-sans font-600 tracking-widest uppercase text-cream/50 border border-cream/15 rounded-full px-2.5 py-1"
                >
                  {tag}
                </span>
              ))}
            </div>
            <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-display font-bold text-cream leading-none mb-5 md:mb-6" style={{ letterSpacing: '-0.04em' }}>
              {caseStudy.title}
            </h1>
            <p className="text-lg sm:text-xl md:text-2xl text-cream/60 max-w-2xl leading-relaxed mb-10 md:mb-12 font-sans">
              {caseStudy.tagline}
            </p>
            <div className="flex items-center gap-2">
              <span className="text-cream/40 text-xs md:text-sm font-sans tracking-wider uppercase" style={{ letterSpacing: '0.18em' }}>My Role</span>
              <span className="text-cream/30 text-xs md:text-sm">/</span>
              <span className="text-cream text-xs md:text-sm font-display font-bold">Lead Product Designer</span>
            </div>
          </div>

        </section>

        {/* ─── Slide 1: The Problem ───────────────────────────────── */}
        <section
          ref={setRef(1)}
          className="slide-section min-h-screen bg-cosmic-black"
        >
          <div className="container mx-auto px-4 md:px-8 min-h-screen grid grid-cols-1 md:grid-cols-2">
            <div className="flex flex-col justify-center pt-20 pb-10 md:py-24">
              <ChapterLabel chapter="Discovery" animated>Discovery</ChapterLabel>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-display font-bold text-cream mb-6 md:mb-8 leading-tight">
                The Problem
              </h2>
              <div className="space-y-4 md:space-y-5 text-cream/70 text-base md:text-lg leading-relaxed max-w-lg font-sans">
                <p>
                  Scene+ members with a Scotiabank or Tangerine card can double or triple their
                  points, but finding the right card meant navigating a clunky iframe pulled in from
                  the bank. It had nothing to do with Scene+. Feedback was consistent:{' '}
                  <em className="text-cream/90 not-italic font-medium">"confusing"</em>,{' '}
                  <em className="text-cream/90 not-italic font-medium">"clunky"</em>,{' '}
                  <em className="text-cream/90 not-italic font-medium">"doesn't feel like Scene+"</em>.
                </p>
                <p>
                  I audited the current experience against benchmarks to map every gap, then ran
                  stakeholder interviews across Scene+, Scotiabank, and Tangerine to align on what
                  members actually needed.
                </p>
              </div>
              <MobileMediaThumb
                items={[{ src: '/scene-banking_current.png', alt: 'Current Scene+ Banking Experience' }]}
                caption="Current Scene+ Banking Experience"
                before
                onOpen={(src, alt, group) => openImage(src, alt, group, 'The Problem')}
              />
            </div>
            <div
              className="hidden md:flex flex-col justify-center bg-cosmic-dark/20 pl-8 py-12 cursor-pointer group overflow-hidden"
              onClick={() => openImage('/scene-banking_current.png', 'Current Scene+ Banking Experience', undefined, 'The Problem')}
            >
              <div className="relative w-full rounded-xl overflow-hidden border border-red-500/20 shadow-2xl">
                <div className="absolute top-3 left-3 z-10">
                  <span className="text-xs font-semibold uppercase tracking-widest px-2.5 py-1 rounded-full bg-red-900/60 border border-red-500/40 text-red-300">
                    Before
                  </span>
                </div>
                <img
                  src="/scene-banking_current.png"
                  alt="Current Scene+ Banking Experience"
                  className="w-full transition-transform duration-500 group-hover:scale-105"
                  style={{ objectFit: 'cover', objectPosition: 'top', maxHeight: '520px' }}
                />
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-cosmic-black/50 pointer-events-none" />
                <ExpandBadge />
              </div>
              <StandaloneCaption text="Current Scene+ Banking Experience" />
            </div>
          </div>
        </section>

        {/* ─── Slide 2: Workshop & Alignment ──────────────────────── */}
        <section
          ref={setRef(2)}
          className="slide-section min-h-screen bg-cosmic-black"
        >
          <div className="container mx-auto px-4 md:px-8 min-h-screen grid grid-cols-1 md:grid-cols-2">
            <div className="flex flex-col justify-center pt-20 pb-10 md:py-24">
              <ChapterLabel chapter="Discovery">Discovery</ChapterLabel>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-display font-bold text-cream mb-6 md:mb-8 leading-tight">
                Workshop &amp; Alignment
              </h2>
              <div className="space-y-4 md:space-y-5 text-cream/70 text-base md:text-lg leading-relaxed max-w-lg font-sans">
                <p>
                  I ran a cross-functional alignment workshop with brand reps from Scene+, Scotiabank,
                  and Tangerine. All three teams co-authored the experience rather than just reviewing it.
                </p>
                <p>
                  We produced two artifacts: a <span className="text-cream/90 font-medium">User Journey Map</span> capturing
                  the end-to-end member experience across all three brands, and a <span className="text-cream/90 font-medium">Business
                  Requirements Document</span> that locked in scope and success criteria. Both kept member
                  comprehension as the primary focus.
                </p>
              </div>
              <MobileMediaThumb
                items={workshopImages}
                caption="Workshop artifacts: Journey Map + BRD"
                onOpen={(src, alt, group) => openImage(src, alt, group, 'Workshop & Alignment')}
              />
            </div>

            {/* Carousel */}
            <div className="hidden md:flex flex-col justify-center bg-cosmic-dark/20 pl-8 py-12 overflow-hidden relative">
              <div className="relative overflow-hidden">
                <div
                  className="flex transition-transform duration-500 ease-in-out"
                  style={{ transform: `translateX(calc(-${workshopCarouselIndex * 85}% - ${workshopCarouselIndex * 12}px))` }}
                >
                  {workshopImages.map((img, i) => (
                    <div
                      key={i}
                      className="w-[85%] flex-shrink-0 mr-3 rounded-xl overflow-hidden border border-white/10 shadow-2xl cursor-pointer group transition-opacity duration-300"
                      style={{ opacity: workshopCarouselIndex === i ? 1 : 0.45, height: '340px' }}
                      onClick={() => openImage(img.src, img.alt, workshopImages, 'Workshop & Alignment')}
                    >
                      <img
                        src={img.src}
                        alt={img.alt}
                        className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105"
                      />
                      <ExpandBadge />
                    </div>
                  ))}
                </div>
              </div>

              {/* Caption + arrows row */}
              <div className="flex items-center justify-between mt-4 pr-3">
                <span className="text-cream/35 text-xs tracking-wide font-sans">
                  {workshopImages[workshopCarouselIndex].alt}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setWorkshopCarouselIndex(0)}
                    className={`p-1.5 rounded-full border border-cream/15 text-cream/50 hover:text-cream hover:border-cream/30 transition-all duration-200 ${
                      workshopCarouselIndex === 0 ? 'opacity-25 pointer-events-none' : 'opacity-100'
                    }`}
                    aria-label="Previous image"
                  >
                    <ChevronLeft size={14} />
                  </button>
                  <span className="text-cream/40 text-xs tabular-nums font-mono">
                    {workshopCarouselIndex + 1} of {workshopImages.length}
                  </span>
                  <button
                    onClick={() => setWorkshopCarouselIndex(1)}
                    className={`p-1.5 rounded-full border border-cream/15 text-cream/50 hover:text-cream hover:border-cream/30 transition-all duration-200 ${
                      workshopCarouselIndex === 1 ? 'opacity-25 pointer-events-none' : 'opacity-100'
                    }`}
                    aria-label="Next image"
                  >
                    <ChevronRight size={14} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ─── Slide 3: Two Banks + Bank Switcher (carousel) ──────── */}
        <section
          ref={setRef(3)}
          className="slide-section min-h-screen bg-cosmic-black"
        >
          <div className="container mx-auto px-4 md:px-8 min-h-screen grid grid-cols-1 md:grid-cols-2">
            <div className="flex flex-col justify-center pt-20 pb-10 md:py-24">
              <ChapterLabel chapter="Implementation" animated>Implementation</ChapterLabel>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-display font-bold text-cream mb-6 md:mb-8 leading-tight">
                Seamless Banks,<br />Seamless Switching
              </h2>
              <div className="space-y-4 md:space-y-5 text-cream/70 text-base md:text-lg leading-relaxed max-w-lg font-sans">
                <p>
                  The hero needed to introduce both banking partners before asking members to pick
                  a card. Brand familiarity had to come first so the partnership felt like a natural
                  fit, not a sales pitch.
                </p>
                <p>
                  The bank switcher carries that same idea. Toggling between Scotiabank and Tangerine
                  feels like a context shift, not a page load. Scene+ stays the constant no matter
                  which bank you're looking at.
                </p>
              </div>
              <MobileMediaThumb
                items={heroLandingImages}
                caption="Landing page + bank switcher"
                onOpen={(src, alt, group) => openImage(src, alt, group, 'Seamless Banks, Seamless Switching')}
              />
            </div>

            {/* Carousel */}
            <div className="hidden md:flex flex-col justify-center bg-cosmic-dark/20 pl-8 py-12 overflow-hidden relative">
              {/* Track — items are 85% wide so the next one peeks in */}
              <div className="relative overflow-hidden">
                <div
                  className="flex transition-transform duration-500 ease-in-out"
                  style={{ transform: `translateX(calc(-${heroLandingCarouselIndex * 85}% - ${heroLandingCarouselIndex * 12}px))` }}
                >
                  {heroLandingImages.map((img, i) => (
                    <div
                      key={i}
                      className="w-[85%] flex-shrink-0 mr-3 rounded-xl overflow-hidden border border-white/10 shadow-2xl cursor-pointer group transition-opacity duration-300"
                      style={{ opacity: heroLandingCarouselIndex === i ? 1 : 0.45 }}
                      onClick={() => openImage(img.src, img.alt, heroLandingImages, 'Seamless Banks, Seamless Switching')}
                    >
                      <img
                        src={img.src}
                        alt={img.alt}
                        className="w-full transition-transform duration-500 group-hover:scale-105"
                      />
                      <ExpandBadge />
                    </div>
                  ))}
                </div>
              </div>

              {/* Caption + arrows row */}
              <div className="flex items-center justify-between mt-4 pr-3">
                <span className="text-cream/35 text-xs tracking-wide font-sans">
                  {heroLandingImages[heroLandingCarouselIndex].alt}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setHeroLandingCarouselIndex(0)}
                    className={`p-1.5 rounded-full border border-cream/15 text-cream/50 hover:text-cream hover:border-cream/30 transition-all duration-200 ${
                      heroLandingCarouselIndex === 0 ? 'opacity-25 pointer-events-none' : 'opacity-100'
                    }`}
                    aria-label="Previous image"
                  >
                    <ChevronLeft size={14} />
                  </button>
                  <span className="text-cream/40 text-xs tabular-nums font-mono">
                    {heroLandingCarouselIndex + 1} of {heroLandingImages.length}
                  </span>
                  <button
                    onClick={() => setHeroLandingCarouselIndex(1)}
                    className={`p-1.5 rounded-full border border-cream/15 text-cream/50 hover:text-cream hover:border-cream/30 transition-all duration-200 ${
                      heroLandingCarouselIndex === 1 ? 'opacity-25 pointer-events-none' : 'opacity-100'
                    }`}
                    aria-label="Next image"
                  >
                    <ChevronRight size={14} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ─── Slide 4: Filter & Comparison Table ─────────────────── */}
        <section
          ref={setRef(4)}
          className="slide-section min-h-screen bg-cosmic-black"
        >
          <div className="container mx-auto px-4 md:px-8 min-h-screen grid grid-cols-1 md:grid-cols-2">
            <div className="flex flex-col justify-center pt-20 pb-10 md:py-24">
              <ChapterLabel chapter="Implementation">Implementation</ChapterLabel>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-display font-bold text-cream mb-6 md:mb-8 leading-tight">
                Card Filter &amp; Comparison
              </h2>
              <div className="space-y-4 md:space-y-5 text-cream/70 text-base md:text-lg leading-relaxed max-w-lg font-sans">
                <p>
                  The old card-finder was walls of fine print. The redesign introduced filter chips
                  and row highlighting so members could find the right card without reading every cell.
                </p>
                <p>
                  Filtering by reward category, annual fee, or income requirement narrowed the
                  options down to what mattered, making comparison feel more like choosing than
                  doing research.
                </p>
              </div>
              <MobileMediaThumb
                items={[{ src: '/filter-table-highlighter.gif', alt: 'Scene+ card filter and comparison table' }]}
                caption="Scene+ card filter and comparison table"
                onOpen={(src, alt, group) => openImage(src, alt, group, 'Card Filter & Comparison')}
              />
            </div>
            <div
              className="hidden md:flex flex-col justify-center bg-cosmic-dark/20 pl-8 py-12 cursor-pointer group overflow-hidden"
              onClick={() => openImage('/filter-table-highlighter.gif', 'Scene+ card filter and comparison table', undefined, 'Card Filter & Comparison')}
            >
              <div className="relative w-full rounded-xl overflow-hidden border border-white/10 shadow-2xl">
                <img
                  src="/filter-table-highlighter.gif"
                  alt="Scene+ card filter and comparison table"
                  className="w-full transition-transform duration-500 group-hover:scale-105"
                />
                <ExpandBadge />
              </div>
              <StandaloneCaption text="Scene+ card filter and comparison table" />
            </div>
          </div>
        </section>

        {/* ─── Slide 5: Iterative Process ──────────────────────────── */}
        <section
          ref={setRef(5)}
          className="slide-section min-h-screen bg-cosmic-black"
        >
          <div className="container mx-auto px-4 md:px-8 min-h-screen grid grid-cols-1 md:grid-cols-2">
            <div className="flex flex-col justify-center pt-20 pb-10 md:py-24">
              <ChapterLabel chapter="Implementation">Implementation</ChapterLabel>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-display font-bold text-cream mb-6 md:mb-8 leading-tight">
                Iterative Design Process
              </h2>
              <div className="space-y-4 md:space-y-5 text-cream/70 text-base md:text-lg leading-relaxed max-w-lg font-sans">
                <p>
                  The design ran through multiple concept rounds on a shared workshop board, with
                  both banking partners and the Scene+ team reviewing each one before we moved on.
                </p>
                <p>
                  Working in the open instead of presenting polished comps let stakeholders redirect
                  early. The team built toward a solution together rather than playing catch-up on
                  feedback at the end.
                </p>
              </div>
              <MobileMediaThumb
                items={[{ src: '/iterative-process.webp', alt: 'Iterative design process across concept versions' }]}
                caption="Iterative design process across concept versions"
                onOpen={(src, alt, group) => openImage(src, alt, group, 'Iterative Design Process')}
              />
            </div>
            <div
              className="hidden md:flex flex-col justify-center bg-cosmic-dark/20 pl-8 py-12 cursor-pointer group overflow-hidden"
              onClick={() => openImage('/iterative-process.webp', 'Iterative design process', undefined, 'Iterative Design Process')}
            >
              <div className="relative w-full rounded-xl overflow-hidden border border-white/10 shadow-2xl">
                <img
                  src="/iterative-process.webp"
                  alt="Iterative design process across concept versions"
                  className="w-full transition-transform duration-500 group-hover:scale-105"
                />
                <ExpandBadge />
              </div>
              <StandaloneCaption text="Iterative design process across concept versions" />
            </div>
          </div>
        </section>

        {/* ─── Slide 6: Web & Mobile Responsive ───────────────────── */}
        <section
          ref={setRef(6)}
          className="slide-section min-h-screen bg-cosmic-black"
        >
          <div className="container mx-auto px-4 md:px-8 min-h-screen grid grid-cols-1 md:grid-cols-2">
            <div className="flex flex-col justify-center pt-20 pb-10 md:py-24">
              <ChapterLabel chapter="Implementation">Implementation</ChapterLabel>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-display font-bold text-cream mb-6 md:mb-8 leading-tight">
                Web &amp; Mobile,<br />One Cohesive Experience
              </h2>
              <div className="space-y-4 md:space-y-5 text-cream/70 text-base md:text-lg leading-relaxed max-w-lg font-sans">
                <p>
                  The experience needed to work on every screen, from full-width desktop to a phone.
                  The same hierarchy and interaction patterns carry across both, so members aren't
                  relearning anything when they switch devices.
                </p>
                <p>
                  On mobile, filter chips scroll horizontally, the comparison table condenses into
                  card views, and the bank toggle stays accessible throughout. It functions the
                  same way it does on web.
                </p>
              </div>
              <MobileMediaThumb
                items={[{ src: '/scene_banking_mobile-responsive-2.png', alt: 'Scene+ Banking — web and mobile responsive design' }]}
                caption="Scene+ Banking — web and mobile responsive design"
                onOpen={(src, alt, group) => openImage(src, alt, group, 'Web & Mobile, One Cohesive Experience')}
              />
            </div>
            <div
              className="hidden md:flex flex-col justify-center bg-cosmic-dark/20 pl-8 py-12 cursor-pointer group overflow-hidden"
              onClick={() => openImage('/scene_banking_mobile-responsive-2.png', 'Scene+ Banking — web and mobile responsive design', undefined, 'Web & Mobile, One Cohesive Experience')}
            >
              <div className="relative w-full rounded-xl overflow-hidden border border-white/10 shadow-2xl">
                <img
                  src="/scene_banking_mobile-responsive-2.png"
                  alt="Scene+ Banking — web and mobile responsive design"
                  className="w-full transition-transform duration-500 group-hover:scale-105"
                />
                <ExpandBadge />
              </div>
              <StandaloneCaption text="Scene+ Banking — web and mobile responsive design" />
            </div>
          </div>
        </section>

        {/* ─── Slide 7: Results ───────────────────────────────────── */}
        <section
          ref={setRef(7)}
          className="slide-section min-h-screen bg-cosmic-black"
        >
          <div className="container mx-auto px-4 md:px-8 min-h-screen grid grid-cols-1 md:grid-cols-2">
            {/* Left: copy */}
            <div className="flex flex-col justify-center pt-20 pb-10 md:py-24">
              <ChapterLabel chapter="Results" animated>Results</ChapterLabel>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-display font-bold text-cream mb-6 md:mb-8 leading-tight">
                Tested with Real Users,<br />Validated with Data
              </h2>
              <div className="space-y-4 md:space-y-5 text-cream/70 text-base md:text-lg leading-relaxed max-w-lg font-sans">
                <p>
                  I partnered with our researcher to build a testing pipeline: AI-assisted
                  prototyping in Claude and Bolt, participant recruiting through User Interviews,
                  and voice-based comprehension testing to catch things click-through studies miss.
                </p>
                <p>
                  Over 100 participants across multiple rounds gave us the evidence to align
                  stakeholders from two banks on a single direction.
                </p>
                <p className="text-cream/40 text-base font-sans">
                  76% of participants preferred flat layouts with less clicks.
                </p>
              </div>

              {/* Live results note */}
              <div className="mt-6 md:mt-8 flex items-start gap-3 rounded-lg border border-amber-400/20 bg-amber-400/5 px-4 py-3 max-w-lg">
                <span className="mt-0.5 h-1.5 w-1.5 rounded-full bg-amber-400/60 flex-shrink-0 mt-2" />
                <p className="text-amber-400/70 text-sm leading-relaxed">
                  Live result updates coming after Q2 2026.
                </p>
              </div>

              <MobileMediaThumb
                items={resultsImages}
                caption="User testing results across rounds"
                onOpen={(src, alt, group) => openImage(src, alt, group, 'Tested with Real Users, Validated with Data')}
              />
            </div>

            {/* Right: carousel */}
            <div className="hidden md:flex flex-col justify-center bg-cosmic-dark/20 pl-8 py-12 overflow-hidden relative">
              <div className="relative overflow-hidden">
                <div
                  className="flex transition-transform duration-500 ease-in-out"
                  style={{ transform: `translateX(calc(-${resultsCarouselIndex * 85}% - ${resultsCarouselIndex * 12}px))` }}
                >
                  {resultsImages.map((img, i) => (
                    <div
                      key={i}
                      className="w-[85%] flex-shrink-0 mr-3 rounded-xl overflow-hidden border border-white/10 shadow-2xl cursor-pointer group transition-opacity duration-300"
                      style={{ opacity: resultsCarouselIndex === i ? 1 : 0.45 }}
                      onClick={() => openImage(img.src, img.alt, resultsImages, 'Tested with Real Users, Validated with Data')}
                    >
                      <img
                        src={img.src}
                        alt={img.alt}
                        className="w-full transition-transform duration-500 group-hover:scale-105"
                      />
                      <ExpandBadge />
                    </div>
                  ))}
                </div>
              </div>

              {/* Caption + arrows row */}
              <div className="flex items-center justify-between mt-4 pr-3">
                <span className="text-cream/35 text-xs tracking-wide font-sans">
                  {resultsImages[resultsCarouselIndex].alt}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setResultsCarouselIndex(i => Math.max(0, i - 1))}
                    className={`p-1.5 rounded-full border border-cream/15 text-cream/50 hover:text-cream hover:border-cream/30 transition-all duration-200 ${
                      resultsCarouselIndex === 0 ? 'opacity-25 pointer-events-none' : 'opacity-100'
                    }`}
                    aria-label="Previous image"
                  >
                    <ChevronLeft size={14} />
                  </button>
                  <span className="text-cream/40 text-xs tabular-nums font-mono">
                    {resultsCarouselIndex + 1} of {resultsImages.length}
                  </span>
                  <button
                    onClick={() => setResultsCarouselIndex(i => Math.min(resultsImages.length - 1, i + 1))}
                    className={`p-1.5 rounded-full border border-cream/15 text-cream/50 hover:text-cream hover:border-cream/30 transition-all duration-200 ${
                      resultsCarouselIndex === resultsImages.length - 1 ? 'opacity-25 pointer-events-none' : 'opacity-100'
                    }`}
                    aria-label="Next image"
                  >
                    <ChevronRight size={14} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      {selectedImage && (
        <ImageModal
          src={selectedImage.src}
          alt={selectedImage.alt}
          title={activeTitle ?? undefined}
          onClose={() => {
            setSelectedImage(null);
            setSelectedImageIndex(-1);
            setActiveGallery([]);
            setActiveTitle(null);
          }}
          onPrevious={handlePrev}
          onNext={handleNext}
          hasPrevious={selectedImageIndex > 0}
          hasNext={selectedImageIndex < activeGallery.length - 1}
          currentIndex={selectedImageIndex}
          totalCount={activeGallery.length}
        />
      )}
    </div>
  );
};

const ChapterLabel = ({
  children,
  chapter,
  animated,
}: {
  children: React.ReactNode;
  chapter: 'Discovery' | 'Implementation' | 'Results' | null;
  animated?: boolean;
}) => {
  const color = chapter ? CHAPTER_COLORS[chapter] : 'text-cream/40';
  const ref = useRef<HTMLSpanElement>(null);
  const [phase, setPhase] = useState<'hidden' | 'grow' | 'retract'>('hidden');

  useEffect(() => {
    if (!animated || !ref.current) return;
    const timers: number[] = [];
    const obs = new IntersectionObserver(
      ([entry]) => {
        timers.forEach((t) => window.clearTimeout(t));
        timers.length = 0;
        if (entry.isIntersecting) {
          setPhase('hidden');
          timers.push(window.setTimeout(() => setPhase('grow'), 300));
          timers.push(window.setTimeout(() => setPhase('retract'), 300 + 650));
          timers.push(window.setTimeout(() => setPhase('hidden'), 300 + 650 + 650));
        } else {
          setPhase('hidden');
        }
      },
      { threshold: 0.6 }
    );
    obs.observe(ref.current);
    return () => {
      obs.disconnect();
      timers.forEach((t) => window.clearTimeout(t));
    };
  }, [animated]);

  const underlineStyle: React.CSSProperties =
    phase === 'hidden'
      ? { transform: 'scaleX(0)', transformOrigin: 'left', transitionDuration: '0ms' }
      : phase === 'grow'
      ? { transform: 'scaleX(1)', transformOrigin: 'left', transitionDuration: '650ms' }
      : { transform: 'scaleX(0)', transformOrigin: 'right', transitionDuration: '650ms' };

  return (
    <span
      ref={ref}
      className={`relative inline-block self-start text-xs font-semibold uppercase tracking-widest mb-5 ${color}`}
    >
      {children}
      {animated && (
        <span
          aria-hidden
          className="absolute left-0 right-0 -bottom-1 h-px bg-current transition-transform ease-out"
          style={underlineStyle}
        />
      )}
    </span>
  );
};

export default ScenePlusCaseStudy;
