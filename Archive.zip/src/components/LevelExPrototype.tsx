import React, { useState } from 'react';
import { HelpCircle, RotateCcw } from 'lucide-react';

type Step = 'initial' | 'searching' | 'results' | 'done';

const LevelExPrototype = () => {
  const [step, setStep] = useState<Step>('initial');
  const [showTooltip, setShowTooltip] = useState(false);

  const handleSignUp = () => {
    setStep('searching');
    setTimeout(() => {
      setStep('results');
    }, 2000);
  };

  const handleSelect = () => {
    setStep('done');
  };

  const handleReset = () => {
    setStep('initial');
  };

  return (
    <div className="bg-gradient-to-br from-purple-900/20 via-blue-900/20 to-cyan-900/20 border border-cyan-500/30 rounded-2xl p-8 my-8 shadow-2xl">
      <div className="text-xs text-cyan-400/70 mb-6 text-center uppercase tracking-widest font-semibold">
        Interactive Prototype
      </div>

      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 rounded-xl shadow-2xl max-w-md mx-auto overflow-hidden relative border border-white/10" style={{ minHeight: '500px' }}>
        {step === 'initial' && (
          <div className="p-8 bg-gradient-to-br from-slate-800 via-blue-900 to-cyan-900 relative flex flex-col" style={{
            backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(6, 182, 212, 0.15) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(59, 130, 246, 0.15) 0%, transparent 50%)',
            minHeight: '500px'
          }}>
            <div className="flex justify-center mb-8 mt-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-white mb-1">
                  doximity
                </div>
                <div className="text-xs text-cyan-300 tracking-wide">
                  The Medical Network
                </div>
              </div>
            </div>

            <div className="flex-1 flex flex-col justify-center max-w-sm mx-auto w-full">
              <div className="space-y-3 mb-4">
                <div className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <div className="w-full pl-11 pr-4 py-3 bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg text-slate-400 pointer-events-none">
                    john.smith@example.com
                  </div>
                </div>

                <div className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                  </div>
                  <div className="w-full pl-11 pr-4 py-3 bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg text-slate-400 pointer-events-none">
                    ••••••••••
                  </div>
                </div>
              </div>

              <button
                onClick={handleSignUp}
                className="relative w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white font-bold py-3.5 rounded-lg transition-all shadow-xl hover:shadow-2xl hover:shadow-cyan-500/50 border-2 border-cyan-400/50 mb-6 animate-pulse hover:animate-none"
              >
                Sign In
              </button>

              <div className="text-center mb-4">
                <div className="text-xs text-slate-400/60">Or continue with</div>
              </div>

              <div className="flex justify-center gap-3 opacity-40 pointer-events-none">
                <div className="w-12 h-12 bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2C6.477 2 2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.879V14.89h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.989C18.343 21.129 22 16.99 22 12c0-5.523-4.477-10-10-10z"/>
                  </svg>
                </div>

                <div className="w-12 h-12 bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12.152 6.896c-.948 0-2.415-1.078-3.96-1.04-2.04.027-3.91 1.183-4.961 3.014-2.117 3.675-.546 9.103 1.519 12.09 1.013 1.454 2.208 3.09 3.792 3.039 1.52-.065 2.09-.987 3.935-.987 1.831 0 2.35.987 3.96.948 1.637-.026 2.676-1.48 3.676-2.948 1.156-1.688 1.636-3.325 1.662-3.415-.039-.013-3.182-1.221-3.22-4.857-.026-3.04 2.48-4.494 2.597-4.559-1.429-2.09-3.623-2.324-4.39-2.376-2-.156-3.675 1.09-4.61 1.09zM15.53 3.83c.843-1.012 1.4-2.427 1.245-3.83-1.207.052-2.662.805-3.532 1.818-.78.896-1.454 2.338-1.273 3.714 1.338.104 2.715-.688 3.559-1.701"/>
                  </svg>
                </div>

                <div className="w-12 h-12 bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                  </svg>
                </div>

                <div className="w-12 h-12 bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        )}

        {step === 'searching' && (
          <div className="p-8 flex flex-col items-center justify-center bg-gradient-to-br from-slate-800 via-blue-900 to-cyan-900 relative" style={{
            backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(6, 182, 212, 0.15) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(59, 130, 246, 0.15) 0%, transparent 50%)',
            minHeight: '500px'
          }}>
            <h3 className="text-xl font-bold text-white mb-4 text-center max-w-xs">
              Thanks! We're searching public records to help create your account.
            </h3>

            <div className="my-12 relative">
              <div className="w-16 h-16 border-4 border-cyan-500/30 border-t-cyan-400 rounded-full animate-spin shadow-lg shadow-cyan-500/50"></div>
              <div className="absolute inset-0 w-16 h-16 border-4 border-blue-400/20 rounded-full animate-pulse"></div>
            </div>

            <div className="text-cyan-300 mb-8 font-medium">Searching...</div>

            <button
              onClick={handleReset}
              className="absolute bottom-8 left-8 right-8 border-2 border-red-400/50 text-red-300 hover:bg-red-500 hover:text-white hover:border-red-500 font-semibold py-3 rounded-lg transition-all shadow-lg"
            >
              Cancel
            </button>
          </div>
        )}

        {step === 'results' && (
          <div className="p-8 bg-gradient-to-br from-slate-800 via-blue-900 to-cyan-900" style={{
            backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(6, 182, 212, 0.15) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(59, 130, 246, 0.15) 0%, transparent 50%)',
            minHeight: '500px'
          }}>
            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold text-white mb-3">Is that you?</h3>
              <div className="flex items-center gap-2 justify-center text-sm text-cyan-200 mb-4">
                <span className="font-semibold">Work State:</span>
                <select className="border-2 border-cyan-400/50 rounded-lg px-3 py-1 bg-white/10 backdrop-blur-sm text-white shadow-lg hover:border-cyan-400 transition-colors focus:outline-none focus:border-cyan-400">
                  <option className="bg-slate-800">All</option>
                  <option className="bg-slate-800">Illinois</option>
                  <option className="bg-slate-800">Wisconsin</option>
                </select>
              </div>
            </div>

            <div className="space-y-3 mb-6">
              <div
                className="border-2 border-cyan-400/50 bg-white/10 backdrop-blur-sm rounded-xl p-4 hover:border-cyan-400 hover:bg-white/15 hover:shadow-xl hover:shadow-cyan-500/30 cursor-pointer transition-all"
                onClick={handleSelect}
              >
                <div className="flex gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center text-white font-bold flex-shrink-0 shadow-lg">
                    IL
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-white">John Smith, M.D., F.A.C.S.</div>
                    <div className="text-sm text-slate-300">Wilmette, IL</div>
                    <div className="text-sm text-cyan-300 font-medium">Plastic Surgery</div>
                  </div>
                </div>
              </div>

              <div
                className="border-2 border-cyan-400/50 bg-white/10 backdrop-blur-sm rounded-xl p-4 hover:border-cyan-400 hover:bg-white/15 hover:shadow-xl hover:shadow-cyan-500/30 cursor-pointer transition-all"
                onClick={handleSelect}
              >
                <div className="flex gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center text-white font-bold flex-shrink-0 shadow-lg">
                    IL
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-white">Jack Smith, L.C.P.C.</div>
                    <div className="text-sm text-slate-300">Orland Park, IL</div>
                    <div className="text-sm text-cyan-300 font-medium">Counselor Professional</div>
                  </div>
                </div>
              </div>

              <div
                className="border-2 border-white/20 bg-white/5 backdrop-blur-sm rounded-xl p-4 hover:border-cyan-400/50 hover:bg-white/10 hover:shadow-lg cursor-pointer transition-all opacity-60"
                onClick={handleSelect}
              >
                <div className="flex gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-slate-600 to-slate-500 rounded-lg flex items-center justify-center text-white font-bold flex-shrink-0 shadow-lg">
                    WI
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-white">Jonathan Smith, PharmD</div>
                    <div className="text-sm text-slate-300">Milwaukee, WI</div>
                    <div className="text-sm text-slate-400 font-medium">Pharmacist</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="border-t border-cyan-400/30 pt-4 mt-4">
              <div className="flex items-start gap-2 mb-4">
                <div className="text-sm text-cyan-200 flex-1 font-medium">
                  National Provider Identifier (NPI)
                </div>
                <button
                  className="relative text-cyan-300 hover:text-cyan-200 transition-colors flex-shrink-0"
                  onMouseEnter={() => setShowTooltip(true)}
                  onMouseLeave={() => setShowTooltip(false)}
                >
                  <HelpCircle size={18} />
                  {showTooltip && (
                    <div className="absolute right-0 top-6 w-64 bg-gradient-to-br from-slate-900 to-slate-800 text-white text-xs rounded-lg p-3 shadow-2xl z-10 border border-cyan-500/30">
                      <div className="font-bold mb-1 text-cyan-300">Why do we need this?</div>
                      <div className="text-slate-300">
                        We use your NPI to verify your medical credentials and personalize your experience with relevant cases from your specialty. Your information is kept secure and never shared without permission.
                      </div>
                      <div className="absolute right-4 -top-1 w-2 h-2 bg-slate-900 transform rotate-45 border-t border-l border-cyan-500/30"></div>
                    </div>
                  )}
                </button>
              </div>

              <button className="w-full text-sm text-cyan-300 hover:text-cyan-200 py-2 text-center font-semibold transition-colors">
                I'll verify later / I don't have an NPI #
              </button>
            </div>
          </div>
        )}

        {step === 'done' && (
          <div className="p-8 text-center flex flex-col items-center justify-center bg-gradient-to-br from-slate-800 via-blue-900 to-cyan-900" style={{
            backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(6, 182, 212, 0.15) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(59, 130, 246, 0.15) 0%, transparent 50%)',
            minHeight: '500px'
          }}>
            <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl shadow-emerald-500/50">
              <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h3 className="text-3xl font-bold text-white mb-4">Verified!</h3>
            <p className="text-slate-200 mb-8 max-w-xs leading-relaxed">
              Your credentials have been verified. You now have access to personalized cases and CME credits for <span className="text-cyan-300 font-semibold">Plastic Surgery</span>.
            </p>
          </div>
        )}
      </div>

      <button
        onClick={handleReset}
        className="mt-6 mx-auto flex items-center gap-2 px-4 py-2 bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 rounded-lg transition-all text-sm font-medium"
      >
        <RotateCcw size={16} />
        Reset Prototype
      </button>
    </div>
  );
};

export default LevelExPrototype;
