import React, { useEffect } from 'react';
import { X } from 'lucide-react';

interface YouTubeModalProps {
  videoId: string;
  onClose: () => void;
}

const YouTubeModal = ({ videoId, onClose }: YouTubeModalProps) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div className="relative w-full max-w-7xl h-[80vh]">
        <button 
          className="absolute -top-12 right-0 text-white/80 hover:text-white transition-colors z-10"
          onClick={onClose}
        >
          <X size={24} />
        </button>
        
        <iframe
          src={`https://www.youtube.com/embed/${videoId}?autoplay=1`}
          title="YouTube video"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          className="w-full h-full rounded-lg"
          onClick={(e) => e.stopPropagation()}
        />
      </div>
    </div>
  );
};

export default YouTubeModal;