import React from 'react';

interface TransitionLayerProps {
  isActive: boolean;
}

const TransitionLayer = ({ isActive }: TransitionLayerProps) => {
  return (
    <div
      className={`fixed inset-0 bg-ink z-[60] pointer-events-none transition-opacity duration-300 ${
        isActive ? 'opacity-100' : 'opacity-0'
      }`}
    />
  );
};

export default TransitionLayer;