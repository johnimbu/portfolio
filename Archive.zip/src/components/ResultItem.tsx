import React from 'react';
import { Check } from 'lucide-react';

interface ResultItemProps {
  children: React.ReactNode;
}

const ResultItem = ({ children }: ResultItemProps) => {
  return (
    <div className="flex items-start space-x-3 group">
      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-gradient-to-r from-accent-teal to-accent-violet flex items-center justify-center transform transition-transform duration-300 group-hover:scale-110">
        <Check size={14} className="text-white" />
      </div>
      <span className="text-lg text-white/80 leading-relaxed">{children}</span>
    </div>
  );
};

export default ResultItem;