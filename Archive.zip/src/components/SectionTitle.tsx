import React from 'react';

interface SectionTitleProps {
  title: string;
  subtitle?: string;
  alignment?: 'left' | 'center' | 'right';
  className?: string;
}

const SectionTitle = ({ 
  title, 
  subtitle, 
  alignment = 'center',
  className = '' 
}: SectionTitleProps) => {
  const alignmentClasses = {
    left: 'text-left',
    center: 'text-center mx-auto',
    right: 'text-right ml-auto',
  };

  return (
    <div className={`mb-12 max-w-2xl ${alignmentClasses[alignment]} ${className}`}>
      <h2 className="text-3xl md:text-4xl font-display font-bold mb-4 text-ink" style={{ letterSpacing: '-0.03em' }}>
        {title}
      </h2>
      {subtitle && (
        <p className="text-lg text-ink-muted leading-relaxed font-sans">
          {subtitle}
        </p>
      )}
    </div>
  );
};

export default SectionTitle;