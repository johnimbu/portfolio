import React, { useRef, useState, useCallback, useEffect } from 'react';
import { ZoomIn, ZoomOut, Maximize2 } from 'lucide-react';

interface ZoomableImageProps {
  src: string;
  alt: string;
}

const MIN_ZOOM = 0.1;
const MAX_ZOOM = 0.4;
const ZOOM_STEP = 0.05;

const ZoomableImage: React.FC<ZoomableImageProps> = ({ src, alt }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(0.18);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0, scrollLeft: 0, scrollTop: 0 });
  const [imgSize, setImgSize] = useState({ w: 0, h: 0 });

  const adjustZoom = (delta: number) => {
    setZoom(z => parseFloat(Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, z + delta)).toFixed(2)));
  };

  const fitToWidth = () => {
    const el = containerRef.current;
    if (!el || imgSize.w === 0) return;
    const newZoom = parseFloat(Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, el.clientWidth / imgSize.w)).toFixed(2));
    setZoom(newZoom);
    setTimeout(() => el.scrollTo({ left: 0, top: 0 }), 0);
  };

  const onMouseDown = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    setIsDragging(true);
    setDragStart({
      x: e.clientX,
      y: e.clientY,
      scrollLeft: containerRef.current.scrollLeft,
      scrollTop: containerRef.current.scrollTop,
    });
  };

  const onMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDragging || !containerRef.current) return;
    containerRef.current.scrollLeft = dragStart.scrollLeft - (e.clientX - dragStart.x);
    containerRef.current.scrollTop = dragStart.scrollTop - (e.clientY - dragStart.y);
  }, [isDragging, dragStart]);

  const onMouseUp = () => setIsDragging(false);

  const onWheel = (e: React.WheelEvent) => {
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      adjustZoom(e.deltaY < 0 ? ZOOM_STEP : -ZOOM_STEP);
    }
  };

  return (
    <div className="my-10 rounded-xl overflow-hidden border border-white/10 bg-[#0a0a0a] shadow-2xl">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-white/5 bg-[#0d0d0d]">
        <span className="text-xs text-white/25 font-mono">User Flow & Journey Map — drag to pan, ctrl+scroll or use buttons to zoom</span>
        <div className="flex items-center gap-2">
          <button
            onClick={() => adjustZoom(-ZOOM_STEP)}
            disabled={zoom <= MIN_ZOOM}
            className="w-8 h-8 flex items-center justify-center rounded-lg bg-cosmic-light/60 border border-white/10 text-white/60 hover:text-white hover:border-white/30 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
          >
            <ZoomOut size={13} />
          </button>
          <span className="text-xs text-white/35 font-mono w-10 text-center">{Math.round(zoom * 100)}%</span>
          <button
            onClick={() => adjustZoom(ZOOM_STEP)}
            disabled={zoom >= MAX_ZOOM}
            className="w-8 h-8 flex items-center justify-center rounded-lg bg-cosmic-light/60 border border-white/10 text-white/60 hover:text-white hover:border-white/30 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
          >
            <ZoomIn size={13} />
          </button>
          <button
            onClick={fitToWidth}
            className="w-8 h-8 flex items-center justify-center rounded-lg bg-cosmic-light/60 border border-white/10 text-white/60 hover:text-white hover:border-white/30 transition-all"
            title="Fit to width"
          >
            <Maximize2 size={13} />
          </button>
        </div>
      </div>

      <div
        ref={containerRef}
        className="overflow-auto"
        style={{
          cursor: isDragging ? 'grabbing' : 'grab',
          maxHeight: 600,
          background: '#f5f0e8',
        }}
        onMouseDown={onMouseDown}
        onMouseMove={onMouseMove}
        onMouseUp={onMouseUp}
        onMouseLeave={onMouseUp}
        onWheel={onWheel}
      >
        <div
          style={{
            width: imgSize.w * zoom || '100%',
            height: imgSize.h * zoom || 'auto',
            minWidth: imgSize.w * zoom,
            flexShrink: 0,
          }}
        >
          <img
            src={src}
            alt={alt}
            draggable={false}
            onLoad={(e) => {
              const img = e.currentTarget;
              setImgSize({ w: img.naturalWidth, h: img.naturalHeight });
            }}
            style={{
              width: imgSize.w * zoom || '100%',
              height: imgSize.h * zoom || 'auto',
              display: 'block',
              transformOrigin: 'top left',
              userSelect: 'none',
              pointerEvents: 'none',
            }}
          />
        </div>
      </div>

      <div className="px-4 py-2.5 border-t border-white/5 bg-[#0d0d0d]">
        <p className="text-xs text-white/20 font-mono text-center">drag to pan · ctrl+scroll or buttons to zoom · click fit icon to reset</p>
      </div>
    </div>
  );
};

export default ZoomableImage;
