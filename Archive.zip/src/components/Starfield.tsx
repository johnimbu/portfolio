import React from 'react';

const Starfield = () => {
  return (
    <div className="fixed top-0 left-0 w-full h-full pointer-events-none z-0">
      <div className="absolute inset-0 bg-gradient-to-br from-cosmic-black via-cosmic-black to-cosmic-black">
        <div
          className="absolute inset-0 opacity-[0.07]"
          style={{
            backgroundImage: `
              linear-gradient(90deg, rgba(5, 217, 232, 0.03) 1px, transparent 1px),
              linear-gradient(0deg, rgba(5, 217, 232, 0.03) 1px, transparent 1px)
            `,
            backgroundSize: '80px 80px',
            animation: 'grid-flow 60s linear infinite'
          }}
        />
        <div
          className="absolute inset-0"
          style={{
            background: `
              radial-gradient(ellipse 800px 600px at 20% 40%, rgba(5, 217, 232, 0.08) 0%, transparent 50%),
              radial-gradient(ellipse 600px 800px at 80% 60%, rgba(255, 215, 0, 0.06) 0%, transparent 50%)
            `,
            animation: 'glow-pulse 20s ease-in-out infinite'
          }}
        />
        <div
          className="absolute inset-0 opacity-[0.15]"
          style={{
            background: 'radial-gradient(circle 2px at 15% 25%, rgba(5, 217, 232, 0.4) 0%, transparent 100%), radial-gradient(circle 1px at 85% 15%, rgba(255, 215, 0, 0.3) 0%, transparent 100%), radial-gradient(circle 1.5px at 45% 65%, rgba(5, 217, 232, 0.3) 0%, transparent 100%), radial-gradient(circle 1px at 65% 85%, rgba(255, 215, 0, 0.25) 0%, transparent 100%), radial-gradient(circle 2px at 30% 90%, rgba(5, 217, 232, 0.35) 0%, transparent 100%)',
            animation: 'sparkle 8s ease-in-out infinite'
          }}
        />
      </div>
      <style>{`
        @keyframes grid-flow {
          0% {
            transform: translate(0, 0);
          }
          100% {
            transform: translate(80px, 80px);
          }
        }

        @keyframes glow-pulse {
          0%, 100% {
            opacity: 0.15;
          }
          50% {
            opacity: 0.25;
          }
        }

        @keyframes sparkle {
          0%, 100% {
            opacity: 0.15;
          }
          50% {
            opacity: 0.3;
          }
        }
      `}</style>
    </div>
  );
};

export default Starfield;