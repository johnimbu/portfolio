import React from 'react';

const Footer = () => {
  return (
    <footer className="relative mt-20 py-12 overflow-hidden">
      <div className="container mx-auto px-4 md:px-8">
      </div>
    </footer>
  );
};

export default Footer;