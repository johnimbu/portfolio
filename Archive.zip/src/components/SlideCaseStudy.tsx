import { ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, ChevronUp, ChevronDown, Maximize2 } from 'lucide-react';
import { CaseStudy } from '../types';
import ImageModal from './ImageModal';
import MobileMediaThumb from './MobileMediaThumb';

type Chapter = 'Discovery' | 'Implementation' | 'Results';

export type SlideMedia =
  | {
      kind: 'image';
      src: string;
      alt: string;
      before?: boolean;
      objectFit?: 'cover' | 'contain';
      objectPosition?: string;
      maxHeight?: string;
    }
  | { kind: 'carousel'; items: { src: string; alt: string }[] };

export type HeroSlide = {
  id: string;
  kind: 'hero';
  backgroundImage: string;
  tags: string[];
  title: string;
  tagline: string;
  role: string;
};

export type ContentSlide = {
  id: string;
  kind: 'content';
  chapter: Chapter;
  title: ReactNode;
  body: ReactNode;
  media: SlideMedia;
  notice?: string;
};

export type Slide = HeroSlide | ContentSlide;

export type SlideCaseStudyConfig = {
  slides: Slide[];
};

interface Props {
  caseStudy: CaseStudy;
  onNextCaseStudy: (nextStudy: CaseStudy) => void;
  allCaseStudies: CaseStudy[];
  config: SlideCaseStudyConfig;
}

const CHAPTER_COLORS: Record<Chapter, string> = {
  Discovery: 'text-accent-teal/80',
  Implementation: 'text-accent-teal/60',
  Results: 'text-amber-400/80',
};

const SlideCaseStudy = ({ caseStudy, onNextCaseStudy, allCaseStudies, config }: Props) => {
  const currentIndex = allCaseStudies.findIndex((s) => s.id === caseStudy.id);
  const nextCaseStudy = allCaseStudies[(currentIndex + 1) % allCaseStudies.length];
  const previousCaseStudy =
    allCaseStudies[(currentIndex - 1 + allCaseStudies.length) % allCaseStudies.length];

  const [activeSlide, setActiveSlide] = useState(0);
  const [selectedImage, setSelectedImage] = useState<{ src: string; alt: string } | null>(null);
  const [selectedImageIndex, setSelectedImageIndex] = useState(-1);
  const [activeGallery, setActiveGallery] = useState<{ src: string; alt: string }[]>([]);
  const [activeTitle, setActiveTitle] = useState<ReactNode>(null);
  const [carouselIndexes, setCarouselIndexes] = useState<Record<string, number>>({});
  const slideRefs = useRef<(HTMLElement | null)[]>([]);

  const openerIds = useMemo(() => {
    const seen = new Set<Chapter>();
    const ids = new Set<string>();
    config.slides.forEach((s) => {
      if (s.kind === 'content' && !seen.has(s.chapter)) {
        seen.add(s.chapter);
        ids.add(s.id);
      }
    });
    return ids;
  }, [config.slides]);

  const gallery: { src: string; alt: string }[] = [];
  config.slides.forEach((slide) => {
    if (slide.kind !== 'content') return;
    if (slide.media.kind === 'image') {
      gallery.push({ src: slide.media.src, alt: slide.media.alt });
    } else {
      slide.media.items.forEach((item) => gallery.push(item));
    }
  });

  useEffect(() => {
    document.title = `John Imburgia | ${caseStudy.title}`;
    return () => {
      document.title = 'John Imburgia: UX Design Leader';
    };
  }, [caseStudy.title]);

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  useEffect(() => {
    const observers: IntersectionObserver[] = [];
    slideRefs.current.forEach((el, i) => {
      if (!el) return;
      const obs = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) setActiveSlide(i);
        },
        { threshold: 0.5 }
      );
      obs.observe(el);
      observers.push(obs);
    });
    return () => observers.forEach((o) => o.disconnect());
  }, [config.slides.length]);

  const openImage = (
    src: string,
    alt: string,
    group?: { src: string; alt: string }[],
    title?: ReactNode
  ) => {
    const g = group ?? gallery;
    const idx = g.findIndex((item) => item.src === src);
    setActiveGallery(g);
    setSelectedImageIndex(idx);
    setSelectedImage({ src, alt });
    setActiveTitle(title ?? null);
  };

  const handlePrev = () => {
    if (selectedImageIndex > 0) {
      const i = selectedImageIndex - 1;
      setSelectedImageIndex(i);
      setSelectedImage(activeGallery[i]);
    }
  };

  const handleNext = () => {
    if (selectedImageIndex < activeGallery.length - 1) {
      const i = selectedImageIndex + 1;
      setSelectedImageIndex(i);
      setSelectedImage(activeGallery[i]);
    }
  };

  const scrollToSlide = (i: number) => {
    const el = slideRefs.current[i];
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (selectedImage) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        onNextCaseStudy(previousCaseStudy);
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        onNextCaseStudy(nextCaseStudy);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        if (activeSlide > 0) scrollToSlide(activeSlide - 1);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (activeSlide < config.slides.length - 1) scrollToSlide(activeSlide + 1);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedImage, activeSlide, config.slides.length, onNextCaseStudy, nextCaseStudy, previousCaseStudy]);

  const setRef = (i: number) => (el: HTMLElement | null) => {
    slideRefs.current[i] = el;
  };

  const setCarouselIndex = (id: string, i: number) => {
    setCarouselIndexes((prev) => ({ ...prev, [id]: i }));
  };

  return (
    <div className="relative">
      <div className="hidden md:flex fixed right-6 top-1/2 -translate-y-1/2 z-40 flex-col items-center rounded-full border border-cream/20 bg-cosmic-black/50 backdrop-blur-sm overflow-hidden">
        <button
          onClick={() => scrollToSlide(activeSlide - 1)}
          disabled={activeSlide === 0}
          aria-label="Previous slide"
          className="p-2.5 text-cream/50 hover:text-cream disabled:opacity-20 disabled:pointer-events-none transition-colors duration-150"
        >
          <ChevronUp size={14} />
        </button>
        <span className="w-px self-stretch bg-cream/15" />
        <span className="px-2.5 py-2 text-cream/50 text-xs tabular-nums font-mono leading-none">
          {activeSlide + 1}
          <span className="text-cream/20 mx-0.5">/</span>
          {config.slides.length}
        </span>
        <span className="w-px self-stretch bg-cream/15" />
        <button
          onClick={() => scrollToSlide(activeSlide + 1)}
          disabled={activeSlide === config.slides.length - 1}
          aria-label="Next slide"
          className="p-2.5 text-cream/50 hover:text-cream disabled:opacity-20 disabled:pointer-events-none transition-colors duration-150"
        >
          <ChevronDown size={14} />
        </button>
      </div>

      <div className="slide-scroll h-screen overflow-y-scroll no-scrollbar">
        {config.slides.map((slide, i) =>
          slide.kind === 'hero' ? (
            <HeroSection key={slide.id} slide={slide} setRef={setRef(i)} />
          ) : (
            <ContentSection
              key={slide.id}
              slide={slide}
              setRef={setRef(i)}
              carouselIndex={carouselIndexes[slide.id] ?? 0}
              onCarouselChange={(idx) => setCarouselIndex(slide.id, idx)}
              onOpenImage={openImage}
              isChapterOpener={openerIds.has(slide.id)}
            />
          )
        )}
      </div>

      {selectedImage && (
        <ImageModal
          src={selectedImage.src}
          alt={selectedImage.alt}
          title={activeTitle ?? undefined}
          onClose={() => {
            setSelectedImage(null);
            setSelectedImageIndex(-1);
            setActiveGallery([]);
            setActiveTitle(null);
          }}
          onPrevious={handlePrev}
          onNext={handleNext}
          hasPrevious={selectedImageIndex > 0}
          hasNext={selectedImageIndex < activeGallery.length - 1}
          currentIndex={selectedImageIndex}
          totalCount={activeGallery.length}
        />
      )}
    </div>
  );
};

const HeroSection = ({
  slide,
  setRef,
}: {
  slide: HeroSlide;
  setRef: (el: HTMLElement | null) => void;
}) => (
  <section
    ref={setRef}
    className="slide-section relative min-h-screen flex items-center bg-cosmic-black py-20 md:py-0"
  >
    <div
      className="absolute inset-0 bg-cover bg-center opacity-30"
      style={{ backgroundImage: `url(${slide.backgroundImage})` }}
    />
    <div className="absolute inset-0 bg-gradient-to-b from-cosmic-black/20 via-transparent to-cosmic-black" />
    <div className="relative z-10 container mx-auto px-4 md:px-8">
      <div className="flex flex-wrap gap-2 mb-6 md:mb-8">
        {slide.tags.map((tag) => (
          <span
            key={tag}
            className="text-[10px] md:text-xs font-sans font-600 tracking-widest uppercase text-cream/50 border border-cream/15 rounded-full px-2.5 py-1"
            style={{ letterSpacing: '0.18em' }}
          >
            {tag}
          </span>
        ))}
      </div>
      <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-display font-bold text-cream leading-none mb-5 md:mb-6" style={{ letterSpacing: '-0.04em' }}>
        {slide.title}
      </h1>
      <p className="text-lg sm:text-xl md:text-2xl text-cream/60 max-w-2xl leading-relaxed mb-10 md:mb-12 font-sans">
        {slide.tagline}
      </p>
      <div className="flex items-center gap-2">
        <span className="text-cream/40 text-xs md:text-sm font-sans tracking-wider uppercase" style={{ letterSpacing: '0.18em' }}>My Role</span>
        <span className="text-cream/30 text-xs md:text-sm">/</span>
        <span className="text-cream text-xs md:text-sm font-display font-bold">{slide.role}</span>
      </div>
    </div>
  </section>
);

const ContentSection = ({
  slide,
  setRef,
  carouselIndex,
  onCarouselChange,
  onOpenImage,
  isChapterOpener,
}: {
  slide: ContentSlide;
  setRef: (el: HTMLElement | null) => void;
  carouselIndex: number;
  onCarouselChange: (i: number) => void;
  onOpenImage: (
    src: string,
    alt: string,
    group?: { src: string; alt: string }[],
    title?: ReactNode
  ) => void;
  isChapterOpener: boolean;
}) => {
  const openWithTitle = (
    src: string,
    alt: string,
    group?: { src: string; alt: string }[]
  ) => onOpenImage(src, alt, group, slide.title);

  return (
    <section
      ref={setRef}
      className="slide-section min-h-screen bg-cosmic-black"
    >
      <div className="container mx-auto px-4 md:px-8 min-h-screen grid grid-cols-1 md:grid-cols-2">
        <div className="flex flex-col justify-center pt-20 pb-10 md:py-24">
          <ChapterLabel chapter={slide.chapter} animated={isChapterOpener} />
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-display font-bold text-cream mb-6 md:mb-8 leading-tight" style={{ letterSpacing: '-0.03em' }}>
            {slide.title}
          </h2>
          <div className="space-y-4 md:space-y-5 text-cream/70 text-base md:text-lg leading-relaxed max-w-lg font-sans">
            {slide.body}
          </div>
          {slide.notice && (
            <div className="mt-6 md:mt-8 flex items-start gap-3 rounded-lg border border-amber-400/20 bg-amber-400/5 px-4 py-3 max-w-lg">
              <span className="mt-2 h-1.5 w-1.5 rounded-full bg-amber-400/60 flex-shrink-0" />
              <p className="text-amber-400/70 text-sm leading-relaxed">{slide.notice}</p>
            </div>
          )}

          {slide.media.kind === 'image' ? (
            <MobileMediaThumb
              items={[{ src: slide.media.src, alt: slide.media.alt }]}
              caption={slide.media.alt}
              before={slide.media.before}
              onOpen={openWithTitle}
            />
          ) : (
            <MobileMediaThumb
              items={slide.media.items}
              caption={slide.media.items[0]?.alt}
              onOpen={openWithTitle}
            />
          )}
        </div>

        {slide.media.kind === 'image' ? (
          <ImagePanel media={slide.media} onOpenImage={openWithTitle} />
        ) : (
          <CarouselPanel
            items={slide.media.items}
            index={carouselIndex}
            onChange={onCarouselChange}
            onOpenImage={openWithTitle}
          />
        )}
      </div>
    </section>
  );
};

const ImagePanel = ({
  media,
  onOpenImage,
}: {
  media: Extract<SlideMedia, { kind: 'image' }>;
  onOpenImage: (src: string, alt: string, group?: { src: string; alt: string }[]) => void;
}) => {
  const objectFit = media.objectFit ?? 'cover';
  const objectPosition = media.objectPosition ?? 'top';
  const maxHeight = media.maxHeight ?? '520px';
  const borderClass = media.before ? 'border-red-500/20' : 'border-white/10';

  return (
    <div
      className="hidden md:flex flex-col justify-center bg-cosmic-dark/20 pl-8 py-12 overflow-hidden"
    >
      <div
        className={`relative w-full rounded-xl overflow-hidden border ${borderClass} shadow-2xl cursor-pointer group`}
        onClick={() => onOpenImage(media.src, media.alt)}
      >
        {media.before && (
          <div className="absolute top-3 left-3 z-10">
            <span className="text-xs font-semibold uppercase tracking-widest px-2.5 py-1 rounded-full bg-red-900/60 border border-red-500/40 text-red-300">
              Before
            </span>
          </div>
        )}
        <img
          src={media.src}
          alt={media.alt}
          className="w-full transition-transform duration-500 group-hover:scale-105"
          style={{ objectFit, objectPosition, maxHeight }}
        />
        {media.before && (
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-cosmic-black/50 pointer-events-none" />
        )}
        <ExpandBadge />
      </div>
      {media.alt && (
        <div className="mt-4 text-center">
          <span className="text-cream/40 text-xs tracking-wide font-sans">
            {media.alt}
          </span>
        </div>
      )}
    </div>
  );
};

const CarouselPanel = ({
  items,
  index,
  onChange,
  onOpenImage,
}: {
  items: { src: string; alt: string }[];
  index: number;
  onChange: (i: number) => void;
  onOpenImage: (src: string, alt: string, group?: { src: string; alt: string }[]) => void;
}) => {
  const clampedIndex = Math.min(Math.max(index, 0), items.length - 1);
  const current = items[clampedIndex];

  return (
    <div className="hidden md:flex flex-col justify-center bg-cosmic-dark/20 pl-8 py-12 overflow-hidden relative">
      <div className="relative overflow-hidden">
        <div
          className="flex transition-transform duration-500 ease-in-out"
          style={{
            transform: `translateX(calc(-${clampedIndex * 85}% - ${clampedIndex * 12}px))`,
          }}
        >
          {items.map((item, i) => (
            <div
              key={item.src}
              className="w-[85%] flex-shrink-0 mr-3 rounded-xl overflow-hidden border border-white/10 shadow-2xl cursor-pointer group transition-opacity duration-300"
              style={{ opacity: clampedIndex === i ? 1 : 0.45, height: '420px' }}
              onClick={() => onOpenImage(item.src, item.alt, items)}
            >
              <img
                src={item.src}
                alt={item.alt}
                className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105"
              />
              <ExpandBadge />
            </div>
          ))}
        </div>
      </div>

      <div className="flex items-center justify-between mt-4 pr-3">
        <span className="text-cream/35 text-xs tracking-wide truncate max-w-[60%] font-sans">
          {current.alt}
        </span>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onChange(Math.max(0, clampedIndex - 1))}
            className={`p-1.5 rounded-full border border-cream/15 text-cream/50 hover:text-cream hover:border-cream/30 transition-all duration-200 ${
              clampedIndex === 0 ? 'opacity-25 pointer-events-none' : 'opacity-100'
            }`}
            aria-label="Previous image"
          >
            <ChevronLeft size={14} />
          </button>
          <span className="text-cream/40 text-xs tabular-nums font-mono">
            {clampedIndex + 1} of {items.length}
          </span>
          <button
            onClick={() => onChange(Math.min(items.length - 1, clampedIndex + 1))}
            className={`p-1.5 rounded-full border border-cream/15 text-cream/50 hover:text-cream hover:border-cream/30 transition-all duration-200 ${
              clampedIndex === items.length - 1 ? 'opacity-25 pointer-events-none' : 'opacity-100'
            }`}
            aria-label="Next image"
          >
            <ChevronRight size={14} />
          </button>
        </div>
      </div>
    </div>
  );
};

const ExpandBadge = () => (
  <div className="absolute top-3 right-3 z-10 p-1.5 rounded-full bg-cosmic-black/70 backdrop-blur-sm border border-white/15 text-white/75 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none">
    <Maximize2 size={14} />
  </div>
);

type UnderlinePhase = 'hidden' | 'grow' | 'retract';

const ChapterLabel = ({ chapter, animated }: { chapter: Chapter; animated?: boolean }) => {
  const ref = useRef<HTMLSpanElement>(null);
  const [phase, setPhase] = useState<UnderlinePhase>('hidden');

  useEffect(() => {
    if (!animated || !ref.current) return;
    const timers: number[] = [];
    let lastTop: number | null = null;
    const obs = new IntersectionObserver(
      ([entry]) => {
        timers.forEach((t) => window.clearTimeout(t));
        timers.length = 0;
        const currentTop = entry.boundingClientRect.top;
        const scrolledDown = lastTop === null || currentTop < lastTop;
        lastTop = currentTop;
        if (entry.isIntersecting && scrolledDown) {
          setPhase('hidden');
          timers.push(window.setTimeout(() => setPhase('grow'), 300));
          timers.push(window.setTimeout(() => setPhase('retract'), 300 + 650));
          timers.push(window.setTimeout(() => setPhase('hidden'), 300 + 650 + 650));
        } else {
          setPhase('hidden');
        }
      },
      { threshold: 0.6 }
    );
    obs.observe(ref.current);
    return () => {
      obs.disconnect();
      timers.forEach((t) => window.clearTimeout(t));
    };
  }, [animated]);

  const underlineStyle: React.CSSProperties = (() => {
    if (phase === 'hidden') {
      return { transform: 'scaleX(0)', transformOrigin: 'left', transitionDuration: '0ms' };
    }
    if (phase === 'grow') {
      return { transform: 'scaleX(1)', transformOrigin: 'left', transitionDuration: '650ms' };
    }
    return { transform: 'scaleX(0)', transformOrigin: 'right', transitionDuration: '650ms' };
  })();

  return (
    <span
      ref={ref}
      className={`relative inline-block self-start text-xs font-semibold uppercase tracking-widest mb-5 ${CHAPTER_COLORS[chapter]}`}
    >
      {chapter}
      {animated && (
        <span
          aria-hidden
          className="absolute left-0 right-0 -bottom-1 h-px bg-current transition-transform ease-out"
          style={underlineStyle}
        />
      )}
    </span>
  );
};

export default SlideCaseStudy;
