import React, { useEffect, useState } from 'react';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { useNavigation } from '../contexts/NavigationContext';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const {
    currentCaseStudy,
    currentIndex,
    nextCaseStudy,
    previousCaseStudy,
    allCaseStudies,
    goHome,
    goToCaseStudy,
  } = useNavigation();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const isOnCaseStudy = currentCaseStudy !== null;

  if (!isOnCaseStudy) {
    return null;
  }

  const displayIndex = currentIndex + 1;
  const totalCount = allCaseStudies.length;

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-cosmic-black/92 backdrop-blur-md py-3 border-b border-cream/10'
          : 'bg-cosmic-black/60 backdrop-blur-sm py-4'
      }`}
    >
      <div className="px-4 md:px-8">
        <nav className="flex items-center justify-between gap-4">
          <button
            onClick={goHome}
            className="font-display font-bold text-base md:text-lg flex items-center group"
            aria-label="Home"
            style={{ letterSpacing: '-0.02em' }}
          >
            <span className="text-cream/90 group-hover:text-cream transition-colors duration-200 uppercase tracking-wide">
              John Imburgia<span className="text-accent-teal normal-case tracking-normal">.</span>
            </span>
          </button>

          <div className="flex items-center rounded-full border border-cream/20 overflow-hidden">
            <button
              onClick={() => previousCaseStudy && goToCaseStudy(previousCaseStudy)}
              title={previousCaseStudy ? `Previous: ${previousCaseStudy.title}` : ''}
              aria-label="Previous case study"
              disabled={!previousCaseStudy}
              className="flex items-center px-3 py-2 text-cream/60 hover:text-cream hover:bg-cream/8 transition-all duration-200 disabled:opacity-30 disabled:pointer-events-none group/prev"
            >
              <ArrowLeft
                size={14}
                className="transition-transform duration-200 group-hover/prev:-translate-x-0.5"
              />
            </button>
            <span className="self-stretch w-px bg-cream/15" />
            <span className="hidden sm:flex items-center px-3.5 py-2 text-cream/40 text-xs tabular-nums font-mono tracking-wide">
              {String(displayIndex).padStart(2, '0')}
              <span className="mx-1 text-cream/20">/</span>
              {String(totalCount).padStart(2, '0')}
            </span>
            <span className="hidden sm:block self-stretch w-px bg-cream/15" />
            <button
              onClick={() => nextCaseStudy && goToCaseStudy(nextCaseStudy)}
              title={nextCaseStudy ? `Next: ${nextCaseStudy.title}` : ''}
              className="flex items-center gap-1.5 px-3.5 py-2 text-cream/70 hover:text-cream hover:bg-cream/8 transition-all duration-200 text-sm font-sans font-medium group/next"
            >
              <span className="hidden sm:inline">Next Case Study</span>
              <span className="sm:hidden">Next</span>
              <ArrowRight
                size={14}
                className="transition-transform duration-200 group-hover/next:translate-x-0.5"
              />
            </button>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Navbar;
