import { ReactNode, TouchEvent, useEffect, useRef } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

interface ImageModalProps {
  src: string;
  alt: string;
  title?: ReactNode;
  onClose: () => void;
  onPrevious?: () => void;
  onNext?: () => void;
  hasPrevious?: boolean;
  hasNext?: boolean;
  currentIndex?: number;
  totalCount?: number;
}

const ImageModal = ({
  src,
  alt,
  title,
  onClose,
  onPrevious,
  onNext,
  hasPrevious,
  hasNext,
  currentIndex,
  totalCount,
}: ImageModalProps) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const touchStartX = useRef<number | null>(null);
  const touchStartY = useRef<number | null>(null);
  const touchSwiping = useRef(false);

  const SWIPE_THRESHOLD = 50;

  const handleTouchStart = (e: TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
    touchSwiping.current = false;
  };

  const handleTouchMove = (e: TouchEvent) => {
    if (touchStartX.current === null || touchStartY.current === null) return;
    const dx = e.touches[0].clientX - touchStartX.current;
    const dy = e.touches[0].clientY - touchStartY.current;
    if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 10) {
      touchSwiping.current = true;
    }
  };

  const handleTouchEnd = (e: TouchEvent) => {
    if (touchStartX.current === null) {
      return;
    }
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    touchStartX.current = null;
    touchStartY.current = null;
    if (!touchSwiping.current || Math.abs(dx) < SWIPE_THRESHOLD) return;
    if (dx < 0 && hasNext) onNext?.();
    else if (dx > 0 && hasPrevious) onPrevious?.();
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowLeft' && hasPrevious && onPrevious) {
        onPrevious();
      } else if (e.key === 'ArrowRight' && hasNext && onNext) {
        onNext();
      } else if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
        const el = scrollRef.current;
        if (!el) return;
        e.preventDefault();
        const delta = e.key === 'ArrowDown' ? 80 : -80;
        el.scrollBy({ top: delta, behavior: 'smooth' });
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose, onPrevious, onNext, hasPrevious, hasNext]);

  const showCounter =
    typeof currentIndex === 'number' && typeof totalCount === 'number' && totalCount > 1;

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-sm">
      <header
        className="absolute top-0 inset-x-0 z-20 flex items-center gap-4 px-4 sm:px-6 py-3 bg-black/50 backdrop-blur-md border-b border-white/10"
        onClick={(e) => e.stopPropagation()}
      >
        <p className="flex-1 min-w-0 text-sm sm:text-[15px] tracking-wide leading-snug truncate">
          {title && (
            <span className="text-white font-medium mr-2">{title}</span>
          )}
          <span className="text-white/70">{alt || 'Untitled'}</span>
        </p>

        {showCounter && (
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onPrevious?.();
              }}
              disabled={!hasPrevious}
              aria-label="Previous image"
              className="p-1.5 rounded-full border border-white/10 text-white/60 hover:text-white hover:border-white/30 transition-all duration-200 disabled:opacity-25 disabled:pointer-events-none"
            >
              <ChevronLeft size={14} />
            </button>
            <span className="text-xs tabular-nums tracking-wide text-white/50">
              {(currentIndex ?? 0) + 1} of {totalCount}
            </span>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onNext?.();
              }}
              disabled={!hasNext}
              aria-label="Next image"
              className="p-1.5 rounded-full border border-white/10 text-white/60 hover:text-white hover:border-white/30 transition-all duration-200 disabled:opacity-25 disabled:pointer-events-none"
            >
              <ChevronRight size={14} />
            </button>
          </div>
        )}

        <button
          className="shrink-0 p-1.5 rounded-full text-white/70 hover:text-white hover:bg-white/10 transition-colors"
          onClick={onClose}
          aria-label="Close"
        >
          <X size={20} />
        </button>
      </header>

      <div
        ref={scrollRef}
        className="absolute inset-0 overflow-y-auto no-scrollbar flex flex-col items-center justify-start pt-20 pb-12"
        onClick={onClose}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <img
          src={src}
          alt={alt}
          className="max-w-full w-auto rounded-lg mx-auto select-none"
          draggable={false}
          onClick={(e) => e.stopPropagation()}
        />
      </div>
    </div>
  );
};

export default ImageModal;
