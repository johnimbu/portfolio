import { useRef, useState, TouchEvent } from 'react';
import { Expand, Layers } from 'lucide-react';

type ThumbItem = { src: string; alt: string };

interface MobileMediaThumbProps {
  items: ThumbItem[];
  caption?: string;
  before?: boolean;
  onOpen: (src: string, alt: string, group: ThumbItem[]) => void;
}

const SWIPE_THRESHOLD = 40;

const MobileMediaThumb = ({ items, caption, before, onOpen }: MobileMediaThumbProps) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const touchStartX = useRef<number | null>(null);
  const touchStartY = useRef<number | null>(null);
  const didSwipe = useRef(false);

  if (items.length === 0) return null;
  const isCarousel = items.length > 1;
  const clamped = Math.min(Math.max(activeIndex, 0), items.length - 1);
  const current = items[clamped];
  const label = caption ?? current.alt;

  const handleTouchStart = (e: TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
    didSwipe.current = false;
  };

  const handleTouchMove = (e: TouchEvent) => {
    if (touchStartX.current === null || touchStartY.current === null) return;
    const dx = e.touches[0].clientX - touchStartX.current;
    const dy = e.touches[0].clientY - touchStartY.current;
    if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 10) {
      didSwipe.current = true;
    }
  };

  const handleTouchEnd = (e: TouchEvent) => {
    if (touchStartX.current === null) return;
    const endX = e.changedTouches[0].clientX;
    const dx = endX - touchStartX.current;
    touchStartX.current = null;
    touchStartY.current = null;

    if (!isCarousel) return;
    if (Math.abs(dx) < SWIPE_THRESHOLD) return;

    if (dx < 0) {
      setActiveIndex((i) => Math.min(items.length - 1, i + 1));
    } else {
      setActiveIndex((i) => Math.max(0, i - 1));
    }
  };

  const handleClick = () => {
    if (didSwipe.current) {
      didSwipe.current = false;
      return;
    }
    onOpen(current.src, current.alt, items);
  };

  return (
    <div className="md:hidden w-full mt-6">
      <button
        type="button"
        onClick={handleClick}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        className={`group relative block w-full rounded-xl overflow-hidden border shadow-xl active:scale-[0.99] transition-transform ${
          before ? 'border-red-500/25' : 'border-cream/15'
        }`}
        aria-label={isCarousel ? `Open gallery: ${label}` : `Open image: ${label}`}
      >
        <div className="relative aspect-[16/10] w-full bg-cosmic-dark/40 overflow-hidden">
          <div
            className="absolute inset-0 flex transition-transform duration-300 ease-out"
            style={{ transform: `translateX(-${clamped * 100}%)` }}
          >
            {items.map((item) => (
              <img
                key={item.src}
                src={item.src}
                alt={item.alt}
                className="w-full h-full flex-shrink-0 object-cover object-top"
                draggable={false}
              />
            ))}
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-cosmic-black/80 via-cosmic-black/10 to-transparent pointer-events-none" />

          {before && (
            <span className="absolute top-2.5 left-2.5 z-10 text-[10px] font-semibold uppercase tracking-widest px-2 py-0.5 rounded-full bg-red-900/70 border border-red-500/40 text-red-200">
              Before
            </span>
          )}

          <div className="absolute top-2.5 right-2.5 z-10 flex items-center gap-1.5 px-2 py-1 rounded-full bg-cosmic-black/70 backdrop-blur-sm border border-cream/15 text-cream/85 text-[11px] font-medium tracking-wide">
            {isCarousel ? (
              <>
                <Layers size={12} strokeWidth={2.25} />
                <span className="tabular-nums">
                  {clamped + 1}/{items.length}
                </span>
              </>
            ) : (
              <>
                <Expand size={12} strokeWidth={2.25} />
                <span>View</span>
              </>
            )}
          </div>

          <div className="absolute inset-x-0 bottom-0 p-3 flex items-end pointer-events-none">
            <span className="text-cream/85 text-xs leading-snug line-clamp-2">
              {label}
            </span>
          </div>
        </div>
      </button>

      {isCarousel && (
        <div className="mt-2 flex items-center gap-1.5">
          {items.slice(0, 6).map((_, i) => (
            <span
              key={i}
              className={`h-1 flex-1 rounded-full transition-colors duration-200 ${
                i === clamped ? 'bg-cream/70' : 'bg-cream/20'
              }`}
            />
          ))}
          <span className="ml-1 text-cream/40 text-[10px] tabular-nums tracking-wider">
            Swipe or tap
          </span>
        </div>
      )}
    </div>
  );
};

export default MobileMediaThumb;
