import React from 'react';
import { ArrowUpRight } from 'lucide-react';
import { CaseStudy } from '../types';

interface CaseStudyCardProps {
  caseStudy: CaseStudy;
  index: number;
  onClick: () => void;
}

const CaseStudyCard = ({ caseStudy, index, onClick }: CaseStudyCardProps) => {
  const isEven = index % 2 === 0;
  const animationClass = isEven ? 'animate-fade-in-left' : 'animate-fade-in-right';
  const isShopifyCase = caseStudy.title.includes('Shopify');

  const getCardImage = () => {
    if (caseStudy.title.includes('Shopify')) return '/shopify_hero.webp';
    if (caseStudy.title.includes('Smithfield')) return '/smithfield1.webp';
    if (caseStudy.title.includes('Second City')) return '/secondcity01.webp';
    if (caseStudy.title.includes('Advicent')) return '/advicent01.webp';
    if (caseStudy.title.includes('ADP')) return '/adp01.webp';
    if (caseStudy.title.includes('Top Derm')) return '/topderm1.webp';
    if (caseStudy.title.includes('Scene+')) return 'https://images.pexels.com/photos/6802042/pexels-photo-6802042.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2';
    return caseStudy.image;
  };

  const getRoles = () => {
    if (isShopifyCase) return ['Design Lead', 'Mission Lead'];
    if (caseStudy.title.includes('Second City')) return ['UX Designer', 'UX Researcher'];
    if (caseStudy.title.includes('Smithfield')) return ['UX / UI Design Lead'];
    if (caseStudy.title.includes('Advicent')) return ['UX Designer', 'UX Researcher'];
    if (caseStudy.title.includes('ADP')) return ['Lead UX Designer', 'Research Assistant'];
    if (caseStudy.title.includes('Top Derm')) return ['UX Manager', 'UX Design Lead'];
    if (caseStudy.title.includes('Scene+')) return ['Lead UX Designer'];
    return [];
  };
  
  return (
    <div
      className={`group relative overflow-hidden rounded-lg cursor-pointer animate-on-scroll opacity-0 transition-all duration-500 border border-paper-rule hover:border-cobalt/30 ${animationClass}`}
      data-animation={animationClass}
      data-case-study-id={caseStudy.id}
      onClick={onClick}
    >
      <div className="relative">
        {/* Image */}
        <div className="overflow-hidden aspect-[4/3]">
          <img
            src={getCardImage()}
            alt={caseStudy.title}
            className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105 [filter:saturate(0%)_brightness(65%)_contrast(115%)]"
          />
        </div>

        {/* Content */}
        <div className="absolute inset-0 flex flex-col justify-end p-8 bg-gradient-to-t from-ink/90 via-ink/55 to-transparent">
          {/* Arrow Icon */}
          <div className="absolute top-8 right-8">
            <span className="h-10 w-10 rounded-full bg-cobalt flex items-center justify-center text-cream transform translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
              <ArrowUpRight size={20} />
            </span>
          </div>

          <div className="transform transition-all duration-300">
            {/* Title */}
            <h3 className="text-2xl font-display font-bold mb-3 text-cobalt" style={{ letterSpacing: '-0.02em' }}>
              {caseStudy.title}
            </h3>

            {/* Tagline */}
            <p className="text-cream/80 mb-4 font-sans text-sm leading-relaxed">
              {caseStudy.tagline}
            </p>

            {/* Tags */}
            <div className="flex flex-wrap gap-2">
              {getRoles().map((role, i) => (
                <span
                  key={i}
                  className="text-xs px-2.5 py-1 rounded-full bg-ink/80 backdrop-blur-sm border border-cream/15 text-cream/75 font-sans font-600 tracking-wide"
                  style={{ letterSpacing: '0.05em' }}
                >
                  {role}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CaseStudyCard;