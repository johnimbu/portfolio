import { FormEvent, useEffect, useRef, useState } from 'react';
import { Lock, X } from 'lucide-react';

const STORAGE_KEY = 'ji-case-study-unlocked';
const PASSWORD = 'iterate';

export const isUnlocked = () => {
  try {
    return localStorage.getItem(STORAGE_KEY) === 'true';
  } catch {
    return false;
  }
};

const markUnlocked = () => {
  try {
    localStorage.setItem(STORAGE_KEY, 'true');
  } catch {
    /* ignore storage errors */
  }
};

interface Props {
  onUnlock: () => void;
  onClose: () => void;
}

const PasswordGate = ({ onUnlock, onClose }: Props) => {
  const [value, setValue] = useState('');
  const [error, setError] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    inputRef.current?.focus();
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, []);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (value.trim().toLowerCase() === PASSWORD) {
      markUnlocked();
      onUnlock();
    } else {
      setError(true);
      setTimeout(() => setError(false), 1600);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-cosmic-black/90 backdrop-blur-md px-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="password-gate-title"
      onWheel={(e) => e.preventDefault()}
      onTouchMove={(e) => e.preventDefault()}
    >
      <div
        className={`relative w-full max-w-md rounded-2xl border border-white/10 bg-cosmic-dark/95 shadow-2xl overflow-hidden ${
          error ? 'animate-shake' : ''
        }`}
      >
        <div
          className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-accent-teal/50 to-transparent"
          aria-hidden
        />

        <button
          type="button"
          onClick={onClose}
          aria-label="Close and return home"
          className="absolute top-3 right-3 p-2 rounded-full text-white/50 hover:text-white hover:bg-white/5 transition-colors"
        >
          <X size={18} />
        </button>

        <div className="p-8 md:p-10">
          <div className="flex items-center justify-center mb-6">
            <div className="relative">
              <div className="absolute inset-0 rounded-full bg-accent-teal/20 blur-xl" aria-hidden />
              <div className="relative flex items-center justify-center w-14 h-14 rounded-full border border-accent-teal/30 bg-cosmic-black">
                <Lock size={22} className="text-accent-teal" />
              </div>
            </div>
          </div>

          <h2
            id="password-gate-title"
            className="text-center text-xs font-semibold uppercase tracking-[0.25em] text-accent-teal/80 mb-8"
          >
            Password Required
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="password-gate-input" className="sr-only">
                Password
              </label>
              <input
                ref={inputRef}
                id="password-gate-input"
                type="password"
                autoComplete="off"
                value={value}
                onChange={(e) => {
                  setValue(e.target.value);
                  if (error) setError(false);
                }}
                placeholder="Enter password"
                className={`w-full rounded-lg border bg-cosmic-black/60 px-4 py-3.5 text-white placeholder-white/30 outline-none transition-all duration-200 ${
                  error
                    ? 'border-red-500/60 shadow-[0_0_0_4px_rgba(239,68,68,0.08)]'
                    : 'border-white/10 focus:border-accent-teal/60 focus:shadow-[0_0_0_4px_rgba(5,217,232,0.08)]'
                }`}
              />
              <p
                className={`mt-2 text-xs leading-relaxed ${
                  error ? 'text-red-400/90' : 'text-white/40'
                }`}
              >
                {error
                  ? 'Incorrect password. Try again.'
                  : 'Ask John for the password or find it in his resume.'}
              </p>
            </div>

            <button
              type="submit"
              className="w-full rounded-lg bg-accent-teal text-cosmic-black font-semibold py-3.5 transition-all duration-200 hover:bg-accent-teal/90 hover:shadow-cosmic-hover"
            >
              Unlock
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default PasswordGate;
