import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { CaseStudy } from '../types';
import ImageModal from './ImageModal';
import ResultItem from './ResultItem';
import LevelExPrototype from './LevelExPrototype';
import ZoomableImage from './ZoomableImage';
import ScenePlusCaseStudy from './ScenePlusCaseStudy';
import SlideCaseStudy from './SlideCaseStudy';
import {
  shopifyConfig,
  secondCityConfig,
  smithfieldConfig,
  advicentConfig,
} from '../data/slideConfigs';
import { ExternalLink } from 'lucide-react';

interface CaseStudyPageProps {
  caseStudy: CaseStudy;
  onBack: () => void;
  onNextCaseStudy: (nextStudy: CaseStudy) => void;
  allCaseStudies: CaseStudy[];
}

const CaseStudyPage = ({ caseStudy, onBack, onNextCaseStudy, allCaseStudies }: CaseStudyPageProps) => {
  const { slug } = useParams();
  
  const [selectedImage, setSelectedImage] = useState<{ src: string; alt: string } | null>(null);
  const [selectedImageIndex, setSelectedImageIndex] = useState<number>(-1);
  const [imageGallery, setImageGallery] = useState<{ src: string; alt: string }[]>([]);
  const [scrollY, setScrollY] = useState(0);
  
  const currentIndex = allCaseStudies.findIndex(study => study.id === caseStudy.id);
  const nextCaseStudy = allCaseStudies[(currentIndex + 1) % allCaseStudies.length];
  const previousCaseStudy = allCaseStudies[(currentIndex - 1 + allCaseStudies.length) % allCaseStudies.length];

  // Update document title when case study changes
  useEffect(() => {
    document.title = `John Imburgia | ${caseStudy.title}`;
    window.scrollTo(0, 0);

    return () => {
      document.title = 'John Imburgia: UX Design Leader';
    };
  }, [caseStudy.title]);

const isShopifyCase = caseStudy.title.includes('Shopify');
  const isSmithfieldCase = caseStudy.title.includes('Smithfield');
  const isSecondCityCase = caseStudy.title.includes('Second City');
  const isTopDermCase = caseStudy.title.includes('Top Derm');
  const isAdvicentCase = caseStudy.title.includes('Advicent');
  const isADPCase = caseStudy.title.includes('ADP');
  const isLevelExCase = caseStudy.title.includes('Level Ex');
  const isScenePlusCase = caseStudy.title.includes('Scene+');

  const delegatesToSlideComponent =
    isScenePlusCase || isShopifyCase || isSecondCityCase || isSmithfieldCase || isAdvicentCase;

  useEffect(() => {
    if (selectedImage || delegatesToSlideComponent) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        onNextCaseStudy(previousCaseStudy);
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        onNextCaseStudy(nextCaseStudy);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedImage, delegatesToSlideComponent, onNextCaseStudy, nextCaseStudy, previousCaseStudy]);

  const getHeroImage = () => {
    if (isShopifyCase) return '/shopify_hero.webp';
    if (isLevelExCase) return '/topderm1.webp';
    if (isSmithfieldCase) return '/smithfield1.webp';
    if (isSecondCityCase) return '/secondcity01.webp';
    if (isAdvicentCase) return '/advicent01.webp';
    if (isADPCase) return '/adp01.webp';
    if (isTopDermCase) return '/topderm1.webp';
    if (isScenePlusCase) return 'https://images.pexels.com/photos/6802042/pexels-photo-6802042.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2';
    return caseStudy.image;
  };

  const getRoles = () => {
    if (isShopifyCase) return ['Design Lead', 'Mission Lead'];
    if (isLevelExCase) return ['Lead UX Designer', 'UX Manager'];
    if (isSecondCityCase) return ['UX Designer', 'UX Researcher'];
    if (caseStudy.title.includes('Smithfield')) return ['UX / UI Design Lead'];
    if (isAdvicentCase) return ['UX Designer', 'UX Researcher'];
    if (isADPCase) return ['Lead UX Designer', 'Research Assistant'];
    if (isTopDermCase) return ['UX Manager', 'UX Design Lead'];
    if (isScenePlusCase) return ['Lead UX Designer'];
    return [];
  };

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };

    const handleImageClickEvent = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail && customEvent.detail.src && customEvent.detail.alt) {
        handleImageClick(customEvent.detail.src, customEvent.detail.alt);
      }
    };

    window.addEventListener('scroll', handleScroll);
    document.addEventListener('imageClick', handleImageClickEvent);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      document.removeEventListener('imageClick', handleImageClickEvent);
    };
  }, []);

  const handleImageClick = (src: string, alt: string) => {
    // Build gallery based on case study
    let gallery: { src: string; alt: string }[] = [];
    
    if (isAdvicentCase) {
      gallery = [
        { src: "/advicent02.webp", alt: "Card sort and questionnaire research" },
        { src: "/advicent04.webp", alt: "Competitive review and heuristic evaluation" },
        { src: "/advicent05.webp", alt: "User personas and journey mapping" },
        { src: "/advicent06.webp", alt: "Experience flows mapping" },
        { src: "/advicent07.webp", alt: "Workshop with client stakeholders" },
        { src: "/advicent08.webp", alt: "Prioritization matrix" },
        { src: "/advicent09.webp", alt: "Opportunity roadmap" },
        { src: "/advicent11.webp", alt: "Final wireframe composition 2" },
        { src: "/advicent12.webp", alt: "Final wireframe composition 3" },
        { src: "/advicent13.webp", alt: "Final wireframe composition 4" },
        { src: "/advicent14.webp", alt: "Final wireframe composition 5" }
      ];
    } else if (isADPCase) {
      gallery = [
        { src: "/adp05.webp", alt: "Client workshop and stakeholder alignment" },
        { src: "/adp04.webp", alt: "User journey mapping" },
        { src: "/secondcity02.png", alt: "Competitive analysis and user research" },
        { src: "/adp06.webp", alt: "ADP wireframe design 1" },
        { src: "/adp07.webp", alt: "ADP wireframe design 2" },
        { src: "/adp08.webp", alt: "ADP wireframe design 3" },
        { src: "/adp09.webp", alt: "ADP wireframe design 4" },
        { src: "/adp10.webp", alt: "ADP wireframe design 5" },
        { src: "/adp11.webp", alt: "ADP wireframe design 6" },
        { src: "/adp12.webp", alt: "ADP wireframe design 7" }
      ];
    } else if (isScenePlusCase) {
      gallery = [
        { src: "/scene-banking_current.png", alt: "Current Scene+ Banking Experience" },
        { src: "/1.png", alt: "User flow and journey map — top left: phases and user flow overview" },
        { src: "/2.png", alt: "User flow and journey map — top right: user thoughts, feelings and responses" },
        { src: "/3.png", alt: "User flow and journey map — bottom left: activation and confirmation flows" },
        { src: "/4.png", alt: "User flow and journey map — bottom right: additional workshop notes" },
      ];
    } else if (isLevelExCase) {
      gallery = [
        // Will add more images later as requested
      ];
    } else if (isShopifyCase) {
      gallery = [
        { src: "/shopify02.webp", alt: "Cross-functional Montréal workshop" },
        { src: "/TLI.gif", alt: "Shopify Tax Dashboard" },
        { src: "/Reg.gif", alt: "Tax Registration Flow" },
        { src: "/shopify05.png", alt: "Tax Settings Interface" },
        { src: "/shopify06.png", alt: "Tax Settings Interface" },
        { src: "/shopify_tradeoffs.webp", alt: "Tradeoffs" },
        { src: "/shopify07.webp", alt: "Tax Compliance Overview" },
        { src: "/shopify08.png", alt: "Tax Filing Interface" },
        { src: "/Dynamic Tax Exemptions.gif", alt: "Dynamic Tax Exemptions workflow" }
      ];
    } else if (isSmithfieldCase) {
      gallery = [
        { src: "/smithfield2.webp", alt: "Smithfield mood board and branding direction" },
        { src: "/smithfield5.webp", alt: "Smithfield style guide in Abstract" },
        { src: "/smithfield3.webp", alt: "Responsive homepage template" },
        { src: "/smithfield4.webp", alt: "Template variations for different brands" },
        { src: "/smithfield6.webp", alt: "Brand customization examples" }
      ];
    } else if (isSecondCityCase) {
      gallery = [
        { src: "/sc_previous.webp", alt: "Previous Second City website" },
        { src: "/secondcity02.png", alt: "Competitive analysis and user research" },
        { src: "/secondcity03.webp", alt: "Mindmap for determining show order" },
        { src: "/secondcity04.webp", alt: "User personas and scenarios" },
        { src: "/secondcity05.png", alt: "User flows for show discovery" },
        { src: "/secondcity07.webp", alt: "Home page redesign" },
        { src: "/secondcity08.webp", alt: "Show finding redesign" },
        { src: "/secondcity09.webp", alt: "Quick ticket finder" },
        { src: "/secondcity10.webp", alt: "Additional project documentation" }
      ];
    } else if (isTopDermCase) {
      gallery = [
        { src: "/topderm3.png", alt: "Top Derm registration challenge analysis" },
        { src: "/topderm4.png", alt: "Top Derm ideation process against subproblems" },
        { src: "/topderm5.png", alt: "Top Derm implementation details" },
        { src: "/topderm6.png", alt: "Top Derm results visualization" }
      ];
    }
    
    const index = gallery.findIndex(img => img.src === src);
    setImageGallery(gallery);
    setSelectedImageIndex(index);
    setSelectedImage({ src, alt });
  };

  const handlePreviousImage = () => {
    if (selectedImageIndex > 0) {
      const newIndex = selectedImageIndex - 1;
      const newImage = imageGallery[newIndex];
      setSelectedImageIndex(newIndex);
      setSelectedImage(newImage);
    }
  };

  const handleNextImage = () => {
    if (selectedImageIndex < imageGallery.length - 1) {
      const newIndex = selectedImageIndex + 1;
      const newImage = imageGallery[newIndex];
      setSelectedImageIndex(newIndex);
      setSelectedImage(newImage);
    }
  };

  const handleCloseModal = () => {
    setSelectedImage(null);
    setSelectedImageIndex(-1);
    setImageGallery([]);
  };

  if (isScenePlusCase) {
    return (
      <ScenePlusCaseStudy
        caseStudy={caseStudy}
        onBack={onBack}
        onNextCaseStudy={onNextCaseStudy}
        allCaseStudies={allCaseStudies}
      />
    );
  }

  const slideConfig = isShopifyCase
    ? shopifyConfig
    : isSecondCityCase
    ? secondCityConfig
    : isSmithfieldCase
    ? smithfieldConfig
    : isAdvicentCase
    ? advicentConfig
    : null;

  if (slideConfig) {
    return (
      <SlideCaseStudy
        caseStudy={caseStudy}
        onNextCaseStudy={onNextCaseStudy}
        allCaseStudies={allCaseStudies}
        config={slideConfig}
      />
    );
  }

  const renderImage = (src: string, alt: string, caption?: string) => {
    const displayCaption = caption ?? alt;
    return (
      <div className="my-8">
        <img
          src={src}
          alt={alt}
          className="rounded-lg w-full cursor-pointer transition-transform hover:scale-[1.02]"
          onClick={() => handleImageClick(src, alt)}
        />
        {displayCaption && (
          <p className="text-white/60 text-sm mt-2 text-center italic">{displayCaption}</p>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-cosmic-black">
      <div className="relative h-screen overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url(${getHeroImage()})`,
            transform: `translateY(${scrollY * 0.5}px)`,
          }}
        />
        
        <div className="absolute inset-0 bg-gradient-to-b from-cosmic-black/60 via-cosmic-black/50 to-cosmic-black"></div>
        <div className="absolute inset-0 bg-cosmic-black/45"></div>

        <div className="absolute inset-0 flex items-center">
          <div className="container mx-auto px-4 md:px-8">
            <div className="max-w-4xl">
              <h1
                className="text-5xl md:text-6xl lg:text-7xl font-display mb-8 text-white"
                style={{ transform: `translateY(${scrollY * 0.2}px)` }}
              >
                {caseStudy.title}
              </h1>

              <div
                style={{ transform: `translateY(${scrollY * 0.15}px)` }}
              >
                <div className="flex items-center gap-4 mb-12">
                  <span className="text-white/50 text-sm font-medium tracking-wider uppercase">
                    My Role
                  </span>
                  <div className="flex flex-wrap gap-3">
                    {getRoles().map((role, index) => (
                      <span
                        key={index}
                        className="px-4 py-1.5 rounded-full bg-cosmic-dark/80 backdrop-blur-sm border border-accent-teal/30 text-accent-teal text-sm font-medium"
                      >
                        {role}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              {isADPCase && renderImage("/adp05.webp", "Client workshop and stakeholder alignment")}

              <div 
                className="space-y-4"
                style={{ transform: `translateY(${scrollY * 0.1}px)` }}
              >
                {caseStudy.challenge && (
                  <div className="text-lg text-white/90 leading-relaxed max-w-2xl bg-cosmic-dark/90 backdrop-blur-sm p-8 rounded-lg border border-white/10 shadow-lg">
                    <h2 className="text-2xl md:text-3xl font-display mb-4 text-accent-teal">Challenge</h2>
                    {caseStudy.challenge.map((paragraph, i) => (
                      <p key={i} className="mb-4" dangerouslySetInnerHTML={{ __html: paragraph }}></p>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-8 py-32">
        <article className="max-w-4xl mx-auto">
          {caseStudy.solution && (
            <>
              <h2 className="text-2xl md:text-3xl font-display mb-6 text-accent-teal">Approach</h2>
              <div className="bg-cosmic-dark/90 backdrop-blur-sm p-8 rounded-lg border border-white/10 shadow-lg mb-12">
                {caseStudy.solution.map((paragraph, i) => {
                  if (isShopifyCase && i === caseStudy.solution.length - 1) {
                    return (
                      <React.Fragment key={i}>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>
                        {renderImage("/shopify02.webp", "Our cross-functional workshop in Montréal", "Our cross-functional workshop in Montréal")}
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">
                          After aligning cross-functionally, we pitched the proposed solutions to senior leadership and confirmed the feature mix as our MVP foundation. We also agreed to keep supporting the free Manual Tax product, ensuring merchants always had access to a no-cost option.
                        </p>
                      </React.Fragment>
                    );
                  }
                  if (isShopifyCase && i === 0) {
                    return (
                      <React.Fragment key={i}>
                        <h3 className="text-xl md:text-2xl font-display mb-6 text-accent-violet">Discovery</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">To start, I audited Shopify’s legacy tax product for EU and UK merchants to understand its capabilities and gaps. It quickly became clear how limited the experience was—merchants could only enter rates manually, with no automation, guidance, or visibility into where they might owe tax.</p>
                        {renderImage("/shopify_manual.webp", "Manual Tax product comparison")}
                        <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>
                      </React.Fragment>
                    );
                  }
                  if (isSecondCityCase && i === 0) {
                    return (
                      <React.Fragment key={i}>
                        <h3 className="text-xl md:text-2xl font-display mb-6 text-accent-violet">Discovery</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>
                      </React.Fragment>
                    );
                  }
                  if (isSecondCityCase && i === 1) {
                    return (
                      <React.Fragment key={i}>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">To better understand user behavior, I dug into The Second City’s robust analytics and paired those findings with stakeholder interviews and competitive research. This helped surface how audiences actually discovered and purchased shows, and revealed opportunities to highlight key performances and simplify navigation. I compiled these insights into a discovery brief and presented it back to the team to align on goals and priorities for the redesign.</p>
                      </React.Fragment>
                    );
                  }
                  if (isSecondCityCase && i === 2) {
                    return (
                      <React.Fragment key={i}>
                        {renderImage("/secondcity02.png", "Competitive analysis and user research")}
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">One key insight from the analytics was a clear divide between near-term mobile buyers and long-term desktop planners—forming the basis for two primary user types:</p>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>
                      </React.Fragment>
                    );
                  }
                  if (isSmithfieldCase && i === 0) {
                    return (
                      <React.Fragment key={i}>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>
                        {renderImage("/smithfield2.webp", "Smithfield mood board and branding direction")}
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">
                         Once we aligned with the brand teams on the aesthetic, we translated the direction into a shared style guide and lightweight design system in Abstract. Using accessibility tools like Contraste, we validated color contrast and ensured components met WCAG standards. This provided design and development partners with a single source of truth and made it easy to efficiently adapt and re-skin the system across Smithfield's portfolio of brands.
                        </p>
                        {renderImage("/smithfield5.webp", "Smithfield style guide in Abstract")}
                      </React.Fragment>
                    );
                  }
                  if (isAdvicentCase && i === 0) {
                    return (
                      <React.Fragment key={i}>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>
                        {renderImage("/advicent02.webp", "Card sort and questionnaire research")}
                        {renderImage("/advicent04.webp", "Competitive review and heuristic evaluation")}
                      </React.Fragment>
                    );
                  }
                  if (isTopDermCase && i === 0) {
                    return (
                      <React.Fragment key={i}>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>
                        {renderImage("/topderm3.png", "Top Derm registration challenge analysis")}
                      </React.Fragment>
                    );
                  }
                  if (isScenePlusCase && i === 0) {
                    return (
                      <React.Fragment key={i}>
                        <h3 className="text-xl md:text-2xl font-display mb-6 text-accent-violet">Discovery</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>
                        <div className="my-8">
                          <div className="inline-block mb-3">
                            <span className="text-xs font-semibold uppercase tracking-widest px-3 py-1 rounded-full bg-red-900/40 border border-red-500/30 text-red-300">
                              Current Experience
                            </span>
                          </div>
                          <div
                            className="rounded-lg overflow-hidden border border-red-500/20 bg-red-950/20 cursor-pointer relative group"
                            onClick={() => handleImageClick('/scene-banking_current.png', 'Current Scene+ Banking Experience')}
                          >
                            <div
                              className="w-full"
                              style={{ height: '320px', overflow: 'hidden' }}
                            >
                              <img
                                src="/scene-banking_current.png"
                                alt="Current Scene+ Banking Experience"
                                className="w-full transition-transform duration-300 group-hover:scale-[1.02]"
                                style={{ objectFit: 'cover', objectPosition: 'top' }}
                              />
                            </div>
                            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-red-950/60 pointer-events-none" />
                          </div>
                          <p className="text-white/50 text-sm mt-2 text-center italic">
                            Content-dense, relying on iframes to surface cards — lacking modern aesthetics and seamless brand integration
                          </p>
                        </div>

                        <h3 className="text-xl md:text-2xl font-display mb-6 mt-12 text-accent-violet">Establishing a Shared Foundation</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">
                          With the problem space clearly defined, my next priority was ensuring every stakeholder entered the design process from the same starting point. Redesigning an experience that spanned two banks and a loyalty platform meant there were multiple definitions of success, different interpretations of what the user needed, and potentially competing priorities around brand. To navigate that complexity before a single pixel was designed, I built out a combined user flow and journey map that brought together the relevant jobs to be done across the full experience — from a member first discovering the card offer through to post-application follow-up.
                        </p>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">
                          Rather than working in isolation and presenting something complete, I brought in brand representatives from both Scotiabank and Tangerine early in the process. I worked directly with them to ensure that each bank's unique user needs, messaging priorities, and touchpoints were accurately reflected. This wasn't a one-size-fits-all document — it needed to account for two distinct banking experiences operating within a shared rewards ecosystem, and that required both banks to have real ownership over what was mapped.
                        </p>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">
                          Once the draft was in strong enough shape, I facilitated an alignment workshop with the broader cross-functional group — including stakeholders from Scene+, both banks, and our internal team. The session gave everyone a chance to pressure-test the flows, surface edge cases, challenge assumptions, and align on where the experience should begin and end from each bank's perspective. The artifact we refined together became the north star for the entire project: a single document that clarified user intent at every stage and gave the team a shared language for making design decisions going forward.
                        </p>

                        <ZoomableImage src="/uj.webp" alt="User Flow & Journey Map" />
                      </React.Fragment>
                    );
                  }
                  if (isLevelExCase && i === 0) {
                    return (
                      <React.Fragment key={i}>
                        <h3 className="text-xl md:text-2xl font-display mb-6 text-accent-violet">Discovery</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>
                      </React.Fragment>
                    );
                  }
                  if (isLevelExCase && i === 3) {
                    return (
                      <React.Fragment key={i}>
                        <h3 className="text-xl md:text-2xl font-display mb-6 mt-12 text-accent-violet">Scenarios</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>
                      </React.Fragment>
                    );
                  }
                  return <p key={i} className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>;
                })}
                {isTopDermCase && renderImage("/topderm4.png", "Top Derm ideation process against subproblems")}
                {isShopifyCase && (
                  <>
                    <h3 className="text-xl md:text-2xl font-display mb-6 mt-12 text-accent-violet">Process</h3>
                    <p className="text-lg text-white/90 mb-8 leading-relaxed">
                      We structured the work into feature-based projects, each moving through proposal, prototype, build, and release—with regular checkpoints to stay aligned across teams and leadership. To keep momentum as tracks overlapped, I brought on a senior designer to lead parallel workstreams. We began with liability tracking, the foundation for the entire system.
                    </p>
                    {renderImage("/shopify_process.png", "Shopify Tax product development process", "My preferred process is highly collaborative and transparent, which keeps up momentum")}
                  </>
                )}
              </div>
            </>
          )}

          {caseStudy.implementation && (
            <>
              <h2 className="text-2xl md:text-3xl font-display mb-6 mt-12 text-accent-teal">Implementation</h2>
              <div className="bg-cosmic-dark/90 backdrop-blur-sm p-8 rounded-lg border border-white/10 shadow-lg">
                {caseStudy.implementation.map((paragraph, i) => {
                  if (isShopifyCase && i === 0) {
                    return (
                      <React.Fragment key={i}>
                        <h3 className="text-xl md:text-2xl font-display mb-6 text-accent-violet">1. Tax Liability Insights</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">In the U.S. product, liability insights and tax collection lived in separate cards — two competing UI elements aimed at the same job-to-be-done of tax collection.</p>
                        {renderImage("/shopify_legacyUS.webp", "Legacy US Tax Product")}
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">For the EU/UK, we saw an opportunity to leapfrog the existing experience by consolidating liability awareness and tax collection. We created a unified tracking and collection flow. Merchants could monitor liabilities as they neared 80% of their threshold, with email and in-admin alerts prompting timely action. The popover reduced clutter, surfaced region-specific insights, and tested well—merchants grasped it immediately. This became the foundation for a simpler, more unified global standard for liability tracking.</p>
                        {renderImage("/shopify_tli-rejects.webp", "Tax Liability Insights design iterations")}
                        {renderImage("/TLI.gif?v=" + Date.now(), "Shopify Tax Dashboard", "Popovers effectively surfaced timely, region-specific visualizations and insights")}
                      </React.Fragment>
                    );
                  }
                  else if (isShopifyCase && i === 1) {
                    return (
                      <React.Fragment key={i}>
                        <h3 className="text-xl md:text-2xl font-display mb-6 mt-12 text-accent-violet">2. VAT Registration</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">As a merchant’s business grows, their tax registrations and exemptions often need to evolve with it. Our goal was to design a system that grows alongside them—communicating at the right moments in their journey to keep them informed, compliant, and confident in their next steps.</p>
                        {renderImage("/Reg.gif", "Tax Registration Flow", "Banners are Shopify’s standard for alerting merchants to important changes or ongoing issues")}
                      </React.Fragment>
                    );
                  }
                  else if (isShopifyCase && i === 2) {
                    return (
                      <React.Fragment key={i}>
                        <h3 className="text-xl md:text-2xl font-display mb-6 mt-12 text-accent-violet">3. VAT Invoices</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">In the EU and UK, merchants must provide VAT invoices for applicable transactions. To support this, we introduced a toggle to enable VAT invoices, ensuring compliance while preventing duplicate sends for merchants using third-party invoicing tools.</p>
                        {renderImage("/shopify06.png", "Tax Settings Interface")}
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">One of the most critical design decisions was determining when and where merchants and buyers should access VAT invoices. We explored multiple entry points before aligning on the buyer and merchant order screens as the most intuitive, scalable, and low-friction options.</p>
                        {renderImage("/shopify_tradeoffs.webp", "Tradeoffs")}
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">VAT invoices had to meet strict legal and merchant requirements while remaining simple to use. Each needed to include complete order, buyer, and tax details—accurate rates, totals, and regional numbering—while adapting to different languages, currencies, and order sizes. I collaborated with teams like B2B and Split Cart to align on shared data needs, such as purchase order numbers and multi-invoice orders. Within our team, we handled complex cases like refunds and reverse charges, ensuring invoices stayed compliant and easy to manage. The design itself was intentionally neutral and utilitarian, prioritizing clarity and letting each merchant’s brand take the lead.</p>
                        {renderImage("/shopify07.webp", "Tax Compliance Overview")}
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">To enable a dynamic and compliant VAT invoice template, I mapped out all country-specific requirements. Our engineering team then used this companion document to build the dynamic template using an html-to-pdf creator.</p>
                        {renderImage("/shopify05.png", "Tax Settings Interface")}
                        
                        <h3 className="text-xl md:text-2xl font-display mb-6 mt-12 text-accent-violet">4. Product Categories</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">Previously, merchants could categorize products for tax, but not in bulk—making the process slow and error-prone. We partnered with the Bulk Editor team to design a faster workflow that let merchants assign or override suggested categories at scale, directly within the tax experience as part of a subtask. In-admin alerts reminded them when products were uncategorized, helping keep exemptions accurate and compliance effortless across regions.</p>
                        {renderImage("/shopify08.png", "Tax Filing Interface")}
                        
                        <h3 className="text-xl md:text-2xl font-display mb-6 mt-12 text-accent-violet">5. B2B Tax Exemptions</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">One of the most requested features for Shopify Tax EU & UK was a VAT ID checker—helping merchants confidently zero-rate VAT for eligible customers at checkout. We built an automated system that validates VAT IDs in real time, flags B2B customers, and applies the correct exemptions. Valid IDs are also pulled directly into VAT invoices, streamlining compliance while creating a smoother experience for merchants and their customers.</p>
                        {renderImage("/Dynamic Tax Exemptions.gif", "Dynamic Tax Exemptions workflow")}
                      </React.Fragment>
                    );
                  }
                  else if (isShopifyCase && i === 3) {
                    return (
                      <React.Fragment key={i}>
                        <h3 className="text-xl md:text-2xl font-display mb-6 mt-12 text-accent-violet">4. Product Categories</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">Previously, merchants struggled to categorize products efficiently — the feature existed, but bulk categorization wasn't supported. To solve this, we partnered with the Bulk Editor team to design a workflow that allowed merchants to assign categories in bulk, directly accessible from the taxes experience. We also introduced periodic in-admin alerts when products were left uncategorized, guiding merchants to resolve them quickly. This ensured exemptions were automatically applied across regions while giving merchants a faster, more scalable way to stay compliant.</p>
                        {renderImage("/shopify08.png", "Tax Filing Interface")}
                        
                        <h3 className="text-xl md:text-2xl font-display mb-6 mt-12 text-accent-violet">5. B2B Tax Exemptions</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">One of the most requested features for Shopify Tax EU & UK was a VAT ID checker—helping merchants confidently zero-rate VAT for eligible customers at checkout. We built an automated system that validates VAT IDs in real time, flags B2B customers, and applies the correct exemptions. Valid IDs are also pulled directly into VAT invoices, streamlining compliance while creating a smoother experience for merchants and their customers.</p>
                        {renderImage("/Dynamic Tax Exemptions.gif", "Dynamic Tax Exemptions workflow")}
                      </React.Fragment>
                    );
                  }
                  else if (isScenePlusCase && i === 0) {
                    return (
                      <React.Fragment key={i}>
                        {renderImage("/2-banks-1-reward-program.gif", "Two banks, one rewards program landing page", "A hero that introduced both banking partners within the Scene+ ecosystem")}
                        {renderImage("/feature-toggle.gif", "Scene+ feature toggle interaction", "")}
                        {renderImage("/filter-table-highlighter.gif", "Scene+ card filter and comparison table interaction", "Filter chips and table row highlighting let members surface the right card without reading fine print")}
                        {renderImage("/iterative-process.webp", "Iterative design process across concept versions", "A snapshot of the iterative workshop board tracking design evolution across multiple concept versions")}
                        {renderImage("/bento-grid.webp", "Scene+ bento grid feature layout", "")}
                        {renderImage("/process-lifestyle-key-perks.webp", "Process lifestyle and key perks", "")}
                        {renderImage("/5-breakpoints.webp", "Responsive design across 5 breakpoints", "")}
                      </React.Fragment>
                    );
                  }
                  else if (isSecondCityCase && i === 0) {
                    return (
                      <React.Fragment key={i}>
                        <h3 className="text-xl md:text-2xl font-display mb-6 text-accent-violet">Determining The Ideal Show Order</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">I led whiteboarding sessions with stakeholders to define a show-ordering approach that balanced user expectations with business goals. We agreed on a chronological foundation, layered with prioritization to surface headline shows above student performances. To support high-intent mobile users, we added urgency indicators like 'tickets remaining,' and grouped well-known shows into large, prioritized tiles to highlight key content.</p>
                        {renderImage("/secondcity03.webp", "Mindmap for determining show order")}
                      </React.Fragment>
                    );
                  }
                  else if (isSecondCityCase && i === 1) {
                    return (
                      <React.Fragment key={i}>
                        <h3 className="text-xl md:text-2xl font-display mb-6 mt-12 text-accent-violet">User Scenarios and Flows</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">To support both near-term and exploratory behaviors, I mapped out a flexible user flow that accommodated the needs of high-intent users ready to buy and lower-intent users who required more information before converting.</p>
                        {renderImage("/secondcity05.png", "User flows for show discovery")}
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">We identified several additional user types beyond our core segments—like travelers searching for touring shows, families looking for age-appropriate options, and audiences specifically seeking improv rather than stand-up, etc. By mapping flows around these behaviors, we designed pathways tailored to each scenario, ensuring intuitive navigation and a seamless experience across devices.</p>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">Each scenario was paired with a clickable prototype, allowing stakeholders to move through the proposed designs and build empathy for each persona.</p>
                        {renderImage("/secondcity04.webp", "User personas and scenarios")}
                      </React.Fragment>
                    );
                  }
                  else if (isSecondCityCase && i === 2) {
                    return (
                      <React.Fragment key={i}>
                        <h4 className="text-lg md:text-xl font-display mb-4 mt-8 text-accent-violet">Homepage</h4>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">For the homepage, we carried forward Second City's fun, energetic aesthetic while simplifying the path into the core experience. We emphasized date selection and ticket availability to make finding a show quick and intuitive, while featuring popular and flagship performances to highlight what's on now. The design balances playful brand expression with a clear entry point for users across desktop and mobile.</p>
                        {renderImage("/secondcity07.webp", "Home page redesign")}
                      </React.Fragment>
                    );
                  }
                  else if (isSecondCityCase && i === 3) {
                    return (
                      <React.Fragment key={i}>
                        <h4 className="text-lg md:text-xl font-display mb-4 mt-8 text-accent-violet">Show Results</h4>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">The results page was designed to make browsing simple and intuitive. Shows were ordered chronologically, with headline performances prioritized over student and touring shows. Key details like dates, times, and ticket availability were surfaced directly in the listings to help users quickly evaluate options. The layout balanced efficiency with flexibility, giving users a clear overview while supporting deeper exploration.</p>
                        {renderImage("/secondcity08.webp", "Show finding redesign")}
                      </React.Fragment>
                    );
                  }
                  else if (isSecondCityCase && i === 4) {
                    return (
                      <React.Fragment key={i}>
                        <h4 className="text-lg md:text-xl font-display mb-4 mt-8 text-accent-violet">Show Detail Quick View</h4>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">To streamline fast browsing for high-intent mobile users, we introduced a quick-view modal directly from the results list. This created a subtask flow where users could preview details and evaluate options without losing their place, keeping the experience lightweight and momentum in the purchase funnel.</p>
                        {renderImage("/secondcity09.webp", "Quick ticket finder")}
                        <h4 className="text-lg md:text-xl font-display mb-4 mt-8 text-accent-violet">Show Detail View</h4>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">For exploratory users, we designed a comprehensive show detail page that surfaced everything in one place—show description, cast, reviews, and key logistics alongside an embedded calendar of upcoming dates. This reduced the need for additional navigation and gave focused-intent users arriving on specific pages a clear view of all available performances, helping them move seamlessly from discovery to purchase.</p>
                        {renderImage("/secondcity10.webp", "Additional project documentation")}
                      </React.Fragment>
                    );
                  }
                  else if (isSecondCityCase && i === 5) {
                    return (
                      <React.Fragment key={i}>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>
                      </React.Fragment>
                    );
                  }
                  else if (isSecondCityCase && i === 6) {
                    return (
                      <React.Fragment key={i}>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>
                      </React.Fragment>
                    );
                  }
                  else if (isAdvicentCase && i === 1) {
                    return (
                      <React.Fragment key={i}>
                        {renderImage("/advicent05.webp", "User personas and journey mapping")}
                        {renderImage("/advicent06.webp", "Experience flows mapping")}
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">We hosted a 3-day workshop with Advicent to review and prioritize the findings from our research, identifying core areas for improvement.</p>
                        {renderImage("/advicent07.webp", "Workshop with client stakeholders")}
                        {renderImage("/advicent08.webp", "Prioritization matrix")}
                        {renderImage("/advicent09.webp", "Opportunity roadmap")}
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">Following the workshop, we refined the findings in consultation with Advicent and prioritized ten key themes for the initial release:</p>
                        <div className="bg-cosmic-light/30 border border-white/5 rounded-lg p-6 my-6">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2 text-sm text-white/80">
                            <div className="flex items-start"><span className="text-accent-violet font-medium mr-2">1.</span>Align advisor and client experiences</div>
                            <div className="flex items-start"><span className="text-accent-violet font-medium mr-2">2.</span>Use a 'core and layers' approach</div>
                            <div className="flex items-start"><span className="text-accent-violet font-medium mr-2">3.</span>Improve advisor workflow efficiency</div>
                            <div className="flex items-start"><span className="text-accent-violet font-medium mr-2">4.</span>Integrate guidance throughout</div>
                            <div className="flex items-start"><span className="text-accent-violet font-medium mr-2">5.</span>Deploy common design standards</div>
                            <div className="flex items-start"><span className="text-accent-violet font-medium mr-2">6.</span>Provide default values using data</div>
                            <div className="flex items-start"><span className="text-accent-violet font-medium mr-2">7.</span>Apply the 80/20 rule</div>
                            <div className="flex items-start"><span className="text-accent-violet font-medium mr-2">8.</span>Use big data for benchmarking</div>
                            <div className="flex items-start"><span className="text-accent-violet font-medium mr-2">9.</span>Empower client interactivity</div>
                            <div className="flex items-start"><span className="text-accent-violet font-medium mr-2">10.</span>Enhance personal finance features</div>
                          </div>
                        </div>
                      </React.Fragment>
                    );
                  }
                  else if (isAdvicentCase && i === 2) {
                    return (
                      <React.Fragment key={i}>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">Key insights emerged:</p>
                        <div className='bg-cosmic-light/30 border border-white/5 rounded-lg p-6 my-6'>
                          <div className='space-y-3 text-sm text-white/80'>
                            <div className='flex items-start'>
                              <span className='w-2 h-2 rounded-full bg-accent-violet mr-3 mt-2 flex-shrink-0'></span>
                              <div><strong className='text-accent-violet'>Self-directed preference:</strong> Younger investors often preferred self-directed financial planning, only wanting planners to validate their decisions</div>
                            </div>
                            <div className='flex items-start'>
                              <span className='w-2 h-2 rounded-full bg-accent-violet mr-3 mt-2 flex-shrink-0'></span>
                              <div><strong className='text-accent-violet'>Client portal importance:</strong> This highlighted the importance of a client portal for self-serve options and a flexible, side-by-side planner-client interface</div>
                            </div>
                            <div className='flex items-start'>
                              <span className='w-2 h-2 rounded-full bg-accent-violet mr-3 mt-2 flex-shrink-0'></span>
                              <div><strong className='text-accent-violet'>Non-linear usage:</strong> Analytics revealed that advisors use the software non-linearly, further reinforcing the need for a customizable, adaptive experience</div>
                            </div>
                          </div>
                        </div>
                      </React.Fragment>
                    );
                  }
                  else if (isSmithfieldCase && i === 0) {
                    return (
                      <React.Fragment key={i}>
                        <h3 className="text-xl md:text-2xl font-display mb-6 mt-12 text-accent-violet">Homepage</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>
                        {renderImage("/smithfield3.webp", "Responsive homepage template")}
                        <h3 className="text-xl md:text-2xl font-display mb-6 mt-12 text-accent-violet">Subpages</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">
                          Once the homepage direction was approved by all stakeholders, we extended the template to subpages such as product listings, detail pages, contact pages, promotional pages, and universal cart pages. Each template went through iterative design and requirements gathering to guarantee usability across all Smithfield brands.
                        </p>
                        {renderImage("/smithfield4.webp", "Template variations for different brands")}
                        <h3 className="text-xl md:text-2xl font-display mb-6 mt-12 text-accent-violet">Multi-Site Experience</h3>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed">
                          With the Smithfield global style guide in place, we assisted other partners in applying this system to each brand's website. Typically, we would collaborate with each agency to skin the homepage before handing over the master design file for further customization. These homepage designs, created alongside Smithfield and partner agencies, maintained brand integrity while adapting to individual brand styles.
                        </p>
                        {renderImage("/smithfield6.webp", "Brand customization examples")}
                      </React.Fragment>
                    );
                  }
                  else if (isADPCase && i === 1) {
                    return (
                      <React.Fragment key={i}>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>
                        {renderImage("/adp04.webp", "User journey mapping")}
                      </React.Fragment>
                    );
                  }
                  else if (isADPCase && i === 2) {
                    return (
                      <React.Fragment key={i}>
                        <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>
                        {renderImage("/secondcity02.png", "Competitive analysis and user research")}
                      </React.Fragment>
                    );
                  }
                  else {
                    if (paragraph.includes('levelex-prototype-container')) {
                      const parts = paragraph.split("<div id='levelex-prototype-container' class='my-8'></div>");
                      return (
                        <React.Fragment key={i}>
                          <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: parts[0] }}></p>
                          <LevelExPrototype />
                          {parts[1] && <p className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: parts[1] }}></p>}
                        </React.Fragment>
                      );
                    }
                    return <p key={i} className="text-lg text-white/90 mb-6 leading-relaxed" dangerouslySetInnerHTML={{ __html: paragraph }}></p>;
                  }
                })}
                {isTopDermCase && (
                  <>
                    {renderImage("/topderm5.png", "Top Derm implementation details")}
                  </>
                )}
                {isAdvicentCase && (
                  <>
                    <div className="mt-8">
                      <h3 className="text-xl md:text-2xl font-display mb-6 text-accent-violet">Themes Integrated Within Design Comps</h3>
                      <div className="overflow-x-auto">
                        <div className="flex space-x-6 pb-4" style={{ width: 'max-content' }}>
                          {[
                            { src: "/advicent11.webp", alt: "Final wireframe composition 2" },
                            { src: "/advicent12.webp", alt: "Final wireframe composition 3" },
                            { src: "/advicent13.webp", alt: "Final wireframe composition 4" },
                            { src: "/advicent14.webp", alt: "Final wireframe composition 5" }
                          ].map((image, index) => (
                            <div key={index} className="flex-shrink-0 w-96">
                              <img
                                src={image.src}
                                alt={image.alt}
                                className="rounded-lg w-full cursor-pointer transition-transform hover:scale-[1.02]"
                                onClick={() => handleImageClick(image.src, image.alt)}
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                     
                     {/* Problem headings for Level Ex case study */}
                     {caseStudy.problemHeadings && (
                       <div className="mt-8 space-y-6">
                         {caseStudy.problemHeadings.map((heading, index) => (
                           <div key={index} className="space-y-3">
                             <h4 className="text-lg font-medium text-accent-violet">
                               {heading}
                             </h4>
                             {caseStudy.problemDescriptions && caseStudy.problemDescriptions[index] && (
                               <p className="text-white/80 leading-relaxed">
                                 {caseStudy.problemDescriptions[index]}
                               </p>
                             )}
                           </div>
                         ))}
                       </div>
                     )}
                    </div>
                  </>
                )}
              </div>
              
              {isADPCase && (
                <div className="mt-16">
                  <h2 className="text-2xl md:text-3xl font-display mb-8 text-accent-violet">Final Wireframe Designs</h2>
                  <div className="overflow-x-auto">
                    <div className="flex space-x-6 pb-4" style={{ width: 'max-content' }}>
                      {[
                        { src: "/adp06.webp", alt: "ADP wireframe design 1" },
                        { src: "/adp07.webp", alt: "ADP wireframe design 2" },
                        { src: "/adp08.webp", alt: "ADP wireframe design 3" },
                        { src: "/adp09.webp", alt: "ADP wireframe design 4" },
                        { src: "/adp10.webp", alt: "ADP wireframe design 5" },
                        { src: "/adp11.webp", alt: "ADP wireframe design 6" },
                        { src: "/adp12.webp", alt: "ADP wireframe design 7" }
                      ].map((image, index) => (
                        <div key={index} className="flex-shrink-0 w-96">
                          <img 
                            src={image.src} 
                            alt={image.alt} 
                            className="rounded-lg w-full cursor-pointer transition-transform hover:scale-[1.02]"
                            onClick={() => handleImageClick(image.src, image.alt)}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </>
          )}

          {caseStudy.impact?.business && (
            <>
              <h2 className="text-2xl md:text-3xl font-display mb-6 mt-16 text-accent-teal">Results</h2>
              <div className="bg-cosmic-dark/90 backdrop-blur-sm p-8 rounded-lg border border-white/10 shadow-lg">
                <div className="space-y-4">
                  {caseStudy.impact.business.map((result, i) => (
                    <ResultItem key={i}>{result}</ResultItem>
                  ))}
                </div>
                
                {/* Problem headings - only for Level Ex case study */}
                {caseStudy.title.includes('Level Ex') && caseStudy.problemHeadings && (
                  <div className="mt-12 space-y-8">
                    {caseStudy.problemHeadings.map((heading, index) => (
                      <h4 key={index} className="text-xl font-display text-accent-violet">
                        {heading}
                      </h4>
                    ))}
                  </div>
                )}
                {isTopDermCase && renderImage("/topderm6.png", "Top Derm results visualization")}
              </div>
            </>
          )}

          {isShopifyCase && (
            <div className="mt-16">
              <h2 className="text-2xl md:text-3xl font-display mb-8 text-accent-violet">More Shopify Tax Work</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <a 
                  href="https://www.shopify.com/tax" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="block bg-cosmic-dark/90 backdrop-blur-sm border border-white/10 rounded-lg p-8 group hover:border-accent-violet transition-all duration-300"
                >
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-xl font-display text-white group-hover:text-accent-violet transition-colors">Shopify Tax & Filing - US</h3>
                    <span className="text-accent-violet">
                      <ExternalLink size={20} />
                    </span>
                  </div>
                  <p className="text-white/90 leading-relaxed">
                    With the launch of Shopify Tax, our first U.S.-based tax product, we aimed to demystify tax compliance for American merchants in a shifting regulatory landscape. Our built-in, automated tax features allow businesses to handle their tax obligations effortlessly, freeing them to focus on growth without the weight of complex tax rules. Knowing that over 90% of Shopify merchants now rely on Shopify Tax for seamless tax management underscores the trust merchants place in our solution and the impact of our work.
                  </p>
                </a>

                <a 
                  href="https://www.shopify.com/tax-platform" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="block bg-cosmic-dark/90 backdrop-blur-sm border border-white/10 rounded-lg p-8 group hover:border-accent-violet transition-all duration-300"
                >
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-xl font-display text-white group-hover:text-accent-violet transition-colors">Shopify Tax Platform - Global</h3>
                    <span className="text-accent-violet">
                      <ExternalLink size={20} />
                    </span>
                  </div>
                  <p className="text-white/90 leading-relaxed">
                    Following the success of Shopify Tax, we expanded by integrating third-party tax providers directly into the platform. This effort empowers merchants with greater flexibility, giving them the freedom to choose the tax solutions that best fit their needs, all within Shopify's ecosystem. Creating a seamless integration experience for merchants was both a rewarding and engaging journey, making tax management even more accessible.
                  </p>
                </a>
              </div>
            </div>
          )}

          {isTopDermCase && (
            <div className="mt-16">
              <h2 className="text-2xl md:text-3xl font-display mb-8 text-accent-violet">Project Recognition</h2>
              <div className="space-y-8">
                <div className="relative w-full aspect-w-16 aspect-h-9 rounded-lg overflow-hidden bg-cosmic-dark/90">
                  <iframe
                    src="https://www.youtube.com/embed/prc-1dTuISg"
                    title="Top Derm Video"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="absolute inset-0 w-full h-full rounded-lg"
                  ></iframe>
                </div>
              </div>
            </div>
          )}

        </article>
      </div>

      {selectedImage && (
        <ImageModal
          src={selectedImage.src}
          alt={selectedImage.alt}
          onClose={handleCloseModal}
          onPrevious={handlePreviousImage}
          onNext={handleNextImage}
          hasPrevious={selectedImageIndex > 0}
          hasNext={selectedImageIndex < imageGallery.length - 1}
          currentIndex={selectedImageIndex}
          totalCount={imageGallery.length}
        />
      )}
    </div>
  );
};

export default CaseStudyPage;