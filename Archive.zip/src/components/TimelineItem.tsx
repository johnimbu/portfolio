import React from 'react';
import { TimelineEvent } from '../types';

interface TimelineItemProps {
  event: TimelineEvent;
  index: number;
  isLast: boolean;
}

const TimelineItem = ({ event, index, isLast }: TimelineItemProps) => {
  const isEven = index % 2 === 0;
  const animationClass = isEven ? 'animate-fade-in-left' : 'animate-fade-in-right';
  
  return (
    <div className={`relative pb-12 ${isLast ? 'pb-0' : ''} animate-on-scroll opacity-0`} data-animation={animationClass}>
      {/* Vertical line */}
      {!isLast && (
        <div className="absolute left-5 top-5 bottom-0 w-px bg-gradient-to-b from-cobalt/40 via-cobalt/20 to-transparent"></div>
      )}

      <div className="flex items-start group">
        {/* Timeline dot */}
        <div className="relative flex-shrink-0 h-10 w-10 rounded-full bg-paper-deep border-2 border-cobalt/50 flex items-center justify-center mr-6 z-10 transition-all duration-300 group-hover:border-cobalt">
          <span className="animate-pulse-slow text-cobalt">
            {event.icon}
          </span>
        </div>

        {/* Content */}
        <div className="flex-grow">
          <div className="flex flex-col md:flex-row md:justify-between md:items-baseline mb-1">
            <h3 className="text-xl font-display font-bold text-ink mr-4" style={{ letterSpacing: '-0.02em' }}>{event.title}</h3>
            <span className="text-sm font-sans font-600 text-cobalt md:text-right">{event.period}</span>
          </div>
          <p className="text-base text-ink-muted font-sans mb-2">{event.company}</p>
          <div className="text-sm text-ink-soft font-sans leading-relaxed">{event.description}</div>

          {/* Skills/technologies used */}
          {event.skills && (
            <div className="mt-3 flex flex-wrap gap-2">
              {event.skills.map((skill, i) => (
                <span key={i} className="text-xs px-2.5 py-1 rounded-full bg-paper-deep border border-paper-rule text-ink-muted font-sans" style={{ letterSpacing: '0.04em' }}>
                  {skill}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TimelineItem;