import React from 'react';

interface QuoteCardProps {
  quote: string;
  author: string;
  className?: string;
}

const QuoteCard = ({ quote, author, className = '' }: QuoteCardProps) => {
  return (
    <div className={`relative p-6 rounded-lg bg-paper-deep border border-paper-rule transition-all duration-300 ${className}`}>
      <div className="text-5xl text-cobalt/20 absolute top-3 left-3 font-display">"</div>
      <blockquote className="relative z-10">
        <p className="text-ink-soft text-lg italic leading-relaxed mb-4 font-sans">{quote}</p>
        <footer className="text-ink-muted text-sm font-sans">
          — <cite className="not-italic font-medium">{author}</cite>
        </footer>
      </blockquote>
      <div className="text-5xl text-cobalt/20 absolute bottom-3 right-3 font-display rotate-180">"</div>
    </div>
  );
};

export default QuoteCard;