import React from 'react';
import { ArrowRight } from 'lucide-react';
import { CaseStudy } from '../types';

interface CaseStudyNavProps {
  onBack: () => void;
  nextCaseStudy: CaseStudy;
  scrollY: number;
  onNextClick: () => void;
  currentIndex: number;
  totalCount: number;
}

const CaseStudyNav = ({ onBack, nextCaseStudy, scrollY, onNextClick, currentIndex, totalCount }: CaseStudyNavProps) => {
  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrollY > 50 ? 'bg-cosmic-black/95 backdrop-blur-md shadow-lg' : 'bg-transparent'
      }`}
    >
      <div className="px-4 md:px-8 py-4">
        <div className="flex items-center justify-between">
          <a
            href="#"
            onClick={(e) => { e.preventDefault(); onBack(); }}
            className="text-white font-display text-xl flex items-center group"
          >
            <span className="bg-gradient-to-r from-accent-teal via-accent-violet to-accent-gold bg-clip-text text-transparent">
              John Imburgia
            </span>
          </a>

          <button
            onClick={onNextClick}
            title={`Next: ${nextCaseStudy.title}`}
            className="flex items-center gap-0 rounded-full border border-white/20 bg-white/0 hover:bg-white/5 hover:border-white/35 transition-all duration-200 group overflow-hidden"
          >
            {/* Position counter */}
            <span className="hidden sm:flex items-center px-3.5 py-2 text-white/40 text-xs tabular-nums font-mono tracking-wide">
              {currentIndex} <span className="mx-1 text-white/20">/</span> {totalCount}
            </span>

            {/* Divider */}
            <span className="hidden sm:block self-stretch w-px bg-white/15" />

            {/* Next label + arrow */}
            <span className="flex items-center gap-1.5 px-3.5 py-2 text-white/70 group-hover:text-white transition-colors duration-200 text-sm font-medium">
              <span className="hidden sm:inline">Next Case Study</span><span className="sm:hidden">Next</span>
              <ArrowRight size={14} className="transition-transform duration-200 group-hover:translate-x-0.5" />
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};

export default CaseStudyNav;