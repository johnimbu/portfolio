import React, { useRef, useState, useEffect, useCallback } from 'react';
import { ZoomIn, ZoomOut, ChevronLeft, ChevronRight } from 'lucide-react';
import UserFlowDiagram from './UserFlowDiagram';

const PHASES = [
  {
    id: 'awareness',
    label: 'Awareness',
    owner: 'Scene+',
    color: '#05D9E8',
    ownerColor: '#05D9E8',
    columns: 3,
  },
  {
    id: 'consideration',
    label: 'Consideration',
    owner: 'Scene+',
    color: '#05D9E8',
    ownerColor: '#05D9E8',
    columns: 4,
  },
  {
    id: 'activation',
    label: 'Activation',
    owner: 'Scotiabank',
    color: '#E8A505',
    ownerColor: '#E8A505',
    columns: 1,
  },
  {
    id: 'confirmation',
    label: 'Confirmation',
    owner: 'Scotiabank',
    color: '#E8A505',
    ownerColor: '#E8A505',
    columns: 2,
  },
  {
    id: 'followup',
    label: 'Follow-up',
    owner: 'Email',
    color: '#E8A505',
    ownerColor: '#E8A505',
    columns: 3,
  },
];

type CardType = 'default' | 'flow-node' | 'decision' | 'note' | 'empty';

interface Card {
  type?: CardType;
  text?: string;
  subtext?: string;
  icon?: string;
  highlight?: boolean;
  italic?: boolean;
  bullets?: string[];
}


const COLUMNS: { phase: string; colIndex: number; stepLabel?: string }[] = [
  { phase: 'awareness', colIndex: 0, stepLabel: 'Home / Nav' },
  { phase: 'awareness', colIndex: 1, stepLabel: 'Payments Overview' },
  { phase: 'awareness', colIndex: 2, stepLabel: 'Card Introduced' },
  { phase: 'consideration', colIndex: 0, stepLabel: 'Individual Card' },
  { phase: 'consideration', colIndex: 1, stepLabel: 'Card Details' },
  { phase: 'consideration', colIndex: 2, stepLabel: 'Card Details (logged in)' },
  { phase: 'consideration', colIndex: 3, stepLabel: 'Pre-apply' },
  { phase: 'activation', colIndex: 0, stepLabel: 'Card Application' },
  { phase: 'confirmation', colIndex: 0, stepLabel: 'Thank You Page' },
  { phase: 'confirmation', colIndex: 1, stepLabel: 'Thank You Email' },
  { phase: 'followup', colIndex: 0, stepLabel: 'Open Email' },
  { phase: 'followup', colIndex: 1, stepLabel: 'Approved Email' },
  { phase: 'followup', colIndex: 2, stepLabel: 'Next Steps' },
];

const ROWS: { id: string; label: string; sublabel: string }[] = [
  { id: 'userflow', label: 'User Flow', sublabel: 'Interaction & touchpoint examples' },
  { id: 'jtbd', label: 'Jobs to Be Done & Motivations', sublabel: "What users are trying to accomplish: the progress they're seeking and why." },
  { id: 'thoughts', label: 'User Thoughts & Feelings', sublabel: 'What users are likely thinking or feeling at this step' },
  { id: 'response', label: 'Our Response & Approach', sublabel: 'How the design or content should respond to that mindset' },
  { id: 'behaviors', label: 'Expected Behaviors & Outcomes', sublabel: 'What the user should do or feel ready to do as a result' },
  { id: 'notes', label: 'Additional Notes from Workshop', sublabel: '' },
];

const DATA: Record<string, Record<string, Card | null>> = {
  userflow: {
    'awareness-0': { type: 'flow-node', text: 'Home', subtext: 'User Start → Home → Nav > Payments' },
    'awareness-1': { type: 'flow-node', text: 'Payments Overview', subtext: 'Personalized content (logged in) or General content (logged out)' },
    'awareness-2': { type: 'flow-node', text: 'Cards Introduced', subtext: 'Multiple card options displayed' },
    'consideration-0': { type: 'flow-node', text: 'Individual Card Page', subtext: 'BNS or TNG — Personalized or General details' },
    'consideration-1': { type: 'flow-node', text: 'Card Details', subtext: 'BNS General / TNG General card details' },
    'consideration-2': { type: 'flow-node', text: 'Card Details (logged in)', subtext: 'Personalized with member info pre-filled' },
    'consideration-3': { type: 'note', text: 'Represent individual cards in this flow. Models vs. detail pages. What are the best ways to categorize the cards? Align on the right categorization.' },
    'activation-0': { type: 'flow-node', text: 'Card Application', subtext: 'TBD — Scotiabank handoff (dashed line)' },
    'confirmation-0': { type: 'flow-node', text: 'Thank You Page', subtext: 'Next steps shown' },
    'confirmation-1': { type: 'flow-node', text: 'Thank You Email', subtext: 'Next steps — then → Approved? decision' },
    'followup-0': { type: 'flow-node', text: 'Open Email', subtext: 'Consistent with Scene+ and Scotiabank branding' },
    'followup-1': { type: 'flow-node', text: 'Approved Email', subtext: '"What to expect…"' },
    'followup-2': { type: 'flow-node', text: 'Denied Email', subtext: '"What\'s next…"' },
  },
  jtbd: {
    'awareness-0': { text: 'When I\'m browsing the Scene+ app or site, I want an easy way to explore cards that maximize and streamline my benefits experience.' },
    'awareness-1': { text: 'When I land on the Payments Overview page, I want it to feel like a natural extension of Scene+, showing how these cards help me accelerate and get more from my rewards.' },
    'awareness-2': { text: 'When I see multiple cards introduced, I want a simple way to understand how they differ, so I can decide which one to explore further.' },
    'consideration-0': { text: 'When I\'m viewing an individual card page, I want to understand how its benefits fit my spending and lifestyle, so I can decide if it\'s the right choice for me.' },
    'consideration-1': { text: 'When I\'m on a specific card page, I want an easy way to compare and explore other options, so I don\'t feel locked into one path.' },
    'consideration-2': { text: 'When I\'m viewing card details, I want a way to begin my application, personalized with my info so I can complete the application quickly.' },
    'consideration-3': { text: 'When I transition to Scotiabank, I want to see clear continuity from Scene+, so I trust it\'s legitimate and connected.' },
    'activation-0': { text: 'When I transition to Scotiabank, I want to see clear continuity from Scene+, so I trust it\'s legitimate and connected.' },
    'confirmation-0': { text: 'When I finish my application, I want clear confirmation and next steps, so I know what happens next.' },
    'confirmation-1': { text: 'When I complete the application, I want a sense of accomplishment or relief, so I feel good about my choice.' },
    'followup-0': { text: 'When I open the email, I want it to feel consistent with Scene+ and Scotiabank, so I know it\'s legitimate.' },
    'followup-1': { text: 'When I get a follow-up email, I want to know right away whether I was approved, so I can plan my next step.' },
    'followup-2': { text: 'When I\'m approved, I want to understand how to start earning or using rewards, so I can act on it immediately.' },
  },
  thoughts: {
    'awareness-0': { italic: true, text: '"I\'m curious if there are new ways to earn or use rewards — but I don\'t want to dig around to find them."' },
    'awareness-1': { italic: true, text: '"This should feel like part of Scene+, not a random bank promo — show me why it matters to my existing rewards."' },
    'awareness-2': { italic: true, text: '"I just want to know which card is right for me — without reading fine print or opening five tabs."' },
    'consideration-0': { italic: true, text: '"Show me how this actually fits into my life — I don\'t want to guess if it\'s worth it."' },
    'consideration-1': { italic: true, text: '"I\'m interested, but I want to make sure I\'ve seen all my options before deciding."' },
    'consideration-2': { italic: true, text: '"I need the experience to feel secure and personalized — if my details don\'t look accurate, I\'ll hesitate to continue."' },
    'consideration-3': { italic: true, text: '"This looks different — am I still in Scene+? Is this the same program I trust?"' },
    'activation-0': { italic: true, text: '"This looks different — am I still in Scene+? Is this the same program I trust?"' },
    'confirmation-0': { italic: true, text: '"Did that go through? What should I expect now?"' },
    'confirmation-1': { italic: true, text: '"That was a bit of effort — I hope it was worth it."' },
    'followup-0': { italic: true, text: '"Is this really from Scene+ or Scotiabank? I don\'t want to click anything sketchy."' },
    'followup-1': { italic: true, text: '"Just tell me if I\'m approved — I don\'t want to dig through text to find it."' },
    'followup-2': { italic: true, text: '"I\'m excited — show me how to start benefiting right away."' },
  },
  response: {
    'awareness-0': { icon: '💡', text: 'Give "Payments" clear visibility in navigation; frame it as a way to enhance the Scene+ experience, not a separate banking area.' },
    'awareness-1': { icon: '💡', text: 'Use familiar Scene+ visuals and tone; connect cards directly to categories users already know (e.g., groceries, dining, travel); highlight how each helps maximize rewards.' },
    'awareness-2': { icon: '💡', text: 'Skims feature highlights; feels confident there\'s a right fit; selects one card for deeper exploration.' },
    'consideration-0': { icon: '💡', text: 'Present relatable examples of value (e.g., "Earn more on groceries"); use visuals and plain language that connect rewards to everyday scenarios.' },
    'consideration-1': { icon: '💡', text: 'Offer lightweight navigation to related cards and a way to overview; (future →) enable easy toggling or comparison without losing context.' },
    'consideration-2': { icon: '💡', text: 'Prefill key details with clear "where this came from" context; use plain, transparent language that builds confidence before committing.' },
    'consideration-3': { icon: '💡', text: 'Maintain visual, content, and tonal continuity between platforms; include Scene+ branding and partnership language; use reassuring microcopy ("In partnership with Scene+").' },
    'activation-0': { icon: '💡', text: 'Maintain visual, content, and tonal continuity between platforms; include Scene+ branding and partnership language; use reassuring microcopy ("In partnership with Scene+").' },
    'confirmation-0': { icon: '💡', text: 'Provide immediate, unambiguous confirmation with timeline cues ("We\'ll email you within 24 hours"); keep tone calm and confident.' },
    'confirmation-1': { icon: '💡', text: 'Celebrate completion lightly ("You\'re one step closer to earning more rewards"); use friendly visuals or micro-animations to signal success.' },
    'followup-0': { icon: '💡', text: 'Use clear joint branding and tone; mirror the look and feel of previous touchpoints; lead with recognizable sender info and subject line.' },
    'followup-1': { icon: '💡', text: 'Make the status instantly visible ("You\'re approved!" or "Here\'s what happens next"); use concise copy and strong hierarchy.' },
    'followup-2': { icon: '💡', text: 'Provide a clear, visual "first step" ("Add to Scene+ app," "Start earning on dining"); link directly to setup or activation flow. Expect card in mail in X days.' },
  },
  behaviors: {
    'awareness-0': { icon: '🖥', text: 'Clicks "Payments" from the home page; begins exploring the overview with curiosity and confidence.' },
    'awareness-1': { icon: '🖥', text: 'Scrolls through the overview; recognizes how cards complement current habits; clicks one to learn more.' },
    'awareness-2': { icon: '🖥', text: 'Reads card benefits with context; feels clarity and excitement about how rewards stack or integrate. Chooses multiple cards for detailed comparison.' },
    'consideration-0': { icon: '🖥', text: 'Reads benefit highlights; recognizes relevance; feels ready to compare or move toward applying.' },
    'consideration-1': { icon: '🖥', text: 'Switches between card pages smoothly; feels in control of the decision; selects a preferred card confidently.' },
    'consideration-2': { icon: '🖥', text: 'Reviews prefilled info, feels reassured it\'s accurate and secure, and proceeds to complete the application without friction.' },
    'consideration-3': { icon: '🖥', text: 'Recognizes continuity immediately; continues with confidence instead of hesitation; proceeds to start the application.' },
    'activation-0': { icon: '🖥', text: 'Recognizes continuity immediately; continues with confidence instead of hesitation; proceeds to start the application.' },
    'confirmation-0': { icon: '🖥', text: 'Reads the confirmation page; feels assured the process is complete; waits for follow-up with confidence.' },
    'confirmation-1': { icon: '🖥', text: 'Smiles or relaxes; feels positive about the process; mentally reinforces the decision as a good one.' },
    'followup-0': { icon: '🖥', text: 'Opens the email with confidence; trusts the content immediately; engages without hesitation.' },
    'followup-1': { icon: '🖥', text: 'Scans and understands status immediately; feels informed; knows what to do next (e.g., activate, wait, or follow up).' },
    'followup-2': { icon: '🖥', text: 'Clicks into setup; activates the card; begins engaging with Scene+ rewards within minutes.' },
  },
  notes: {
    'awareness-0': { bullets: ['How do we simplify the process if you\'re not a member to avoid falloff?', 'What if you come in through a specific card, how do you see more options?'] },
    'awareness-1': null,
    'awareness-2': null,
    'consideration-0': { bullets: ['What if they leave and come back?', 'Familiar visuals, use cookies'] },
    'consideration-1': { bullets: ['How do we differentiate products: cc/dc?', 'Start with, "what\'s right for you"'] },
    'consideration-2': { bullets: ['Need to consider TNG is a new concept. Intro with care.', 'Download app, origin determines next steps.', 'Starting with 1 TNG card for the foreseeable future', 'BNS has 8-9 cards (w/ Scene+ benefits). To be confirmed.'] },
    'consideration-3': null,
    'activation-0': null,
    'confirmation-0': null,
    'confirmation-1': null,
    'followup-0': null,
    'followup-1': { bullets: ['How to represent eligibility?', 'Process of ingesting information from bank.', 'Experiments?'] },
    'followup-2': { bullets: ['Short and long term benefits.'] },
  },
};

const CARD_W = 200;
const CARD_H_FLOW = 80;
const CARD_H = 130;
const CARD_H_NOTES = 110;
const COL_GAP = 20;
const ROW_GAP = 20;
const SIDEBAR_W = 220;
const HEADER_H = 72;
const ROW_LABEL_W = 220;

interface ScenePlusJourneyMapProps {
  onImageClick?: (src: string, alt: string) => void;
}

const ScenePlusJourneyMap = (_props: ScenePlusJourneyMapProps) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(0.72);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0, scrollLeft: 0, scrollTop: 0 });
  const [scrollProgress, setScrollProgress] = useState(0);
  const [activePhase, setActivePhase] = useState(0);
  const [hoveredCell, setHoveredCell] = useState<string | null>(null);

  const MIN_ZOOM = 0.35;
  const MAX_ZOOM = 1.1;
  const ZOOM_STEP = 0.08;

  const getCardHeight = (rowId: string) => {
    if (rowId === 'userflow') return 260;
    if (rowId === 'notes') return CARD_H_NOTES;
    return CARD_H;
  };

  const totalCanvasW = SIDEBAR_W + 20 + COLUMNS.length * (CARD_W + COL_GAP) - COL_GAP + 80;
  const totalCanvasH = HEADER_H + ROWS.reduce((sum, r) => sum + getCardHeight(r.id) + ROW_GAP, 0) + 60;

  const handleScroll = useCallback(() => {
    const el = containerRef.current;
    if (!el) return;
    const maxX = el.scrollWidth - el.clientWidth;
    setScrollProgress(maxX > 0 ? el.scrollLeft / maxX : 0);

    const scaledSidebarW = (SIDEBAR_W + 20) * zoom;
    const scaledColW = (CARD_W + COL_GAP) * zoom;
    const scrollRelative = el.scrollLeft - scaledSidebarW;
    let colIdx = Math.max(0, Math.floor(scrollRelative / scaledColW));
    const col = COLUMNS[Math.min(colIdx, COLUMNS.length - 1)];
    const phaseIdx = PHASES.findIndex(p => p.id === col?.phase);
    setActivePhase(Math.max(0, phaseIdx));
  }, [zoom]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    el.addEventListener('scroll', handleScroll, { passive: true });
    return () => el.removeEventListener('scroll', handleScroll);
  }, [handleScroll]);

  const onMouseDown = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    setIsDragging(true);
    setDragStart({
      x: e.clientX,
      y: e.clientY,
      scrollLeft: containerRef.current.scrollLeft,
      scrollTop: containerRef.current.scrollTop,
    });
  };

  const onMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (!isDragging || !containerRef.current) return;
      containerRef.current.scrollLeft = dragStart.scrollLeft - (e.clientX - dragStart.x);
      containerRef.current.scrollTop = dragStart.scrollTop - (e.clientY - dragStart.y);
    },
    [isDragging, dragStart]
  );

  const onMouseUp = () => setIsDragging(false);

  const scrollToPhase = (phaseId: string) => {
    const el = containerRef.current;
    if (!el) return;
    const colIdx = COLUMNS.findIndex(c => c.phase === phaseId);
    if (colIdx < 0) return;
    const phaseIdx = PHASES.findIndex(p => p.id === phaseId);
    setActivePhase(Math.max(0, phaseIdx));
    const target = (SIDEBAR_W + 20 + colIdx * (CARD_W + COL_GAP) - 24) * zoom;
    el.scrollTo({ left: target, behavior: 'smooth' });
  };

  const adjustZoom = (delta: number) => {
    setZoom(z => Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, parseFloat((z + delta).toFixed(2)))));
  };

  const getPhaseColor = (phaseId: string) => PHASES.find(p => p.id === phaseId)?.color ?? '#ffffff';

  const renderCard = (card: Card | null, rowId: string, colKey: string) => {
    const height = getCardHeight(rowId);
    const isHovered = hoveredCell === colKey + rowId;
    const phaseId = colKey.split('-')[0];
    const phaseColor = getPhaseColor(phaseId);

    if (!card || card.type === 'empty') {
      return (
        <div
          style={{ width: CARD_W, height, flexShrink: 0 }}
          className="rounded-lg border border-dashed border-white/5"
        />
      );
    }

    if (card.type === 'flow-node') {
      return (
        <div
          style={{ width: CARD_W, height, flexShrink: 0, borderColor: `${phaseColor}30` }}
          className="rounded-lg border bg-[#111] flex flex-col justify-center px-3 py-2"
        >
          <p className="text-white font-display font-semibold leading-tight" style={{ fontSize: 11 }}>
            {card.text}
          </p>
          {card.subtext && (
            <p className="text-white/40 leading-snug mt-1" style={{ fontSize: 10 }}>
              {card.subtext}
            </p>
          )}
        </div>
      );
    }

    if (card.type === 'note') {
      return (
        <div
          style={{ width: CARD_W, height, flexShrink: 0 }}
          className="rounded-lg border border-dashed border-white/15 bg-white/[0.02] flex flex-col justify-center px-3 py-2"
        >
          <p className="text-white/50 leading-snug" style={{ fontSize: 10 }}>
            {card.text}
          </p>
        </div>
      );
    }

    if (card.bullets) {
      return (
        <div
          style={{ width: CARD_W, height, flexShrink: 0 }}
          className={`rounded-lg border transition-all duration-200 px-3 py-2 overflow-hidden ${
            isHovered
              ? 'border-white/20 bg-white/[0.06]'
              : 'border-white/8 bg-white/[0.03]'
          }`}
          onMouseEnter={() => setHoveredCell(colKey + rowId)}
          onMouseLeave={() => setHoveredCell(null)}
        >
          <ul className="space-y-1">
            {card.bullets.map((b, i) => (
              <li key={i} className="flex items-start gap-1.5" style={{ fontSize: 10 }}>
                <span className="text-white/30 mt-0.5 flex-shrink-0">•</span>
                <span className="text-white/60 leading-snug">{b}</span>
              </li>
            ))}
          </ul>
        </div>
      );
    }

    const isThought = rowId === 'thoughts';
    const isResponse = rowId === 'response';

    return (
      <div
        style={{
          width: CARD_W,
          height,
          flexShrink: 0,
          borderColor: isHovered ? `${phaseColor}40` : 'rgba(255,255,255,0.07)',
          backgroundColor: isHovered ? `${phaseColor}08` : 'rgba(255,255,255,0.02)',
        }}
        className="rounded-lg border transition-all duration-200 px-3 py-2.5 overflow-hidden flex flex-col justify-start"
        onMouseEnter={() => setHoveredCell(colKey + rowId)}
        onMouseLeave={() => setHoveredCell(null)}
      >
        {card.icon && (
          <span className="mb-1 leading-none" style={{ fontSize: 12 }}>{card.icon}</span>
        )}
        <p
          className={`leading-snug ${
            isThought ? 'text-white/50' : isResponse ? 'text-white/80' : 'text-white/70'
          } ${card.italic ? 'italic' : ''}`}
          style={{ fontSize: 10 }}
        >
          {card.text}
        </p>
      </div>
    );
  };

  const phaseColSpans: Record<string, number> = {};
  COLUMNS.forEach(col => {
    phaseColSpans[col.phase] = (phaseColSpans[col.phase] ?? 0) + 1;
  });

  return (
    <div className="my-10">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <span className="text-xs font-semibold uppercase tracking-widest px-3 py-1 rounded-full bg-cosmic-light/40 border border-white/20 text-white/70">
          Combined User Flow &amp; Journey Map
        </span>
        <div className="flex items-center gap-2">
          <button
            onClick={() => adjustZoom(-ZOOM_STEP)}
            disabled={zoom <= MIN_ZOOM}
            className="w-8 h-8 flex items-center justify-center rounded-lg bg-cosmic-light/60 border border-white/10 text-white/60 hover:text-white hover:border-white/30 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
          >
            <ZoomOut size={13} />
          </button>
          <span className="text-xs text-white/35 font-mono w-10 text-center">{Math.round(zoom * 100)}%</span>
          <button
            onClick={() => adjustZoom(ZOOM_STEP)}
            disabled={zoom >= MAX_ZOOM}
            className="w-8 h-8 flex items-center justify-center rounded-lg bg-cosmic-light/60 border border-white/10 text-white/60 hover:text-white hover:border-white/30 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
          >
            <ZoomIn size={13} />
          </button>
          <div className="w-px h-5 bg-white/10 mx-1" />
          <button
            onClick={() => containerRef.current?.scrollBy({ left: -300, behavior: 'smooth' })}
            className="w-8 h-8 flex items-center justify-center rounded-lg bg-cosmic-light/60 border border-white/10 text-white/60 hover:text-white hover:border-white/30 transition-all"
          >
            <ChevronLeft size={13} />
          </button>
          <button
            onClick={() => containerRef.current?.scrollBy({ left: 300, behavior: 'smooth' })}
            className="w-8 h-8 flex items-center justify-center rounded-lg bg-cosmic-light/60 border border-white/10 text-white/60 hover:text-white hover:border-white/30 transition-all"
          >
            <ChevronRight size={13} />
          </button>
        </div>
      </div>

      <div className="rounded-xl overflow-hidden border border-white/10 bg-[#0a0a0a] shadow-2xl">
        <div className="flex items-center px-5 py-2.5 border-b border-white/5 bg-[#0d0d0d]">
          <span className="text-xs text-white/25 font-mono">Scene+ × Scotiabank × Tangerine — UX Flow &amp; Journey Map</span>
        </div>

        <div className="flex border-b border-white/5 bg-[#0c0c0c]">
          <div style={{ minWidth: ROW_LABEL_W }} className="flex-shrink-0" />
          {PHASES.map((phase) => (
            <button
              key={phase.id}
              onClick={() => scrollToPhase(phase.id)}
              className={`flex-1 px-4 py-2 text-xs font-medium border-r border-white/5 transition-all text-left ${
                PHASES[activePhase]?.id === phase.id
                  ? 'bg-white/5'
                  : 'hover:bg-white/[0.02]'
              }`}
              style={{
                color: PHASES[activePhase]?.id === phase.id ? phase.color : 'rgba(255,255,255,0.3)',
                borderBottom: PHASES[activePhase]?.id === phase.id ? `2px solid ${phase.color}` : '2px solid transparent',
              }}
            >
              {phase.label}
              <span className="block text-white/25 font-normal" style={{ fontSize: 10 }}>{phase.owner}</span>
            </button>
          ))}
        </div>

        <div
          ref={containerRef}
          className="overflow-auto"
          style={{
            cursor: isDragging ? 'grabbing' : 'grab',
            maxHeight: 560,
          }}
          onMouseDown={onMouseDown}
          onMouseMove={onMouseMove}
          onMouseUp={onMouseUp}
          onMouseLeave={onMouseUp}
        >
          <div
            style={{
              width: totalCanvasW * zoom,
              height: totalCanvasH * zoom,
              transformOrigin: 'top left',
              position: 'relative',
            }}
          >
            <div
              style={{
                transform: `scale(${zoom})`,
                transformOrigin: 'top left',
                width: totalCanvasW,
                height: totalCanvasH,
              }}
            >
              <div style={{ display: 'flex', paddingLeft: SIDEBAR_W + 20, paddingTop: 16, paddingRight: 40 }}>
                {PHASES.map((phase) => {
                  const span = phaseColSpans[phase.id] ?? 1;
                  const w = span * CARD_W + (span - 1) * COL_GAP;
                  return (
                    <div key={phase.id} style={{ width: w, marginRight: COL_GAP, flexShrink: 0 }}>
                      <div
                        className="rounded-lg px-4 py-2 text-center mb-1"
                        style={{ background: `${phase.color}10`, border: `1px solid ${phase.color}25` }}
                      >
                        <p className="font-display font-bold text-sm" style={{ color: phase.color }}>
                          {phase.label}
                        </p>
                        <p className="text-xs" style={{ color: `${phase.color}80` }}>{phase.owner}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div style={{ paddingTop: 12 }}>
                {ROWS.map((row) => {
                  const cardH = getCardHeight(row.id);
                  const isUserFlow = row.id === 'userflow';
                  const flowW = 1940;
                  return (
                    <div
                      key={row.id}
                      style={{ display: 'flex', alignItems: 'flex-start', marginBottom: ROW_GAP }}
                    >
                      <div
                        style={{ width: SIDEBAR_W + 20, flexShrink: 0, paddingLeft: 20, paddingRight: 24, paddingTop: 8 }}
                        className="flex flex-col justify-start"
                      >
                        <p className="font-display font-semibold text-white/90 leading-tight" style={{ fontSize: 13 }}>
                          {row.label}
                        </p>
                        {row.sublabel && (
                          <p className="text-white/35 leading-snug mt-1" style={{ fontSize: 10 }}>
                            {row.sublabel}
                          </p>
                        )}
                      </div>

                      {isUserFlow ? (
                        <div style={{ width: flowW, flexShrink: 0, paddingRight: 40 }}>
                          <UserFlowDiagram />
                        </div>
                      ) : (
                        <div style={{ display: 'flex', gap: COL_GAP, paddingRight: 40 }}>
                          {COLUMNS.map((col, colIdx) => {
                            const key = `${col.phase}-${col.colIndex}`;
                            const card = DATA[row.id]?.[key] ?? null;
                            return (
                              <div key={colIdx} style={{ flexShrink: 0 }}>
                                {renderCard(card, row.id, key)}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        <div className="px-4 py-3 border-t border-white/5 flex items-center gap-4 bg-[#0d0d0d]">
          <div className="flex items-center gap-2.5">
            {PHASES.map((phase, idx) => (
              <button
                key={phase.id}
                onClick={() => scrollToPhase(phase.id)}
                className="transition-all duration-300 rounded-full"
                style={{
                  width: activePhase === idx ? 20 : 6,
                  height: 6,
                  backgroundColor: activePhase === idx ? phase.color : 'rgba(255,255,255,0.15)',
                }}
              />
            ))}
          </div>
          <div className="flex-1 h-0.5 bg-white/5 rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-150"
              style={{
                width: `${scrollProgress * 100}%`,
                background: `linear-gradient(to right, #05D9E8, #E8A505)`,
              }}
            />
          </div>
          <p className="text-xs text-white/20 font-mono whitespace-nowrap">drag or scroll to explore</p>
        </div>
      </div>

      <p className="text-white/35 text-sm mt-3 text-center italic">
        Combined user flow and journey map — refined with both banking partners and finalized in an alignment workshop
      </p>
    </div>
  );
};

export default ScenePlusJourneyMap;
