import React from 'react';
import SectionTitle from '../components/SectionTitle';
import { Mail, Phone, Linkedin, MapPin } from 'lucide-react';

const Contact = () => {
  return (
    <section id="contact" className="py-20">
      <div className="container mx-auto px-4 md:px-8">
        <SectionTitle 
          title="Contact"
          alignment="center"
        />
        
        <div className="max-w-4xl mx-auto mt-12">
          <div className="animate-on-scroll opacity-0" data-animation="animate-fade-in-up">
            <div className="bg-cosmic-dark/50 backdrop-blur-sm border border-white/5 rounded-lg p-8">
              <div className="mb-8 pb-8 border-b border-white/10">
                <h4 className="text-white font-medium mb-4">Current Availability</h4>
                <div className="flex items-center">
                  <div className="h-3 w-3 rounded-full bg-accent-teal animate-pulse mr-2"></div>
                  <p className="text-white font-medium">
                    Exploring new full-time roles
                  </p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-white/80">
                <div className="flex items-start group">
                  <Linkedin size={20} className="text-accent-gold mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="text-white font-medium mb-1">LinkedIn</h4>
                    <a 
                      href="https://www.linkedin.com/in/johnimbu/" 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="text-white/70 hover:text-accent-gold transition-colors duration-300"
                    >
                      linkedin.com/in/johnimbu
                    </a>
                  </div>
                </div>

                <div className="flex items-start group">
                  <Mail size={20} className="text-accent-gold mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="text-white font-medium mb-1">Email</h4>
                    <a 
                      href="mailto:john.imbu@gmail.com"
                      className="text-white/70 hover:text-accent-gold transition-colors duration-300"
                    >
                      john.imbu@gmail.com
                    </a>
                  </div>
                </div>
                
                <div className="flex items-start group">
                  <Phone size={20} className="text-accent-gold mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="text-white font-medium mb-1">Phone</h4>
                    <a 
                      href="tel:847-767-1419"
                      className="text-white/70 hover:text-accent-gold transition-colors duration-300"
                    >
                      847-767-1419
                    </a>
                  </div>
                </div>

                <div className="flex items-start group">
                  <MapPin size={20} className="text-accent-gold mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="text-white font-medium mb-1">Location</h4>
                    <p className="text-white/70">Chicago, IL</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;