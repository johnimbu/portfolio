import React from 'react';
import SectionTitle from '../components/SectionTitle';
import TimelineItem from '../components/TimelineItem';
import { createTimelineEvents } from '../data/timeline';
import { FileText } from 'lucide-react';
import Button from '../components/Button';
import YouTubeModal from '../components/YouTubeModal';

const Experience = () => {
  const [showVideoModal, setShowVideoModal] = React.useState(false);
  
  const timelineEvents = createTimelineEvents(() => setShowVideoModal(true));

  const handleResumeClick = () => {
    window.open('/John-Imburgia_Resume.pdf', '_blank');
  };

  return (
    <section id="experience" className="py-20">
      <div className="container mx-auto px-4 md:px-8">
        <SectionTitle 
          title="Experience"
          alignment="center"
        />
        
        <div className="max-w-3xl mx-auto mt-16">
          {timelineEvents.map((event, index) => (
            <TimelineItem 
              key={index}
              event={event}
              index={index}
              isLast={index === timelineEvents.length - 1}
            />
          ))}
        </div>

        <div className="flex justify-center mt-16 animate-on-scroll opacity-0" data-animation="animate-fade-in-up">
          <Button
            variant="secondary"
            size="lg"
            onClick={handleResumeClick}
            icon={<FileText size={20} />}
          >
            View Resume
          </Button>
        </div>
      </div>
      
      {showVideoModal && (
        <YouTubeModal
          videoId="prc-1dTuISg"
          onClose={() => setShowVideoModal(false)}
        />
      )}
    </section>
  );
};

export default Experience;