import React, { useRef, useState } from 'react';
import { ArrowDown, Linkedin, Mail, Phone, MapPin } from 'lucide-react';
import { useNavigation } from '../contexts/NavigationContext';

const Hero = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isSnapping, setIsSnapping] = useState(false);
  const { goToFirstCaseStudy } = useNavigation();

  const handleEnter = async () => {
    if (isSnapping) return;
    setIsSnapping(true);
    await new Promise((r) => setTimeout(r, 450));
    goToFirstCaseStudy();
  };

  return (
    <section
      ref={sectionRef}
      id="hero"
      className={`relative h-screen overflow-hidden transition-transform duration-500 ease-in ${
        isSnapping ? '-translate-y-full' : 'translate-y-0'
      }`}
    >
      {/* Background photo */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(/me.webp)` }}
      />
      {/* Dark overlay — keep the photo dark so cream text reads */}
      <div className="absolute inset-0 bg-gradient-to-r from-ink/85 via-ink/40 to-ink/10" />
      <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-transparent to-transparent" />

      {/* Content anchored to bottom */}
      <div className="absolute bottom-0 left-0 right-0 z-10 px-4 md:px-8 pb-16 md:pb-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-16 items-end">

          <div>
            <img
              src="/stamp-inverted.svg"
              alt="Product Design · Growth · Artificial Intelligence"
              className="animate-fade-in opacity-0 mb-4"
              style={{ width: 'clamp(72px, 10vw, 110px)', animationDelay: '0.2s' }}
            />

            <h1
              className="font-display font-bold leading-none mb-5 whitespace-nowrap text-cream uppercase animate-fade-in opacity-0"
              style={{ fontSize: 'clamp(1.925rem, 5.25vw, 4.2rem)', letterSpacing: '0.01em', animationDelay: '0.7s' }}
            >
              John Imburgia<span className="text-accent-teal">.</span>
            </h1>

            <p
              className="text-cream/55 leading-relaxed animate-fade-in opacity-0 font-sans"
              style={{ fontSize: 'clamp(0.875rem, 1.4vw, 1rem)', animationDelay: '1.4s', maxWidth: '40ch' }}
            >
              Design leader with 10+ years across product, growth, and AI. I turn complex systems into clear experiences that ship and perform.
            </p>
          </div>

          <div className="animate-fade-in opacity-0" style={{ animationDelay: '1.6s' }}>
            <div className="flex items-center gap-2.5 mb-5">
              <div className="h-2 w-2 rounded-full bg-accent-teal animate-pulse flex-shrink-0" />
              <span className="text-cream/50 text-sm font-sans">Available for select projects</span>
            </div>

            <div className="border-t border-cream/15 mb-5" />

            <div className="grid grid-cols-2 gap-x-6 gap-y-4 mb-7">
              <a
                href="https://www.linkedin.com/in/johnimbu/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 group"
              >
                <Linkedin size={13} className="text-cream/30 group-hover:text-accent-teal transition-colors duration-200 flex-shrink-0" />
                <span className="text-cream/45 group-hover:text-cream/80 transition-colors duration-200 text-sm font-sans">linkedin.com/in/johnimbu</span>
              </a>

              <a
                href="mailto:john.imbu@gmail.com"
                className="flex items-center gap-2 group"
              >
                <Mail size={13} className="text-cream/30 group-hover:text-accent-teal transition-colors duration-200 flex-shrink-0" />
                <span className="text-cream/45 group-hover:text-cream/80 transition-colors duration-200 text-sm font-sans">john.imbu@gmail.com</span>
              </a>

              <a
                href="tel:847-767-1419"
                className="flex items-center gap-2 group"
              >
                <Phone size={13} className="text-cream/30 group-hover:text-accent-teal transition-colors duration-200 flex-shrink-0" />
                <span className="text-cream/45 group-hover:text-cream/80 transition-colors duration-200 text-sm font-sans">847-767-1419</span>
              </a>

              <div className="flex items-center gap-2">
                <MapPin size={13} className="text-cream/30 flex-shrink-0" />
                <span className="text-cream/45 text-sm font-sans">Chicago, IL</span>
              </div>

              <a
                href="/John_Imburgia_—_Product_Design_Leader.pdf"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 group col-span-2"
              >
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-cream/30 group-hover:text-accent-teal transition-colors duration-200 flex-shrink-0"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
                <span className="text-cream/45 group-hover:text-cream/80 transition-colors duration-200 text-sm font-sans">Resume</span>
              </a>
            </div>

            <button
              onClick={handleEnter}
              className="flex items-center rounded-full border border-accent-teal/50 hover:border-accent-teal hover:bg-accent-teal/10 transition-all duration-200 group overflow-hidden"
            >
              <span className="px-4 py-2.5 text-accent-teal/80 group-hover:text-accent-teal transition-colors duration-200 text-sm font-display font-700 tracking-wide">
                Featured Case Studies
              </span>
              <span className="self-stretch w-px bg-accent-teal/25" />
              <span className="flex items-center px-3.5 py-2.5 text-accent-teal/60 group-hover:text-accent-teal transition-colors duration-200">
                <ArrowDown size={14} className="animate-bounce-subtle" />
              </span>
            </button>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Hero;
