import React from 'react';
import SectionTitle from '../components/SectionTitle';
import CaseStudyCard from '../components/CaseStudyCard';
import { CaseStudy } from '../types';

interface CaseStudiesProps {
  onCaseStudyClick: (caseStudy: CaseStudy) => void;
  allCaseStudies: CaseStudy[];
}

const CaseStudies = ({ onCaseStudyClick, allCaseStudies }: CaseStudiesProps) => {
  return (
    <section id="work" className="py-20">
      <div className="container mx-auto px-4 md:px-8">
        <SectionTitle
          title="Featured Work"
          alignment="center"
        />
        
        {/* 2x2 grid layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {allCaseStudies.map((caseStudy, index) => (
            <CaseStudyCard 
              key={caseStudy.id}
              caseStudy={caseStudy}
              index={index}
              onClick={() => onCaseStudyClick(caseStudy)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default CaseStudies;