import React from 'react';
import SectionTitle from '../components/SectionTitle';
import { Mail, Phone, Linkedin, MapPin, FileText } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="py-20">
      <div className="container mx-auto px-4 md:px-8">
        <SectionTitle
          title="Get in Touch"
          alignment="center"
        />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start mt-12">
          <div className="animate-on-scroll opacity-0" data-animation="animate-fade-in-left">
            <div className="relative group">
              <img
                src="/me.webp"
                alt="John working on UX design with sticky notes and user flows on the wall"
                className="w-full h-auto rounded-lg shadow-lg object-cover aspect-[4/3] [filter:saturate(105%)_brightness(102%)]"
              />
            </div>
          </div>

          <div className="animate-on-scroll opacity-0 space-y-8" data-animation="animate-fade-in-right">
            <div className="bg-paper-deep border border-paper-rule rounded-lg p-8">
              <div className="space-y-5 text-ink-soft font-sans leading-relaxed mb-8">
                <p>
                  I'm a Chicago-based product design leader. Over the past decade I've led design across web, mobile, games, and enterprise software, building products that earn trust, drive adoption, and hit real business goals.
                </p>

                <p>
                  I care about the balance between strategy and craft. I shape direction through research and experimentation while helping teams do their best work.
                </p>
              </div>

              <div className="mb-8 pb-8 border-b border-paper-rule">
                <h4 className="text-ink font-display font-bold mb-4 text-sm" style={{ letterSpacing: '0.1em', textTransform: 'uppercase' }}>Current Availability</h4>
                <div className="flex items-center gap-3">
                  <div className="h-2.5 w-2.5 rounded-full bg-accent-teal animate-pulse flex-shrink-0"></div>
                  <p className="text-ink-soft font-sans font-500 text-sm">
                    Available for select projects
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-ink-soft">
                <div className="flex items-start group">
                  <Linkedin size={18} className="text-cobalt mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="text-ink font-sans font-600 mb-1 text-sm">LinkedIn</h4>
                    <a
                      href="https://www.linkedin.com/in/johnimbu/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-ink-muted hover:text-cobalt transition-colors duration-300 text-sm font-sans"
                    >
                      linkedin.com/in/johnimbu
                    </a>
                  </div>
                </div>

                <div className="flex items-start group">
                  <Mail size={18} className="text-cobalt mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="text-ink font-sans font-600 mb-1 text-sm">Email</h4>
                    <a
                      href="mailto:john.imbu@gmail.com"
                      className="text-ink-muted hover:text-cobalt transition-colors duration-300 text-sm font-sans"
                    >
                      john.imbu@gmail.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start group">
                  <Phone size={18} className="text-cobalt mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="text-ink font-sans font-600 mb-1 text-sm">Phone</h4>
                    <a
                      href="tel:847-767-1419"
                      className="text-ink-muted hover:text-cobalt transition-colors duration-300 text-sm font-sans"
                    >
                      847-767-1419
                    </a>
                  </div>
                </div>

                <div className="flex items-start group">
                  <MapPin size={18} className="text-cobalt mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="text-ink font-sans font-600 mb-1 text-sm">Location</h4>
                    <p className="text-ink-muted text-sm font-sans">Chicago, IL</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;