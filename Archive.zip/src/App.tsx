import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useParams, useNavigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Hero from './sections/Hero';
import Footer from './components/Footer';

import CaseStudyPage from './components/CaseStudyPage';

import TransitionLayer from './components/TransitionLayer';
import { useScrollAnimation } from './hooks/useScrollAnimation';
import { CaseStudy } from './types';
import { caseStudies, featuredCaseStudy } from './data/caseStudies';
import { slugify } from './utils/slugify';
import { NavigationProvider, useNavigation } from './contexts/NavigationContext';

const CaseStudyRoute = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { allCaseStudies, goHome, goToCaseStudy } = useNavigation();

  const caseStudy = allCaseStudies.find((study) => slugify(study.title) === slug);

  useEffect(() => {
    if (slug && !caseStudy) {
      navigate('/', { replace: true });
    }
  }, [slug, caseStudy, navigate]);

  if (!caseStudy) {
    return null;
  }

  return (
    <CaseStudyPage
      key={slug}
      caseStudy={caseStudy}
      onBack={goHome}
      onNextCaseStudy={goToCaseStudy}
      allCaseStudies={allCaseStudies}
    />
  );
};

const HomePage = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <main>
      <Hero />
    </main>
  );
};

const AppShell = ({ allCaseStudies }: { allCaseStudies: CaseStudy[] }) => {
  return (
    <NavigationProvider allCaseStudies={allCaseStudies}>
      <ShellContent />
    </NavigationProvider>
  );
};

const ShellContent = () => {
  const { isTransitioning, currentCaseStudy, goHome } = useNavigation();
  const isHome = !currentCaseStudy;
  useEffect(() => {
    if (isHome) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isHome]);

  return (
    <>
      <TransitionLayer isActive={isTransitioning} />
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/case-study/:slug" element={<CaseStudyRoute />} />
      </Routes>
      {!isHome && <Footer />}
    </>
  );
};

function App() {
  const scenePlus = caseStudies.find((s) => s.title.includes('Scene+'));
  const rest = caseStudies.filter((s) => !s.title.includes('Scene+'));
  const allCaseStudies = scenePlus
    ? [scenePlus, featuredCaseStudy, ...rest]
    : [featuredCaseStudy, ...caseStudies];
  useScrollAnimation();

  useEffect(() => {
    document.title = 'John Imburgia: UX Design Leader';
  }, []);

  return (
    <Router>
      <div className="relative bg-paper min-h-screen text-ink overflow-hidden font-sans">
        <div className="relative z-10">
          <AppShell allCaseStudies={allCaseStudies} />
        </div>
      </div>
    </Router>
  );
}

export default App;
