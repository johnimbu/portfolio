import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import fs from 'node:fs';
import path from 'node:path';

function skipBrokenPublicFiles(filenames: string[]): import('vite').Plugin {
  return {
    name: 'skip-broken-public-files',
    apply: 'build',
    closeBundle() {
      for (const filename of filenames) {
        const dest = path.resolve(__dirname, 'dist', filename);
        try {
          if (fs.existsSync(dest)) fs.unlinkSync(dest);
        } catch {
        }
      }
    },
    buildStart() {
      const origCopyFile = fs.copyFileSync.bind(fs);
      (fs as unknown as Record<string, unknown>).copyFileSync = (src: string, dest: string, ...args: unknown[]) => {
        for (const filename of filenames) {
          if (typeof src === 'string' && src.endsWith(filename)) {
            return;
          }
        }
        return origCopyFile(src, dest, ...(args as []));
      };
    },
  };
}

export default defineConfig({
  plugins: [
    react(),
    skipBrokenPublicFiles(['shopify07 copy.webp']),
  ],
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
});
